import { safeLineDestination } from '../../../shared/lineDestination.js';
import type { LineMessage } from './line.js';

// Compact brand cards: the illustration and accent communicate the actual event.
export const LINE_CARD_COLORS = {
  text: '#3D2314', muted: '#7D7772', accent: '#E65F2B', positive: '#287352',
  negative: '#A63F1B', border: '#EDE7DF', subtle: '#FAF5ED', white: '#FFFFFF',
};
export type LineCardCharacter = 'expense' | 'income' | 'guide' | 'review' | 'working' | 'received' | 'spent' | 'cancelled' | 'saving' | 'withdraw' | 'report' | 'reminder' | 'urgent' | 'document';
export const MAX_LINE_ITEMS = 5;
const C = LINE_CARD_COLORS;
function excerpt(value: string, limit = 120): string {
  return value.length > limit ? `${value.slice(0, limit - 1)}…` : value;
}

export function lineDivider() { return { type: 'separator', color: C.border, margin: 'lg' }; }
export function lineSection(text: string) {
  return { type: 'text', text, size: 'xs', weight: 'regular', color: C.muted, wrap: true, margin: 'lg' };
}

export function lineValueRow(label: string, value: string, opts?: { color?: string; bold?: boolean; size?: string }) {
  // Descriptive values need full width; fixed proportional columns clipped long Thai names.
  const stacked = value.length > 22 || (opts?.bold === false && !/^[+\-฿\d]/.test(value));
  return {
    type: 'box', layout: stacked ? 'vertical' : 'horizontal', spacing: 'sm', margin: 'md',
    contents: [
      { type: 'text', text: label, size: 'xs', color: C.muted, flex: 1, wrap: true },
      { type: 'text', text: excerpt(value || '—', 240), size: opts?.size || 'sm', color: opts?.color || C.text,
        weight: opts?.bold === false ? 'regular' : 'bold', flex: stacked ? 1 : 0,
        align: stacked ? 'start' : 'end', wrap: true },
    ],
  };
}

export function lineJobItem(item: { name: string; client?: string; amount: string; meta?: string; metaColor?: string }) {
  return {
    type: 'box', layout: 'vertical', margin: 'lg', spacing: 'xs',
    contents: [
      { type: 'box', layout: item.amount.length > 14 ? 'vertical' : 'horizontal', spacing: 'sm', contents: [
        { type: 'text', text: excerpt(item.name || 'ไม่ระบุชื่องาน'), size: 'sm', weight: 'regular', color: C.text, wrap: true, maxLines: 2, flex: 1 },
        { type: 'text', text: item.amount, size: 'sm', weight: 'bold', color: C.text, align: item.amount.length > 14 ? 'start' : 'end', flex: 0, wrap: true },
      ] },
      ...(item.client ? [{ type: 'text', text: excerpt(item.client), size: 'xs', color: C.muted, wrap: true, maxLines: 1 }] : []),
      ...(item.meta ? [{ type: 'text', text: excerpt(item.meta), size: 'xs', color: item.metaColor || C.muted, wrap: true }] : []),
    ],
  };
}

export function lineAppLink(path: string, label = 'ดูรายละเอียดในแอป'): { label: string; uri: string } | undefined {
  try {
    if (!process.env.APP_URL) return undefined;
    const origin = new URL(process.env.APP_URL);
    if (origin.protocol !== 'https:') return undefined;
    const target = new URL(path, origin.origin);
    if (target.origin !== origin.origin) return undefined;
    const destination = safeLineDestination(path);
    const liffId = process.env.LIFF_ID;
    if (destination && liffId && /^[A-Za-z0-9-]+$/.test(liffId)) {
      return { label, uri: `https://liff.line.me/${liffId}?openPath=${encodeURIComponent(destination)}` };
    }
    return { label, uri: target.href };
  } catch { return undefined; }
}

export function lineCard(opts: {
  title: string; subtitle?: string; altText: string; body: any[];
  character?: LineCardCharacter;
  compact?: boolean;
  metric?: { label: string; value: string; note?: string; color?: string };
  footer?: { label: string; uri: string }; note?: string;
}): LineMessage {
  const requested = opts.character || 'guide';
  // Legacy draft kinds do not imply that money has already changed hands.
  const character = requested === 'income' || requested === 'expense' ? 'review' : requested;
  const padding = '16px';
  const mascotSize = opts.compact ? '92px' : '104px';
  const mascotHeight = opts.compact ? '74px' : '84px';
  const palettes = {
    guide: { end: '#FFD9AA', paper: '#FFF5E9', ink: '#89400E', tag: 'ให้กระรอกช่วย' },
    review: { end: '#FFE3AF', paper: '#FFF7E7', ink: '#855116', tag: 'รายการของคุณ' },
    working: { end: '#FFE8A2', paper: '#FFF9E5', ink: '#765511', tag: 'โหมดทำงาน' },
    received: { end: '#D5F0BD', paper: '#ECF8E7', ink: '#287352', tag: 'เงินเข้าแล้ว' },
    spent: { end: '#FFD4BD', paper: '#FFF0E9', ink: '#A64B24', tag: 'เงินออก' },
    cancelled: { end: '#FFD5D0', paper: '#FFF0EE', ink: '#A0443B', tag: 'อัปเดตสถานะ' },
    saving: { end: '#DFEFAE', paper: '#F2F8E6', ink: '#507332', tag: 'ตุนไว้ให้อุ่นใจ' },
    withdraw: { end: '#FCE7A9', paper: '#FFF9E7', ink: '#856421', tag: 'จัดการเงินเก็บ' },
    report: { end: '#FFD8AB', paper: '#FFF3E4', ink: '#89400E', tag: 'เช็กภาพรวม' },
    reminder: { end: '#FFE39B', paper: '#FFF8DF', ink: '#8B6415', tag: 'เตือนให้ทัน' },
    urgent: { end: '#FFBFAB', paper: '#FFF0E9', ink: '#A63F1B', tag: 'ถึงเวลาจัดการ' },
    document: { end: '#DAEADA', paper: '#F0F6ED', ink: '#426C49', tag: 'เอกสารของคุณ' },
  };
  const palette = palettes[character];
  const asset = `/line/mascot-v6-${character}.png`;
  const mascot = lineAppLink(asset)?.uri;
  const gradient = { type: 'linearGradient', angle: '115deg', startColor: '#FFFCF7', centerColor: '#FFF7ED', centerPosition: '42%', endColor: palette.end };
  const heading = [
    { type: 'box', layout: 'horizontal', contents: [
      { type: 'box', layout: 'vertical', flex: 0, backgroundColor: palette.paper, cornerRadius: '8px', paddingStart: '8px', paddingEnd: '8px', paddingTop: '3px', paddingBottom: '3px', contents: [
        { type: 'text', text: palette.tag, size: 'xxs', color: palette.ink, weight: 'bold', wrap: false },
      ] },
      { type: 'box', layout: 'vertical', flex: 1, contents: [] },
    ] },
    { type: 'text', text: opts.title, size: 'lg', weight: 'bold', color: C.text, wrap: true },
    ...(opts.subtitle ? [{ type: 'text', text: opts.subtitle, size: 'xs', color: C.muted, wrap: true }] : []),
  ];
  return { type: 'flex', altText: opts.altText.slice(0, 400), contents: {
    type: 'bubble', size: 'mega',
    header: mascot ? {
      type: 'box', layout: 'horizontal', alignItems: 'flex-end', paddingAll: padding, paddingTop: '8px', paddingBottom: '0px', paddingEnd: '8px', spacing: 'sm', background: gradient,
      contents: [
        { type: 'box', layout: 'vertical', flex: 1, spacing: 'sm', paddingBottom: padding, justifyContent: 'center', contents: heading },
        // Keep the original mascot proportions and clip the legs at the header edge.
        { type: 'box', layout: 'vertical', width: mascotSize, height: mascotHeight, flex: 0, contents: [
          { type: 'box', layout: 'vertical', height: mascotHeight, contents: [] },
          { type: 'image', url: mascot, size: mascotSize, aspectRatio: '1:1', aspectMode: 'fit', position: 'absolute', offsetTop: '0px', offsetStart: '0px' },
        ] },
      ],
    } : { type: 'box', layout: 'vertical', paddingAll: '20px', paddingBottom: '0px', spacing: 'xs', contents: heading },
    body: { type: 'box', layout: 'vertical', paddingAll: padding, paddingTop: '16px', contents: [
      ...(opts.metric ? [{ type: 'box', layout: 'vertical', backgroundColor: palette.paper, background: { type: 'linearGradient', angle: '135deg', startColor: '#FFFCF8', endColor: palette.paper }, borderColor: palette.end, borderWidth: '1px', cornerRadius: '12px', paddingAll: '14px', spacing: 'xs', contents: [
        { type: 'text', text: opts.metric.label, size: 'xs', color: C.muted, wrap: true },
        { type: 'text', text: opts.metric.value, size: opts.metric.value.length > 18 ? 'xl' : 'xxl', weight: 'bold', color: opts.metric.color || C.accent, wrap: true },
        ...(opts.metric.note ? [{ type: 'text', text: opts.metric.note, size: 'xxs', color: C.muted, wrap: true }] : []),
      ] }] : []),
      ...opts.body,
      ...(opts.note ? [{ type: 'text', text: opts.note, size: 'xxs', color: C.muted, wrap: true, margin: 'lg' }] : []),
    ] },
    ...(opts.footer ? { footer: { type: 'box', layout: 'vertical', paddingAll: padding, paddingTop: '0px', contents: [
      { type: 'button', style: 'primary', color: C.accent, height: 'sm', action: { type: 'uri', ...opts.footer } },
    ] } } : {}),
    styles: { header: { backgroundColor: mascot ? '#FFFCF7' : C.white }, body: { backgroundColor: C.white }, footer: { backgroundColor: C.white } },
  } };
}
