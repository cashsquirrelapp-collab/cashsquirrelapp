import type { LineMessage } from './line.js';
import { LINE_CARD_COLORS as C, lineAppLink, lineCard, lineJobItem } from './lineCards.js';

export interface JobRow {
  id: string;
  name: string;
  client: string;
  status: string;
  pending: number;
  paymentStatus?: string;
  dueDate?: string | null;
  payDate: string | null;
  followUpCount?: number;
  lastFollowUpDate?: string;
  installments?: Array<{
    id: string;
    label: string;
    amount: number;
    dueDate: string | null;
    paidAt: string | null;
    status: 'pending' | 'paid';
  }>;
}

// Bangkok is UTC+7 with no DST; a fixed offset is enough to get "today" right locally.
export function todayInBangkok(now = new Date()): string {
  const bangkok = new Date(now.getTime() + 7 * 60 * 60 * 1000);
  return bangkok.toISOString().split('T')[0];
}

// How many days until (positive) or since (negative) the job's due date. 0 = due today.
function diffDaysFromToday(target: string, today: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(target)) return Number.NaN;
  const parsed = new Date(target + 'T00:00:00Z');
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== target) return Number.NaN;
  return (parsed.getTime() - Date.parse(today + 'T00:00:00Z')) / 86400000;
}

export interface JobWithDiff extends JobRow {
  diffDays: number;
}

// Overdue jobs, jobs due today, and jobs due within the next 2 days -- catching it a day or two
// early is far more useful than only finding out once it's already overdue.
//
// Trust the recorded `pending` field as-is, same as Dashboard/Summary/Timeline -- don't also gate
// on status behavior or paymentStatus, or a job whose paid flag and pending amount have drifted
// out of sync silently skips the digest instead of surfacing as money still owed.
export function findJobsNeedingAttention(jobs: JobRow[], now = new Date()): JobWithDiff[] {
  const today = todayInBangkok(now);
  return jobs
    .flatMap((j) => {
      if (j.installments?.length) {
        return j.installments.flatMap((row) => {
          if (row.status === 'paid' || row.amount <= 0 || !row.dueDate) return [];
          const diffDays = diffDaysFromToday(row.dueDate, today);
          if (!Number.isFinite(diffDays) || diffDays > 2) return [];
          return [{
            ...j,
            id: `${j.id}:${row.id}`,
            name: `${j.name} • ${row.label}`,
            pending: row.amount,
            dueDate: row.dueDate,
            payDate: row.dueDate,
            diffDays,
          }];
        });
      }
      const targetDateStr = j.dueDate || j.payDate;
      if (j.pending <= 0 || !targetDateStr) return [];

      const diffDays = diffDaysFromToday(targetDateStr, today);
      if (!Number.isFinite(diffDays) || diffDays > 2) return [];
      return [{ ...j, diffDays }];
    })
    .filter((j): j is JobWithDiff => !!j);
}

const MAX_REMINDER_ITEMS = 3;
function shortDate(date: string): string {
  return new Date(date + 'T00:00:00Z').toLocaleDateString('th-TH', {
    day: 'numeric', month: 'short', year: '2-digit', timeZone: 'Asia/Bangkok',
  });
}
function dueText(days: number): string {
  return days < 0 ? `เลย ${Math.abs(days)} วัน` : days === 0 ? 'วันนี้' : `อีก ${days} วัน`;
}

/** One compact digest, with a visible example from every urgency group and complete totals. */
export function buildDigestFlexMessage(jobs: JobWithDiff[], options: { test?: boolean; now?: Date } = {}): LineMessage {
  const sorted = [...jobs].sort((a, b) => a.diffDays - b.diffDays || (a.dueDate || a.payDate || '').localeCompare(b.dueDate || b.payDate || ''));
  const groups = [
    { title: 'เลยกำหนด', color: C.negative, background: '#FBEFE9', items: sorted.filter(j => j.diffDays < 0) },
    { title: 'ครบกำหนดวันนี้', color: '#9A5B18', background: '#FFF5DF', items: sorted.filter(j => j.diffDays === 0) },
    { title: 'ใกล้ครบกำหนด', color: '#75614B', background: '#F7F3EC', items: sorted.filter(j => j.diffDays > 0) },
  ];
  // Reserve one slot per group so a large overdue backlog cannot hide today's or upcoming money.
  const visible = new Set(groups.flatMap(group => group.items.slice(0, 1)));
  for (const job of sorted) {
    if (visible.size >= MAX_REMINDER_ITEMS) break;
    visible.add(job);
  }
  const total = jobs.reduce((sum, job) => sum + job.pending, 0);
  const body: any[] = [{
    type: 'box', layout: 'vertical', spacing: 'xs', contents: [
      { type: 'text', text: options.test ? 'ยอดตัวอย่าง · ไม่ใช่ยอดจริง' : 'ยอดรอรับที่ต้องติดตาม', size: 'xs', color: C.muted, wrap: true },
      { type: 'text', text: `฿ ${total.toLocaleString('th-TH')}`, size: total >= 1e10 ? 'xl' : 'xxl', weight: 'bold', color: C.text, wrap: true },
      { type: 'text', text: `${jobs.length} รายการ · เรียงตามความเร่งด่วน`, size: 'xxs', color: C.muted, wrap: true },
    ],
  }];
  for (const group of groups) {
    if (!group.items.length) continue;
    body.push({
      type: 'box', layout: 'vertical', margin: 'md', paddingAll: '12px', cornerRadius: '12px', backgroundColor: group.background,
      contents: [
        { type: 'text', text: `${group.title} · ${group.items.length} รายการ`, size: 'xs', weight: 'bold', color: group.color, wrap: true },
        ...group.items.filter(job => visible.has(job)).map(job => {
          const date = job.dueDate || job.payDate;
          const row = lineJobItem({
            name: job.name, client: job.client,
            amount: `฿ ${job.pending.toLocaleString('th-TH')}`,
            meta: `${date ? `กำหนด ${shortDate(date)} · ` : ''}${dueText(job.diffDays)}`,
            metaColor: group.color,
          });
          return { ...row, margin: 'sm' };
        }),
      ],
    });
  }
  const hiddenCount = jobs.length - visible.size;
  const note = options.test ? 'ข้อมูลตัวอย่างสำหรับทดสอบเท่านั้น\nไม่มีการเพิ่มงานหรือเปลี่ยนยอดเงินจริง'
    : `${hiddenCount > 0 ? `แสดง ${visible.size} จาก ${jobs.length} รายการ · อีก ${hiddenCount} รายการดูในแอป\n` : ''}รับเงินแล้ว? อัปเดตสถานะในแอปได้เลย`;
  return lineCard({
    compact: true, character: groups[0].items.length ? 'urgent' : 'reminder', title: options.test ? 'ทดสอบแจ้งเตือน' : 'เตือนรับเงิน',
    subtitle: `เครดิตเทอม · ${shortDate(todayInBangkok(options.now))}`,
    altText: `${options.test ? '[ทดสอบ] ' : ''}เตือนรับเงิน: เลยกำหนด ${groups[0].items.length} · วันนี้ ${groups[1].items.length} · ใกล้ครบกำหนด ${groups[2].items.length} รายการ`,
    body, note, footer: lineAppLink('/receivables', 'ดูรายการรอรับเงิน'),
  });
}

/** In-memory examples only. Use the same date selection and card builder as the scheduled digest. */
export function buildReminderTestMessage(now = new Date()): LineMessage {
  const today = Date.parse(todayInBangkok(now) + 'T00:00:00Z');
  const samples: JobRow[] = [
    { id: 'demo-overdue', name: 'ออกแบบแพ็กเกจ', client: 'ลูกค้าตัวอย่าง A', status: 'pending', pending: 4500, payDate: new Date(today - 3 * 86400000).toISOString().slice(0, 10) },
    { id: 'demo-today', name: 'ถ่ายภาพสินค้า', client: 'ลูกค้าตัวอย่าง B', status: 'pending', pending: 3000, payDate: new Date(today).toISOString().slice(0, 10) },
    { id: 'demo-soon', name: 'ตัดต่อวิดีโอ', client: 'ลูกค้าตัวอย่าง C', status: 'pending', pending: 2500, payDate: new Date(today + 2 * 86400000).toISOString().slice(0, 10) },
  ];
  return buildDigestFlexMessage(findJobsNeedingAttention(samples, now), { test: true, now });
}

