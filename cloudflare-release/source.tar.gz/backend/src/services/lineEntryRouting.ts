import { lineAppLink, lineCard, LINE_CARD_COLORS as C } from './lineCards.js';
import type { LineMessage } from './line.js';

/** Every unprefixed message stays on the deterministic path, including unsupported inputs. */
export function explicitLineAiText(text: string): string | null {
  const match = /^(?:ถาม\s*AI|AI)[\s:：]+(.+)$/is.exec(text.trim());
  return match?.[1].trim() || null;
}

// The app records jobs and the income they bring (owner, 2026-10-22: "ของเรามันเอาไว้จดงาน จดรายรับที่
// เป็นงาน"), so the examples are jobs. Every example is one parseLineQuickDraft turns into a job draft
// (tests/line-entry-help.test.ts); none may contain "ตัวอย่าง", which the parser refuses on purpose.
export const LINE_JOB_EXAMPLES = [
  'เพิ่มงาน ออกแบบโลโก้ 5000',
  'เพิ่มงาน ถ่ายภาพ ให้ร้านดอกไม้ 12000',
  'เพิ่มงาน ตัดต่อวิดีโอ 8000 รอรับเงิน',
] as const;

/** A hello on its own ("สวัสดีครับ", "hi"), so the secretary greets back instead of saying it did not understand. */
export function isLineGreeting(text: string): boolean {
  const plain = text.normalize('NFKC').trim().toLowerCase().replace(/[\s!.~?]+/g, '').replace(/(ครับ|ค่ะ|คะ|จ้า|จ้ะ|นะ)+$/, '');
  return /^(สวัสดี|หวัดดี|ดี|hello|hi|hey)$/.test(plain);
}

/**
 * The reply when a linked user's message is not a command the bot knows: it says so plainly and shows
 * how to record a job. A greeting gets a greeting instead (owner, 2026-10-22: welcome people in the
 * secretary's voice, "มีอะไรให้เลขาช่วยไหม").
 */
export function buildLineEntryHelp(text = ''): LineMessage {
  const form = lineAppLink('/jobs?openAddJob=1', 'เพิ่มงานในแอป');
  const greeting = isLineGreeting(text);
  return lineCard({
    title: greeting ? 'สวัสดีครับ' : 'เลขายังไม่เข้าใจครับ',
    subtitle: greeting ? 'มีอะไรให้เลขากระรอกช่วยไหมครับ' : 'ลองพิมพ์ตามแบบด้านล่างครับ', character: 'guide',
    altText: `${greeting ? 'สวัสดีครับ มีอะไรให้เลขาช่วยไหมครับ' : 'เลขายังไม่เข้าใจข้อความนี้ครับ'} · พิมพ์ ${LINE_JOB_EXAMPLES[0]} เพื่อบันทึกงาน`,
    body: [
      { type:'text',text:'บันทึกงานได้โดยพิมพ์ แล้วตรวจก่อนบันทึก',size:'sm',color:C.text,wrap:true },
      { type:'box',layout:'vertical',spacing:'sm',margin:'lg',paddingAll:'12px',cornerRadius:'8px',backgroundColor:C.subtle,
        contents: LINE_JOB_EXAMPLES.map(example => ({ type:'text',text:example,size:'sm',color:C.text,wrap:true })) },
      { type:'text',text:'ใส่ลูกค้าหลังคำว่า “ให้” ต่อท้ายด้วย รอรับเงิน, รับเงินครบแล้ว หรือ ได้รับมัดจำ 3000 ได้',size:'xs',color:C.muted,wrap:true,margin:'lg' }
    ],
    footer: form,
    note: 'ดูเงินได้จาก “สรุปเดือนนี้” หรือ “รอรับเงิน”',
  });
}
