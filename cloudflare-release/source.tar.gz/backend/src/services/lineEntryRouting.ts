import { lineAppLink, lineCard, LINE_CARD_COLORS as C } from './lineCards.js';
import type { LineMessage } from './line.js';

/** Every unprefixed message stays on the deterministic path, including unsupported inputs. */
export function explicitLineAiText(text: string): string | null {
  const match = /^(?:ถาม\s*AI|AI)[\s:：]+(.+)$/is.exec(text.trim());
  return match?.[1].trim() || null;
}

export function buildLineEntryHelp(): LineMessage {
  const form = lineAppLink('/jobs?openAddJob=1', 'เพิ่มงานในแอป');
  return lineCard({
    title: 'ให้เลขาช่วยจดงาน', subtitle: 'ผู้ช่วยจัดการงานและการเงินของคุณ', character: 'review',
    altText: 'พิมพ์ กาแฟ80 หรือเปิดฟอร์มเพื่อกรอกและตรวจรายการ',
    body: [
      { type:'text',text:'ลองพิมพ์รายการสั้น ๆ ตามตัวอย่าง',size:'sm',color:C.text,wrap:true },
      { type:'text',text:'กาแฟ80\nค่าเดินทาง120\nรายรับ ค่าถ่ายภาพ 3000',size:'sm',color:C.text,wrap:true,margin:'lg' },
      { type:'text',text:'ถ้าข้อมูลยังไม่ชัด ให้เปิดฟอร์มแล้วเลือกเองได้เลย',size:'xs',color:C.muted,wrap:true,margin:'lg' },
    ],
    footer: form,
    note: 'ดูเงินได้จาก “สรุปเดือนนี้” หรือ “รอรับเงิน”',
  });
}
