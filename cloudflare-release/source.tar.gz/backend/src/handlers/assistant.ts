import { z } from 'zod';
import { ATTACHMENT_MAX_BASE64, ATTACHMENT_TYPES, checkAttachment } from '../ai/attachment.js';
import { aiConfig } from '../ai/config.js';
import { confirmProposal, handleMessage, usageStatus } from '../ai/service.js';
import { assistantPlan, supabaseAssistantDb } from '../ai/supabaseDb.js';
import { HttpError, withGuard } from '../http/guard.js';
import { rateLimit } from '../security/rateLimit.js';
import { requireUser } from '../security/session.js';

// /api/assistant — เลขากระรอก. GET: is it on, the plan, tokens left. POST: send a message, confirm or cancel a
// proposal. Off unless AI_ENABLED=true; the keys stay on the server. The browser never chooses the model, the
// user id or the cost.

const turnSchema = z.object({ role: z.enum(['user', 'assistant']), text: z.string().max(1000) }).strict();
const actionSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('message'),
    text: z.string().trim().min(1).max(2000),
    history: z.array(turnSchema).max(12).optional(),
    pageName: z.string().trim().max(40).optional(),
    attachment: z.object({ name: z.string().max(200), mimeType: z.enum(ATTACHMENT_TYPES), data: z.string().min(4).max(ATTACHMENT_MAX_BASE64) }).strict().optional(),
  }).strict(),
  z.object({ action: z.literal('confirm'), proposalId: z.string().regex(/^p_[0-9a-f-]{36}$/) }).strict(),
  z.object({ action: z.literal('cancel'), proposalId: z.string().regex(/^p_[0-9a-f-]{36}$/) }).strict(),
]);

export default withGuard(async (req, res) => {
  if (!['GET', 'POST'].includes(req.method || '')) throw new HttpError(405, 'Method not allowed');
  const user = await requireUser(req, res);
  if (req.headers['x-account-id'] !== user.id) throw new HttpError(401, 'บัญชีเปลี่ยน กรุณาโหลดหน้าใหม่');
  // Group workspaces are not supported yet: the assistant works on the signed-in person's own account only.
  if (req.headers['x-finance-group'] !== undefined) throw new HttpError(400, 'เลขากระรอกใช้ได้กับบัญชีส่วนตัวเท่านั้นในตอนนี้');
  const config = aiConfig(process.env);
  const db = supabaseAssistantDb;

  // While AI_ADMINS_ONLY is on (the default), everyone but system admins sees เลขา as switched off.
  const configFor = (plan: Awaited<ReturnType<typeof assistantPlan>>) => (config.adminsOnly && plan.plan !== 'admin' ? { ...config, enabled: false } : config);

  if (req.method === 'GET') {
    await rateLimit('assistant-read', user.id, 60, 60);
    const plan = await assistantPlan(user);
    res.json(await usageStatus(db, configFor(plan), user.id, plan));
    return;
  }

  const parsed = actionSchema.safeParse(req.body);
  if (!parsed.success) throw new HttpError(400, 'ข้อความไม่ถูกต้อง หรือยาวเกิน 2,000 ตัวอักษร');
  const body = parsed.data;
  if (body.action === 'confirm') {
    await rateLimit('assistant-confirm', user.id, 30, 60);
    res.json(await confirmProposal(db, user.id, body.proposalId));
    return;
  }
  if (body.action === 'cancel') {
    await rateLimit('assistant-confirm', user.id, 30, 60);
    res.json({ cancelled: await db.cancelProposal(user.id, body.proposalId) });
    return;
  }
  await rateLimit('assistant-message', user.id, 20, 60);
  const attachment = body.attachment ? checkAttachment(body.attachment) : undefined;
  if (attachment) await rateLimit('assistant-file', user.id, 10, 600);
  const plan = await assistantPlan(user);
  res.json(await handleMessage(db, { config: configFor(plan) }, user.id, plan, { text: body.text, history: body.history, pageName: body.pageName, attachment }));
}, { csrf: true });
