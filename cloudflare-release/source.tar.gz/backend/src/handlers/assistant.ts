import { z } from 'zod';
import { ATTACHMENT_MAX_BASE64, ATTACHMENT_TYPES, checkAttachment } from '../ai/attachment.js';
import { aiConfig, aiConfigFor } from '../ai/config.js';
import { buildLineInbox, inboxReply } from '../ai/lineInbox.js';
import { accountSnapshot } from '../repositories/accounts.js';
import type { UserRow } from '../services/lineAssistant.js';
import { dueActionOutcome, duePartialOutcome, dueRefFromDigestId } from '../services/lineDuePayments.js';
import { confirmProposal, handleMessage, MESSAGE_RATE, usageStatus } from '../ai/service.js';
import { assistantPlan, supabaseAssistantDb } from '../ai/supabaseDb.js';
import { transcribeVoice, VOICE_MAX_BASE64 } from '../ai/transcription.js';
import { HttpError, withGuard } from '../http/guard.js';
import { rateLimit } from '../security/rateLimit.js';
import { requireUser } from '../security/session.js';

// /api/assistant — เลขากระรอก. GET: is it on, the plan, tokens left. POST: send a message, confirm or cancel a
// proposal. Off unless AI_ENABLED=true; the keys stay on the server. The browser never chooses the model, the
// user id or the cost.

const turnSchema = z.object({ role: z.enum(['user', 'assistant']), text: z.string().max(1000) }).strict();
const actionSchema = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('message'),
    text: z.string().trim().min(1).max(2000),
    history: z.array(turnSchema).max(12).optional(),
    pageName: z.string().trim().max(40).optional(),
    attachment: z.object({ name: z.string().max(200), mimeType: z.enum(ATTACHMENT_TYPES), data: z.string().min(4).max(ATTACHMENT_MAX_BASE64) }).strict().optional(),
  }).strict(),
  z.object({
    action: z.literal('transcribe'),
    audio: z.object({ mimeType: z.literal('audio/wav'), data: z.string().min(4).max(VOICE_MAX_BASE64) }).strict(),
    language: z.enum(['th-TH', 'en-US']).optional(),
  }).strict(),
  z.object({ action: z.literal('confirm'), proposalId: z.string().regex(/^p_[0-9a-f-]{36}$/) }).strict(),
  z.object({ action: z.literal('cancel'), proposalId: z.string().regex(/^p_[0-9a-f-]{36}$/) }).strict(),
  // The notifications thread: a payment button on a reminder, or the amount typed after ได้ไม่ครบ.
  z.object({ action: z.literal('line-due'), kind: z.enum(['paid', 'later', 'partial']), id: z.string().regex(/^[A-Za-z0-9_.-]{1,128}(?::[A-Za-z0-9_.-]{1,128})?$/) }).strict(),
  z.object({ action: z.literal('line-partial'), text: z.string().trim().min(1).max(200) }).strict(),
]);

export default withGuard(async (req, res) => {
  if (!['GET', 'POST'].includes(req.method || '')) throw new HttpError(405, 'Method not allowed');
  const user = await requireUser(req, res);
  if (req.headers['x-account-id'] !== user.id) throw new HttpError(401, 'บัญชีเปลี่ยน กรุณาโหลดหน้าใหม่');
  // Group workspaces are not supported yet: the assistant works on the signed-in person's own account only.
  if (req.headers['x-finance-group'] !== undefined) throw new HttpError(400, 'เลขากระรอกใช้ได้กับบัญชีส่วนตัวเท่านั้นในตอนนี้');
  const config = aiConfig(process.env);
  const db = supabaseAssistantDb;

  // While AI_ADMINS_ONLY is on (the default), only system admins and AI_ALLOWED_EMAILS get the real เลขา.
  const configFor = (plan: Awaited<ReturnType<typeof assistantPlan>>) => aiConfigFor(config, plan.plan, user.email);

  if (req.method === 'GET' && req.query.view === 'line') {
    // The "แจ้งเตือนอัตโนมัติ" thread: built from this account's own data, whether or not the AI is on.
    await rateLimit('assistant-read', user.id, 60, 60);
    res.json(buildLineInbox(await accountSnapshot(user.id) as unknown as UserRow));
    return;
  }
  if (req.method === 'GET') {
    await rateLimit('assistant-read', user.id, 60, 60);
    const plan = await assistantPlan(user);
    res.json(await usageStatus(db, configFor(plan), user.id, plan));
    return;
  }

  const parsed = actionSchema.safeParse(req.body);
  if (!parsed.success) throw new HttpError(400, 'ข้อความไม่ถูกต้อง หรือยาวเกิน 2,000 ตัวอักษร');
  const body = parsed.data;
  if (body.action === 'transcribe') {
    await rateLimit('assistant-voice-minute', user.id, 6, 60);
    await rateLimit('assistant-voice-window', user.id, 20, 600);
    const plan = await assistantPlan(user);
    res.json(await transcribeVoice(db, { config: configFor(plan) }, user.id, plan, body));
    return;
  }
  if (body.action === 'confirm') {
    await rateLimit('assistant-confirm', user.id, 30, 60);
    res.json(await confirmProposal(db, user.id, body.proposalId));
    return;
  }
  if (body.action === 'line-due' || body.action === 'line-partial') {
    // The same recording as LINE's 08:00 buttons (lineDuePayments): reread, apply, save with its version.
    await rateLimit('assistant-confirm', user.id, 30, 60);
    if (body.action === 'line-due') {
      const ref = dueRefFromDigestId(body.id);
      if (!ref) throw new HttpError(400, 'รายการไม่ถูกต้อง');
      res.json(inboxReply(await dueActionOutcome({ user_id: user.id }, { kind: body.kind, ref })));
      return;
    }
    const account = await accountSnapshot(user.id) as unknown as UserRow;
    const outcome = await duePartialOutcome({ user_id: user.id, jobs: account.jobs as never }, body.text);
    res.json(outcome ? inboxReply(outcome) : { text: 'พิมพ์ยอดต่อท้ายข้อความ เช่น รับเงินบางส่วน #ABC123 ยอด 5000' });
    return;
  }
  if (body.action === 'cancel') {
    await rateLimit('assistant-confirm', user.id, 30, 60);
    res.json({ cancelled: await db.cancelProposal(user.id, body.proposalId) });
    return;
  }
  await rateLimit(MESSAGE_RATE.scope, user.id, MESSAGE_RATE.limit, MESSAGE_RATE.seconds);
  const attachment = body.attachment ? checkAttachment(body.attachment) : undefined;
  if (attachment) await rateLimit('assistant-file', user.id, 10, 600);
  const plan = await assistantPlan(user);
  res.json(await handleMessage(db, { config: configFor(plan) }, user.id, plan, { text: body.text, history: body.history, pageName: body.pageName, attachment }));
}, { csrf: true });
