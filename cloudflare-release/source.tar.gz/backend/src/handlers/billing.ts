import { appOrigin } from '../config/env.js';
import { configuredStripeLivemode, stripe } from '../config/stripe.js';
import { getSupabaseAdmin } from '../config/supabase.js';
import { HttpError, withGuard } from '../http/guard.js';
import { rateLimit } from '../security/rateLimit.js';
import { requireUser } from '../security/session.js';
import { getStripeBillingPortalConfiguration, isStripeCustomerOwnedByUser } from '../services/stripeSubscriptions.js';
import { cancelPrepaidCheckout, prepaidEnabled, startPrepaidCheckout } from '../services/prepaidBilling.js';

export default withGuard(async (req, res) => {
  const user = await requireUser(req, res);
  // Status polling must not exhaust the separate mutation budget.
  await rateLimit(req.method === 'POST' ? 'billing-write' : 'billing-read', user.id, req.method === 'POST' ? 12 : 60, 60);
  const admin = getSupabaseAdmin();
  const result = await admin.from('subscriptions').select('*').eq('user_id', user.id).maybeSingle();
  if (result.error) throw result.error;
  const row = result.data;
  if (req.method === 'GET') {
    // Read only authoritative database state; a success query string never grants access.
    let pending = null;
    let pendingCheckout = null;
    if (prepaidEnabled() && row?.stripe_checkout_reservation_id) {
      const query = await admin.from('cashflow_prepaid_orders')
        .select('id,session_id,period,months,amount,method,checkout_url,expires_at,status')
        .eq('id', row.stripe_checkout_reservation_id).eq('user_id', user.id).maybeSingle();
      if (query.error) throw query.error;
      if (query.data?.session_id && ['reserved','open'].includes(query.data.status)) {
        pendingCheckout = { id: query.data.id, months: query.data.months, amount: query.data.amount };
      }
      if (query.data?.method === 'promptpay' && query.data.checkout_url && ['reserved','open'].includes(query.data.status)) {
        pending = { url: query.data.checkout_url, expires_at: query.data.expires_at,
          amount: query.data.amount, months: query.data.months, period: query.data.period,
          status: Date.parse(query.data.expires_at) > Date.now() ? 'open' : 'expired' };
      }
    }
    res.json({ checkout_ready: prepaidEnabled(), pending_checkout: pendingCheckout, subscription: row ? {
      status: row.status, plan: row.plan, current_period_end: row.current_period_end,
      cancel_at_period_end: row.cancel_at_period_end, stripe_status: row.stripe_subscription_status,
      has_subscription: Boolean(row.stripe_subscription_id), managed: Boolean(row.stripe_customer_id),
      intro_eligible: false, intro_paid_cycles: row.stripe_intro_paid_cycles || 0,
      promptpay_checkout: pending,
    } : null });
    return;
  }
  if (req.method !== 'POST') throw new HttpError(405, 'Method not allowed');
  if (req.body?.action === 'cancel_checkout') {
    if (typeof req.body.order_id !== 'string' || !/^[a-f0-9-]{36}$/i.test(req.body.order_id)
      || Object.keys(req.body).some(key => !['action','order_id'].includes(key))) {
      throw new HttpError(400, 'Invalid cancellation fields');
    }
    res.json(await cancelPrepaidCheckout(user.id, req.body.order_id));
    return;
  }
  if (req.body?.action === 'portal') {
    if (!row?.stripe_customer_id) throw new HttpError(409, 'ยังไม่มีบัญชีลูกค้า Stripe');
    const [customer, configuration] = await Promise.all([
      stripe.customers.retrieve(row.stripe_customer_id), getStripeBillingPortalConfiguration(),
    ]);
    if (!isStripeCustomerOwnedByUser(customer, user.id, configuredStripeLivemode())) throw new Error('Invalid Stripe Customer');
    const portal = await stripe.billingPortal.sessions.create({ customer: customer.id, configuration: configuration.id,
      return_url: `${appOrigin()}/app` });
    res.json({ url: portal.url, destination: 'portal' });
    return;
  }
  if (!['checkout','promptpay_checkout'].includes(req.body?.action)) throw new HttpError(400, 'Invalid billing action');
  // No client-supplied amount, duration, Stripe Price, account or URL is trusted.
  const allowed = new Set(['action','period']);
  if (Object.keys(req.body).some(key => !allowed.has(key))) throw new HttpError(400, 'Invalid checkout fields');
  res.json(await startPrepaidCheckout(user, req.body.period, req.body.action === 'promptpay_checkout' ? 'promptpay' : 'card'));
}, { csrf: true });
