import { inFreeTrial } from '../../../shared/trial.js';
import type { User } from '@supabase/supabase-js';
import { getSupabaseAdmin } from '../config/supabase.js';
import { HttpError } from '../http/guard.js';
import { accountSnapshot } from '../repositories/accounts.js';
import { systemRole } from '../repositories/roles.js';
import type { UserRow } from '../services/lineAssistant.js';
import { listVaultFiles, hasProAccess } from '../services/vault.js';
import type { AssistantDb, PlanInfo, StoredProposal } from './service.js';
import { MEMORY_LIMIT, type MemoryRow } from './memory.js';
import { claimDocumentSlots, releaseDocumentSlots } from '../services/documentQuota.js';
import { applyWithDocumentQuota } from './documentQuota.js';

// AssistantDb on Supabase, using database/ai_secretary.sql (tables cashflow_ai_*). Until the owner runs that file,
// every call here answers 503 with a plain message instead of failing silently.


/** The history of a memory (review and rollback); before the migration runs there is none, and nothing fails. */
async function memoryEvents(userId: string, rows: { memory_id: string | null; action: 'created' | 'updated' | 'deleted' | 'expired'; kind: string; old_value: string | null; new_value: string | null; channel: 'app' | 'line' | 'system' }[]) {
  if (!rows.length) return;
  await getSupabaseAdmin().from('cashflow_ai_memory_events').insert(rows.map(row => ({ user_id: userId, ...row }))).then(() => undefined, () => undefined);
}

function dbError(error: { code?: string; message?: string } | null): void {
  if (!error) return;
  // PostgREST: table or function missing (database/ai_secretary.sql not run yet).
  if (['PGRST202', 'PGRST205', '42P01', '42883'].includes(error.code || '')) {
    throw new HttpError(503, 'เลขากระรอกต้องอัปเดตฐานข้อมูลก่อน (ai_secretary.sql)', 'ai_db_missing');
  }
  throw error;
}

/** Same rule as hasProAccess (services/vault.ts) with the trial and admins told apart. Fails closed. */
export async function assistantPlan(user: User, now = Date.now()): Promise<PlanInfo> {
  const [{ data: sub, error }, role] = await Promise.all([
    getSupabaseAdmin().from('subscriptions').select('status, plan, current_period_end').eq('user_id', user.id).maybeSingle(),
    systemRole(user.id),
  ]);
  if (error) throw error;
  if (role === 'admin') return { plan: 'admin' };
  if (sub?.plan === 'admin_revoked' || sub?.plan === 'admin_removed') return { plan: 'none' };
  if (sub?.status === 'active' && sub.plan === 'admin_grant') return { plan: 'pro' };
  // Paid Pro: tokens renew monthly on the renewal day of current_period_end.
  if (sub?.status === 'active' && sub.current_period_end && new Date(sub.current_period_end).getTime() > now) {
    return { plan: 'pro', periodEnd: sub.current_period_end };
  }
  const trial = inFreeTrial(user.created_at, now);
  return { plan: trial ? 'trial' : 'none' };
}

/** The plan for a LINE user (no session there): the auth record gives the creation date the trial counts from. Fails closed. */
export async function assistantPlanForUserId(userId: string): Promise<PlanInfo & { email: string | null }> {
  const { data, error } = await getSupabaseAdmin().auth.admin.getUserById(userId);
  if (error || !data?.user) throw error ?? new Error('auth user missing');
  return { ...(await assistantPlan(data.user)), email: data.user.email ?? null };
}

type ProposalRow = { id: string; user_id: string; kind: StoredProposal['kind']; job_id: string; record: Record<string, unknown> | null; base_version: number | null; title: string; changes: StoredProposal['changes']; created_at: string };
const fromRow = (row: ProposalRow): StoredProposal => ({
  id: row.id, userId: row.user_id, kind: row.kind, jobId: row.job_id, record: row.record, baseVersion: row.base_version,
  title: row.title, changes: row.changes, createdAt: new Date(row.created_at).getTime(),
});

export const supabaseAssistantDb: AssistantDb = {
  listVaultFiles: userId => listVaultFiles({ kind: 'user', id: userId }),
  async loadAccount(userId) {
    const snapshot = await accountSnapshot(userId);
    const versions = { ...(snapshot.versions?.cashflow_jobs || {}) } as Record<string, number>;
    for (const [table, records] of Object.entries(snapshot.versions || {})) {
      if (records && typeof records === 'object') for (const [id, version] of Object.entries(records)) {
        if (typeof version === 'number') versions[`${table}:${id}`] = version;
      }
    }
    const documentVersions = snapshot.versions?.cashflow_documents;
    const absentRecords = documentVersions && typeof documentVersions === 'object'
      ? ['settings', 'issuer_profile', 'notif_settings'].filter(id => !Object.prototype.hasOwnProperty.call(documentVersions, id)).map(id => `cashflow_documents:${id}`)
      : [];
    return { user: snapshot as unknown as UserRow, versions, absentRecords };
  },
  async reserve(input) {
    const { data, error } = await getSupabaseAdmin().rpc('cashflow_ai_reserve', {
      p_user_id: input.userId, p_cycle: input.cycle, p_request_id: input.requestId, p_tokens: input.tokens,
      p_token_limit: input.tokenLimit, p_request_limit: input.requestLimit, p_daily_cap_usd: input.dailyCapUsd,
    });
    dbError(error);
    const result = data as { ok: boolean; reason?: 'tokens' | 'requests' | 'daily_cap'; used_tokens?: number; used_requests?: number };
    return result.ok ? { ok: true, usedTokens: Number(result.used_tokens || 0), usedRequests: Number(result.used_requests || 0) } : { ok: false, reason: result.reason || 'tokens' };
  },
  async settle(input) {
    const { error } = await getSupabaseAdmin().rpc('cashflow_ai_settle', {
      p_user_id: input.userId, p_request_id: input.requestId, p_tokens: input.tokens, p_cost_usd: input.costUsd,
      p_model: input.model, p_route: input.route, p_prompt_version: input.promptVersion, p_release: input.release,
    });
    dbError(error);
  },
  async usage(userId, cycle) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_usage').select('tokens')
      .eq('user_id', userId).eq('cycle_key', cycle).in('status', ['reserved', 'settled']);
    dbError(error);
    const rows = (data || []) as { tokens: number }[];
    return { tokens: rows.reduce((sum, row) => sum + Number(row.tokens || 0), 0), requests: rows.length };
  },
  async saveProposal(proposal) {
    const row = {
      id: proposal.id, user_id: proposal.userId, kind: proposal.kind, job_id: proposal.jobId, record: proposal.record,
      base_version: proposal.baseVersion, title: proposal.title, changes: proposal.changes,
    };
    // tool/args (editable cards, 2026-10-24) need supabase/migrations/20261024120000_ai_proposal_args.sql. Until it
    // runs, the card is saved without them and simply cannot be edited.
    const { error } = await getSupabaseAdmin().from('cashflow_ai_proposals').insert({ ...row, tool: proposal.tool ?? null, args: proposal.args ?? null });
    if (error && /\b(tool|args)\b/.test(`${error.message} ${(error as { details?: string }).details ?? ''}`)) {
      const retry = await getSupabaseAdmin().from('cashflow_ai_proposals').insert(row);
      dbError(retry.error);
      return;
    }
    dbError(error);
  },
  async getProposal(userId, id) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_proposals').select('id,user_id,kind,job_id,record,base_version,title,changes,created_at,status,expires_at,tool,args')
      .eq('id', id).eq('user_id', userId).maybeSingle();
    if (error) return null; // before the migration the columns do not exist: not editable
    const row = data as (ProposalRow & { status: string; expires_at: string; tool: string | null; args: Record<string, unknown> | null }) | null;
    if (!row || row.status !== 'pending' || Date.parse(row.expires_at) <= Date.now()) return null;
    return { ...fromRow(row), tool: row.tool ?? undefined, args: row.args ?? undefined };
  },
  async claimProposal(userId, id) {
    const { data, error } = await getSupabaseAdmin().rpc('cashflow_ai_claim_proposal', { p_user_id: userId, p_id: id });
    dbError(error);
    const rows = (data || []) as ProposalRow[];
    return rows[0] ? fromRow(rows[0]) : null;
  },
  async finishProposal(userId, id, status) {
    const { error } = await getSupabaseAdmin().from('cashflow_ai_proposals')
      .update({ status, ...(status === 'applied' ? { applied_at: new Date().toISOString() } : {}) })
      .eq('id', id).eq('user_id', userId).eq('status', 'applying');
    dbError(error);
  },
  async cancelProposal(userId, id) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_proposals').update({ status: 'cancelled' })
      .eq('id', id).eq('user_id', userId).eq('status', 'pending').select('id');
    dbError(error);
    return Boolean(data?.length);
  },
  async applyChanges(userId, changes) {
    return applyWithDocumentQuota(userId, changes, {
      unlimited: async owner => {
        const { data, error } = await getSupabaseAdmin().auth.admin.getUserById(owner);
        if (error || !data?.user || data.user.id !== owner) throw error ?? new Error('auth user missing');
        return hasProAccess(data.user);
      },
      claim: claimDocumentSlots,
      release: releaseDocumentSlots,
      apply: async (owner, validated) => {
        // A pending goal proposal cannot outlive the account's verified admin feature access.
        if (validated.some(change => change.table === 'cashflow_goals') && await systemRole(owner) !== 'admin') {
          throw new HttpError(403, 'ฟีเจอร์เป้าหมายยังไม่เปิดให้บัญชีนี้ใช้งาน', 'ai_feature_unavailable');
        }
        const { data, error } = await getSupabaseAdmin().rpc('cashflow_apply_changes', { p_user_id: owner, p_changes: validated });
        if (error?.code === '40001') return false;
        dbError(error);
        // false = stale version; null supports the older SQL function returning void.
        return data !== false;
      },
    });
  },
  async memories(userId) {
    // Memory is a nicety: if it cannot be read, the assistant still answers. Before 20261025090000_ai_learning.sql
    // runs, the new columns are missing and the old ones are read.
    const db = getSupabaseAdmin();
    let read = await db.from('cashflow_ai_memories').select('id, kind, value, source, created_at, updated_at, last_used_at')
      .eq('user_id', userId).order('updated_at', { ascending: false }).limit(MEMORY_LIMIT + 10);
    if (read.error) read = await db.from('cashflow_ai_memories').select('id, kind, value, created_at').eq('user_id', userId).order('created_at', { ascending: false }).limit(20) as typeof read;
    if (read.error) return [];
    return (read.data || []) as MemoryRow[];
  },
  async remember(userId, kind, value, limit) {
    const db = getSupabaseAdmin();
    if (kind === 'preferred_name' || kind === 'tone') {
      const removed = await db.from('cashflow_ai_memories').delete().eq('user_id', userId).eq('kind', kind);
      dbError(removed.error);
    }
    const inserted = await db.from('cashflow_ai_memories').insert({ user_id: userId, kind, value });
    dbError(inserted.error);
    const { data } = await db.from('cashflow_ai_memories').select('id').eq('user_id', userId).order('created_at', { ascending: false });
    const extra = (data || []).slice(limit).map(row => row.id as string);
    if (extra.length) await db.from('cashflow_ai_memories').delete().in('id', extra);
  },
  async saveMemory(userId, input) {
    const db = getSupabaseAdmin();
    const now = new Date().toISOString();
    let memoryId = input.replace?.id;
    if (input.replace) {
      const updated = await db.from('cashflow_ai_memories').update({ value: input.value, source: input.source, version: (input.replace.version ?? 1) + 1, updated_at: now })
        .eq('id', input.replace.id).eq('user_id', userId);
      dbError(updated.error);
    } else {
      const inserted = await db.from('cashflow_ai_memories').insert({ user_id: userId, kind: input.kind, value: input.value, source: input.source, updated_at: now }).select('id').single();
      dbError(inserted.error);
      memoryId = inserted.data?.id as string | undefined;
    }
    await memoryEvents(userId, [{ memory_id: memoryId ?? null, action: input.replace ? 'updated' : 'created', kind: input.kind,
      old_value: input.replace?.value ?? null, new_value: input.value, channel: input.channel }]);
    // Over the limit, the least recently used go (never the communication preferences).
    for (const row of input.evict ?? []) {
      const removed = await db.from('cashflow_ai_memories').delete().eq('id', row.id).eq('user_id', userId);
      if (!removed.error) await memoryEvents(userId, [{ memory_id: row.id, action: 'expired', kind: row.kind, old_value: null, new_value: null, channel: input.channel }]);
    }
    return memoryId ?? null;
  },
  async forgetMemories(userId, rows, channel) {
    if (!rows.length) return 0;
    const db = getSupabaseAdmin();
    const ids = rows.map(row => row.id);
    const removed = await db.from('cashflow_ai_memories').delete().eq('user_id', userId).in('id', ids);
    dbError(removed.error);
    // The user asked to forget: earlier versions of these memories lose their text too.
    await db.from('cashflow_ai_memory_events').update({ old_value: null, new_value: null }).eq('user_id', userId).in('memory_id', ids);
    await memoryEvents(userId, rows.map(row => ({ memory_id: row.id, action: 'deleted' as const, kind: row.kind, old_value: null, new_value: null, channel })));
    return ids.length;
  },
  async touchMemories(userId, ids) {
    if (!ids.length) return;
    await getSupabaseAdmin().rpc('cashflow_ai_memories_touch', { p_user_id: userId, p_ids: ids }).then(() => undefined, () => undefined);
  },
};
