import { inFreeTrial } from '../../../shared/trial.js';
import type { User } from '@supabase/supabase-js';
import { getSupabaseAdmin } from '../config/supabase.js';
import { HttpError } from '../http/guard.js';
import { accountSnapshot } from '../repositories/accounts.js';
import { systemRole } from '../repositories/roles.js';
import type { UserRow } from '../services/lineAssistant.js';
import type { AssistantDb, PlanInfo, StoredProposal } from './service.js';

// AssistantDb on Supabase, using database/ai_secretary.sql (tables cashflow_ai_*). Until the owner runs that file,
// every call here answers 503 with a plain message instead of failing silently.


function dbError(error: { code?: string; message?: string } | null): void {
  if (!error) return;
  // PostgREST: table or function missing (database/ai_secretary.sql not run yet).
  if (['PGRST202', 'PGRST205', '42P01', '42883'].includes(error.code || '')) {
    throw new HttpError(503, 'เลขากระรอกต้องอัปเดตฐานข้อมูลก่อน (ai_secretary.sql)', 'ai_db_missing');
  }
  throw error;
}

/** Same rule as hasProAccess (services/vault.ts) with the trial and admins told apart. Fails closed. */
export async function assistantPlan(user: User, now = Date.now()): Promise<PlanInfo> {
  const [{ data: sub, error }, role] = await Promise.all([
    getSupabaseAdmin().from('subscriptions').select('status, plan, current_period_end').eq('user_id', user.id).maybeSingle(),
    systemRole(user.id),
  ]);
  if (error) throw error;
  if (role === 'admin') return { plan: 'admin' };
  if (sub?.plan === 'admin_revoked' || sub?.plan === 'admin_removed') return { plan: 'none' };
  if (sub?.status === 'active' && sub.plan === 'admin_grant') return { plan: 'pro' };
  // Paid Pro: tokens renew monthly on the renewal day of current_period_end.
  if (sub?.status === 'active' && sub.current_period_end && new Date(sub.current_period_end).getTime() > now) {
    return { plan: 'pro', periodEnd: sub.current_period_end };
  }
  const trial = inFreeTrial(user.created_at, now);
  return { plan: trial ? 'trial' : 'none' };
}

type ProposalRow = { id: string; user_id: string; kind: StoredProposal['kind']; job_id: string; record: Record<string, unknown> | null; base_version: number | null; title: string; changes: StoredProposal['changes']; created_at: string };
const fromRow = (row: ProposalRow): StoredProposal => ({
  id: row.id, userId: row.user_id, kind: row.kind, jobId: row.job_id, record: row.record, baseVersion: row.base_version,
  title: row.title, changes: row.changes, createdAt: new Date(row.created_at).getTime(),
});

export const supabaseAssistantDb: AssistantDb = {
  async loadAccount(userId) {
    const snapshot = await accountSnapshot(userId);
    const versions = (snapshot.versions?.cashflow_jobs || {}) as Record<string, number>;
    return { user: snapshot as unknown as UserRow, versions };
  },
  async reserve(input) {
    const { data, error } = await getSupabaseAdmin().rpc('cashflow_ai_reserve', {
      p_user_id: input.userId, p_cycle: input.cycle, p_request_id: input.requestId, p_tokens: input.tokens,
      p_token_limit: input.tokenLimit, p_request_limit: input.requestLimit, p_daily_cap_usd: input.dailyCapUsd,
    });
    dbError(error);
    const result = data as { ok: boolean; reason?: 'tokens' | 'requests' | 'daily_cap'; used_tokens?: number; used_requests?: number };
    return result.ok ? { ok: true, usedTokens: Number(result.used_tokens || 0), usedRequests: Number(result.used_requests || 0) } : { ok: false, reason: result.reason || 'tokens' };
  },
  async settle(input) {
    const { error } = await getSupabaseAdmin().rpc('cashflow_ai_settle', {
      p_user_id: input.userId, p_request_id: input.requestId, p_tokens: input.tokens, p_cost_usd: input.costUsd,
      p_model: input.model, p_route: input.route, p_prompt_version: input.promptVersion, p_release: input.release,
    });
    dbError(error);
  },
  async usage(userId, cycle) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_usage').select('tokens')
      .eq('user_id', userId).eq('cycle_key', cycle).in('status', ['reserved', 'settled']);
    dbError(error);
    const rows = (data || []) as { tokens: number }[];
    return { tokens: rows.reduce((sum, row) => sum + Number(row.tokens || 0), 0), requests: rows.length };
  },
  async saveProposal(proposal) {
    const { error } = await getSupabaseAdmin().from('cashflow_ai_proposals').insert({
      id: proposal.id, user_id: proposal.userId, kind: proposal.kind, job_id: proposal.jobId, record: proposal.record,
      base_version: proposal.baseVersion, title: proposal.title, changes: proposal.changes,
    });
    dbError(error);
  },
  async claimProposal(userId, id) {
    const { data, error } = await getSupabaseAdmin().rpc('cashflow_ai_claim_proposal', { p_user_id: userId, p_id: id });
    dbError(error);
    const rows = (data || []) as ProposalRow[];
    return rows[0] ? fromRow(rows[0]) : null;
  },
  async finishProposal(userId, id, status) {
    const { error } = await getSupabaseAdmin().from('cashflow_ai_proposals')
      .update({ status, ...(status === 'applied' ? { applied_at: new Date().toISOString() } : {}) })
      .eq('id', id).eq('user_id', userId).eq('status', 'applying');
    dbError(error);
  },
  async cancelProposal(userId, id) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_proposals').update({ status: 'cancelled' })
      .eq('id', id).eq('user_id', userId).eq('status', 'pending').select('id');
    dbError(error);
    return Boolean(data?.length);
  },
  async applyChanges(userId, changes) {
    const { data, error } = await getSupabaseAdmin().rpc('cashflow_apply_changes', { p_user_id: userId, p_changes: changes });
    if (error?.code === '40001') return false;
    dbError(error);
    // false = the job changed since the version the AI read; null = older SQL that returns void.
    return data !== false;
  },
  async memories(userId) {
    const { data, error } = await getSupabaseAdmin().from('cashflow_ai_memories').select('kind, value')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(20);
    // Memory is a nicety: if it cannot be read, the assistant still answers.
    if (error) return [];
    return (data || []) as { kind: string; value: string }[];
  },
  async remember(userId, kind, value, limit) {
    const db = getSupabaseAdmin();
    if (kind === 'preferred_name' || kind === 'tone') {
      const removed = await db.from('cashflow_ai_memories').delete().eq('user_id', userId).eq('kind', kind);
      dbError(removed.error);
    }
    const inserted = await db.from('cashflow_ai_memories').insert({ user_id: userId, kind, value });
    dbError(inserted.error);
    const { data } = await db.from('cashflow_ai_memories').select('id').eq('user_id', userId).order('created_at', { ascending: false });
    const extra = (data || []).slice(limit).map(row => row.id as string);
    if (extra.length) await db.from('cashflow_ai_memories').delete().in('id', extra);
  },
};
