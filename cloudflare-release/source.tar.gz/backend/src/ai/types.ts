// เลขากระรอก AI Gateway: the shapes every part of the gateway shares. Nothing here calls a provider.

export type Route = 'chat' | 'action';
export type ProviderName = 'gemini' | 'openai';
export type Effort = 'minimal' | 'low' | 'medium';

/** `attachment`: a picture or PDF sent with this one user turn (never stored). */
export interface ChatTurn { role: 'user' | 'assistant'; text: string; attachment?: { name: string; mimeType: string; data: string } }

/** A tool as the models see it: a name, what it is for, and a JSON-Schema object for its arguments. */
export interface ToolSpec {
  name: string;
  description: string;
  parameters: { type: 'object'; properties: Record<string, unknown>; required?: string[] };
}

export interface ToolCall { id: string; name: string; args: Record<string, unknown> }

/** What a tool hands back: the data the model reads, plus anything the chat screen should draw. */
export interface ToolOutcome {
  result: unknown;
  /** A card for the chat (same kinds the screen already draws: summary, project, document, confirm). */
  card?: AssistantCard;
  /** More cards from the same tool call (several documents found). */
  extraCards?: AssistantCard[];
  /** Set by route_to_action: the chat model asks the gateway to hand the request to the action model. */
  handoff?: string;
}

export type AssistantCard =
  | { kind: 'summary'; period: string; income: string; expense: string; balance: string }
  | { kind: 'project'; name: string; client: string; amount: string; status: string }
  | { kind: 'document'; docType: string; number: string; client: string; amount: string; path: string }
  | { kind: 'navigation'; label: string; path: string; autoOpen: boolean }
  | { kind: 'confirm'; id: string; title: string; changes: { label: string; value: string }[] };

export interface Usage { inputTokens: number; cachedInputTokens: number; outputTokens: number; thinkingTokens: number }

export interface ProviderRequest {
  apiKey: string;
  model: string;
  system: string;
  turns: ChatTurn[];
  tools: ToolSpec[];
  maxOutputTokens: number;
  effort?: Effort;
  execute: (call: ToolCall) => Promise<ToolOutcome>;
  /** Tool rounds before the gateway stops the loop (each round is one more paid call). */
  maxSteps?: number;
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}

export interface ProviderResult {
  provider: ProviderName;
  model: string;
  text: string;
  usage: Usage;
  toolCalls: { name: string; args: unknown }[];
  cards: AssistantCard[];
  handoff?: string;
  steps: number;
  stoppedAt?: 'max_steps';
}

export interface Provider {
  name: ProviderName;
  run(request: ProviderRequest): Promise<ProviderResult>;
}

/** A provider answered with an error the gateway should surface as "try again" (never a success). */
export class ProviderError extends Error {
  constructor(message: string, readonly status: number, readonly provider: ProviderName, readonly retryable: boolean) { super(message); }
}

export const emptyUsage = (): Usage => ({ inputTokens: 0, cachedInputTokens: 0, outputTokens: 0, thinkingTokens: 0 });
export const addUsage = (a: Usage, b: Usage): Usage => ({
  inputTokens: a.inputTokens + b.inputTokens,
  cachedInputTokens: a.cachedInputTokens + b.cachedInputTokens,
  outputTokens: a.outputTokens + b.outputTokens,
  thinkingTokens: a.thinkingTokens + b.thinkingTokens,
});
