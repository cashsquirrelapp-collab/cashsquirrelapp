import type { UserRow } from '../services/lineAssistant.js';
import type { AiConfig } from './config.js';
import { costUsd, krarokTokens } from './cost.js';
import { knowledgeSnippets, lookupKnowledge } from './knowledge.js';
import { PROMPT_VERSION, bangkokNow, buildSystemPrompt, type PromptSlots } from './prompt.js';
import { geminiProvider } from './providers/gemini.js';
import { openaiProvider } from './providers/openai.js';
import { routeMessage } from './router.js';
import { accountContext, createToolbox, toolsFor, type MemoryStore, type ProposalStore } from './tools.js';
import type { AssistantCard, ChatTurn, Effort, Provider, ProviderName, ProviderResult, Route, ToolCall, ToolOutcome, Usage } from './types.js';
import type { VaultLoader } from './vaultQueries.js';

// One request to เลขากระรอก: pick the model, build the prompt, run the model with the account's tools, and
// hand over from the chat model to the action model when the user wants something done. Returns the reply,
// the cards to draw and what it cost. Nothing is saved here except what the user asked to be remembered;
// changes come back as proposals the user confirms.

const MAX_HISTORY_TURNS = 12;
const MAX_TURN_CHARS = 2000;

export class AiUnavailableError extends Error {
  constructor(readonly reason: 'disabled' | 'missing_key') { super(`AI unavailable: ${reason}`); }
}

export interface AssistantRequest {
  user: UserRow;
  plan: PromptSlots['plan'];
  text: string;
  /** Earlier turns of this conversation, oldest first (the gateway keeps only the most recent ones). */
  history?: ChatTurn[];
  hasAttachment?: boolean;
  /** A picture or PDF with this message (checked by attachment.ts); it goes to the action model. */
  attachment?: { name: string; mimeType: string; data: string };
  pendingConfirmation?: boolean;
  pageName?: string;
  channel?: 'app' | 'line';
  preferredName?: string;
  communicationProfile?: string;
  memories?: string[];
  trialLeft?: number;
  tokensLeft?: number;
  /** Verified subscription/token-cycle metadata, supplied by the server, never by a chat body. */
  access?: { period_end: string | null; tokens_reset_at: string | null; token_limit: number | null };
  /** Skip the router (the model comparison runs each case on a fixed route). */
  forceRoute?: Route;
}

export interface AssistantDependencies {
  config: AiConfig;
  proposals: ProposalStore;
  memory: MemoryStore;
  loadVaultFiles?: VaultLoader;
  providers?: Partial<Record<ProviderName, Provider>>;
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
  now?: Date;
  /** Sees every tool call and its result (the model comparison uses it to check figures against the data). */
  observe?: (call: ToolCall, outcome: ToolOutcome) => void;
}

export interface ModelCall {
  route: Route;
  provider: ProviderName;
  model: string;
  usage: Usage;
  costUsd: number;
  steps: number;
  toolCalls: { name: string; args: unknown }[];
  stoppedAt?: 'max_steps';
}

export interface AssistantReply {
  route: Route;
  handedOff: boolean;
  text: string;
  cards: AssistantCard[];
  calls: ModelCall[];
  costUsd: number;
  /** Krarok Tokens to charge for this request. */
  tokens: number;
  promptVersion: string;
}

const providerFor = (model: string): ProviderName => (/^gemini/i.test(model) ? 'gemini' : 'openai');

const FALLBACK_TEXT = {
  max_steps: 'ขออภัยครับ คำขอนี้มีหลายขั้นตอนเกินกว่าจะทำในครั้งเดียว ลองแยกเป็นคำขอสั้น ๆ ทีละเรื่องได้ไหมครับ',
  proposal_at_limit: 'เตรียมรายการที่แสดงบนการ์ดให้ตรวจแล้วครับ ยังไม่ได้บันทึก กรุณาตรวจรายละเอียดก่อนกดยืนยัน หากขอหลายอย่าง ให้ตรวจว่าการ์ดครอบคลุมครบก่อนครับ',
  empty: 'ขออภัยครับ ตอนนี้ยังตอบไม่ได้ ลองพิมพ์ใหม่อีกครั้งนะครับ',
};

function trimHistory(history: ChatTurn[] = []): ChatTurn[] {
  return history.slice(-MAX_HISTORY_TURNS).map(turn => ({ role: turn.role, text: turn.text.slice(0, MAX_TURN_CHARS) }));
}

export async function runAssistant(request: AssistantRequest, deps: AssistantDependencies): Promise<AssistantReply> {
  const { config } = deps;
  if (!config.enabled) throw new AiUnavailableError('disabled');

  const providers: Record<ProviderName, Provider> = { gemini: geminiProvider, openai: openaiProvider, ...deps.providers };
  const keys: Record<ProviderName, string | undefined> = { gemini: config.geminiKey, openai: config.openaiKey };
  const modelFor = (route: Route) => (route === 'chat' ? config.chatModel : config.actionModel);
  const firstRoute = request.forceRoute ?? routeMessage({ text: request.text, hasAttachment: request.hasAttachment || Boolean(request.attachment), pendingConfirmation: request.pendingConfirmation });
  // Both keys are checked up front: a chat request can hand over to the action model mid-request.
  for (const route of firstRoute === 'chat' ? ['chat', 'action'] as const : ['action'] as const) {
    if (!keys[providerFor(modelFor(route))]) throw new AiUnavailableError('missing_key');
  }

  const toolbox = createToolbox({ user: request.user, proposals: deps.proposals, memory: deps.memory, loadVaultFiles: deps.loadVaultFiles, now: deps.now,
    isAdmin: request.plan === 'admin', requestText: request.text });
  const knowledge = knowledgeSnippets(lookupKnowledge(request.text, 3));
  const context = accountContext(request.user, deps.now, request.access);
  const turns: ChatTurn[] = [...trimHistory(request.history), { role: 'user', text: request.text.slice(0, MAX_TURN_CHARS), ...(request.attachment ? { attachment: request.attachment } : {}) }];

  const timeout = AbortSignal.timeout(config.timeoutMs);
  const signal = deps.signal ? AbortSignal.any([deps.signal, timeout]) : timeout;

  const calls: ModelCall[] = [];
  const cards: AssistantCard[] = [];
  let lastEditError: string | undefined;

  const run = async (route: Route, handoff?: string): Promise<ProviderResult> => {
    lastEditError = undefined;
    const availableTools = toolsFor(route);
    const allowed = new Set(availableTools.map(tool => tool.name));
    const execute = async (call: ToolCall) => {
      const outcome = allowed.has(call.name) ? await toolbox(call) : { result: { ok: false, error: 'เครื่องมือนี้ไม่เปิดให้ใช้ในคำขอนี้' } };
      // This edit tool returns local validation messages, never provider text or raw service errors.
      // Preserve the last actionable failure at the budget boundary without buying another turn.
      // A later tool result clears it, so an earlier, already-resolved failure cannot leak through.
      const validation = outcome.result as { ok?: unknown; error?: unknown } | null;
      lastEditError = allowed.has(call.name) && call.name === 'propose_edit_job'
        && validation?.ok === false && typeof validation.error === 'string'
        ? validation.error.slice(0, 1200) : undefined;
      deps.observe?.(call, outcome);
      return outcome;
    };
    const model = modelFor(route);
    const name = providerFor(model);
    const system = buildSystemPrompt({
      route, plan: request.plan, trialLeft: request.trialLeft, tokensLeft: request.tokensLeft,
      preferredName: request.preferredName, communicationProfile: request.communicationProfile, memories: request.memories,
      nowLocal: bangkokNow(deps.now), pageName: request.pageName, channel: request.channel, knowledge, accountContext: context,
    }) + (handoff ? `\n\nHANDOVER FROM THE CONVERSATION ASSISTANT: ${handoff}` : '');
    // Gemini Flash-Lite thinks least by default; the action model reasons a little before changing data.
    const effort: Effort = route === 'chat' && name === 'gemini' ? 'minimal' : 'low';
    const result = await providers[name].run({
      apiKey: keys[name]!, model, system, turns, tools: availableTools,
      maxOutputTokens: config.maxOutputTokens[route], effort, execute,
      maxSteps: config.maxToolSteps, signal, fetchImpl: deps.fetchImpl,
    });
    calls.push({ route, provider: name, model, usage: result.usage, costUsd: costUsd(name, model, result.usage), steps: result.steps, toolCalls: result.toolCalls, ...(result.stoppedAt ? { stoppedAt: result.stoppedAt } : {}) });
    cards.push(...result.cards);
    return result;
  };

  let result = await run(firstRoute);
  let handedOff = false;
  if (firstRoute === 'chat' && result.handoff !== undefined) {
    handedOff = true;
    result = await run('action', result.handoff || request.text);
  }

  const text = result.text.trim()
    || (result.stoppedAt === 'max_steps'
      ? cards.some(card => card.kind === 'confirm') ? FALLBACK_TEXT.proposal_at_limit : lastEditError || FALLBACK_TEXT.max_steps
      : cards.length ? '' : FALLBACK_TEXT.empty);
  const total = calls.reduce((sum, call) => sum + call.costUsd, 0);
  return {
    route: handedOff ? 'action' : firstRoute, handedOff, text, cards, calls,
    costUsd: total, tokens: krarokTokens(total, config.tokenUsd), promptVersion: PROMPT_VERSION,
  };
}

/** Proposals and memories kept in memory: for tests and the model comparison (the handler uses the database). */
export function memoryStores() {
  const proposals = new Map<string, import('./tools.js').Proposal>();
  const remembered: { userId: string; kind: string; value: string }[] = [];
  return {
    proposals: { async save(proposal) { proposals.set(proposal.id, proposal); } } as ProposalStore,
    memory: { async remember(userId, kind, value) { remembered.push({ userId, kind, value }); } } as MemoryStore,
    saved: proposals,
    remembered,
  };
}
