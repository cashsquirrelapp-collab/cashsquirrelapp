import type { UserRow } from '../services/lineAssistant.js';
import type { AiConfig } from './config.js';
import { costUsd, krarokTokens } from './cost.js';
import { knowledgeSnippets, lookupKnowledge } from './knowledge.js';
import { PROMPT_VERSION, bangkokNow, buildSystemPrompt, type PromptSlots } from './prompt.js';
import { geminiProvider } from './providers/gemini.js';
import { openaiProvider } from './providers/openai.js';
import { anthropicProvider } from './providers/anthropic.js';
import { needsSmartModel } from './difficulty.js';
import { routeMessage } from './router.js';
import { accountContext, createToolbox, toolsFor, type MemoryStore, type ProposalStore } from './tools.js';
import { emptyUsage, ProviderError, subtractUsage, type AssistantCard, type ChatTurn, type Effort, type Provider, type ProviderName, type ProviderResult, type Route, type ToolCall, type ToolOutcome, type Usage } from './types.js';
import type { VaultLoader } from './vaultQueries.js';

// One request to เลขากระรอก: pick the model, build the prompt, run the model with the account's tools, and
// hand over from the chat model to the action model when the user wants something done. Returns the reply,
// the cards to draw and what it cost. Nothing is saved here except what the user asked to be remembered;
// changes come back as proposals the user confirms.

const MAX_HISTORY_TURNS = 12;
const MAX_TURN_CHARS = 2000;
/** The message being answered may be long (a pasted list, owner 2026-10-24); earlier turns stay short. */
export const MAX_MESSAGE_CHARS = 6000;

export class AiUnavailableError extends Error {
  constructor(readonly reason: 'disabled' | 'missing_key') { super(`AI unavailable: ${reason}`); }
}

export interface AssistantRequest {
  user: UserRow;
  plan: PromptSlots['plan'];
  text: string;
  /** Earlier turns of this conversation, oldest first (the gateway keeps only the most recent ones). */
  history?: ChatTurn[];
  hasAttachment?: boolean;
  /** A picture or PDF with this message (checked by attachment.ts); it goes to the action model. */
  attachment?: { name: string; mimeType: string; data: string };
  pendingConfirmation?: boolean;
  pageName?: string;
  channel?: 'app' | 'line';
  preferredName?: string;
  communicationProfile?: string;
  memories?: string[];
  trialLeft?: number;
  tokensLeft?: number;
  /** Verified subscription/token-cycle metadata, supplied by the server, never by a chat body. */
  access?: { period_end: string | null; tokens_reset_at: string | null; token_limit: number | null };
  /** Skip the router (the model comparison runs each case on a fixed route). */
  forceRoute?: Route;
}

export interface AssistantDependencies {
  config: AiConfig;
  proposals: ProposalStore;
  memory: MemoryStore;
  loadVaultFiles?: VaultLoader;
  providers?: Partial<Record<ProviderName, Provider>>;
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
  now?: Date;
  /** Sees every tool call and its result (the model comparison uses it to check figures against the data). */
  observe?: (call: ToolCall, outcome: ToolOutcome) => void;
}

export interface ModelCall {
  route: Route;
  provider: ProviderName;
  model: string;
  usage: Usage;
  costUsd: number;
  steps: number;
  toolCalls: { name: string; args: unknown }[];
  stoppedAt?: 'max_steps' | 'budget';
}

export interface AssistantReply {
  route: Route;
  handedOff: boolean;
  text: string;
  cards: AssistantCard[];
  calls: ModelCall[];
  costUsd: number;
  /** Krarok Tokens to charge for this request. */
  tokens: number;
  promptVersion: string;
  /** What an attached file shows (note_from_file), for the chat to send with its later messages. */
  memo?: string;
}

const providerFor = (model: string): ProviderName => (/^gemini/i.test(model) ? 'gemini' : /^claude/i.test(model) ? 'anthropic' : 'openai');

const FALLBACK_TEXT = {
  // Never ask the owner to send it one step at a time (owner, 2026-10-24: "บอกทีละขั้นตอน ... มันก็เสียเวลา").
  max_steps: 'ขออภัยครับ คำขอนี้ยังทำไม่เสร็จในรอบเดียว ลองบอกชื่องานหรือลูกค้าให้ชัดขึ้นอีกนิดได้ไหมครับ',
  proposal_at_limit: 'เตรียมรายการที่แสดงบนการ์ดให้ตรวจแล้วครับ ยังไม่ได้บันทึก กรุณาตรวจรายละเอียดก่อนกดยืนยัน หากขอหลายอย่าง ให้ตรวจว่าการ์ดครอบคลุมครบก่อนครับ',
  empty: 'ขออภัยครับ ตอนนี้ยังตอบไม่ได้ ลองพิมพ์ใหม่อีกครั้งนะครับ',
};

function trimHistory(history: ChatTurn[] = []): ChatTurn[] {
  return history.slice(-MAX_HISTORY_TURNS).map(turn => ({ role: turn.role, text: turn.text.slice(0, MAX_TURN_CHARS) }));
}

// A questions card reaches the history as "- question" lines after เลขา's text (assistantApi).
const ASKS = /(\?|ไหม|มั้ย|หรือเปล่า|หรือไม่|รบกวน|ขอ(?:ข้อมูล|ชื่อ|วันที่|รายละเอียด)|ระบุ|แจ้ง|\n- )/;
/** A file was sent earlier in the chat (assistantApi marks it, and puts what was read from it before เลขา's answer). */
export const FILE_MARK = /\[(?:แนบไฟล์|อ่านจากไฟล์ที่แนบ)/;
/**
 * This message answers questions that came out of hard work: walking back while เลขา's turns are questions, a user
 * turn in that run needed the smart model or sent a file. Owner, 2026-10-24: a quotation started with a picture went
 * back to the light model on the second answer and asked again for the client the picture showed.
 */
function continuesSmartWork(history: ChatTurn[] = []): boolean {
  let asked = false;
  for (let index = history.length - 1; index >= Math.max(0, history.length - MAX_HISTORY_TURNS); index--) {
    const turn = history[index];
    if (turn.role === 'assistant') {
      if (!ASKS.test(turn.text.replace(/^\[อ่านจากไฟล์ที่แนบ:[\s\S]*?\]\n/, ''))) return false;
      if (FILE_MARK.test(turn.text)) return true;
      asked = true;
    } else if (asked && (needsSmartModel(turn.text) || FILE_MARK.test(turn.text))) return true;
  }
  return false;
}

export async function runAssistant(request: AssistantRequest, deps: AssistantDependencies): Promise<AssistantReply> {
  const { config } = deps;
  if (!config.enabled) throw new AiUnavailableError('disabled');

  const providers: Record<ProviderName, Provider> = { gemini: geminiProvider, openai: openaiProvider, anthropic: anthropicProvider, ...deps.providers };
  const keys: Record<ProviderName, string | undefined> = { gemini: config.geminiKey, openai: config.openaiKey, anthropic: config.anthropicKey };
  // Hard requests (difficulty.ts) go to the smart model when it is set and its key exists (owner, 2026-10-24:
  // Sonnet 5.5 only for hard work); everything else, and every request while the key is missing, stays light.
  // A reply to the smart model's own question stays with it (2026-10-24: the owner's address and tax ID, sent after
  // Sonnet asked for the quotation's issuer, went to Gemini and came back empty).
  const smartReady = Boolean(config.smartModel && keys[providerFor(config.smartModel)]);
  let smart = smartReady && (needsSmartModel(request.text, { hasAttachment: request.hasAttachment || Boolean(request.attachment) })
    || continuesSmartWork(request.history)) ? config.smartModel : undefined;
  const lightModel = (route: Route) => route === 'chat' ? config.chatModel : config.actionModel;
  const modelFor = (route: Route) => smart ?? lightModel(route);
  const firstRoute = request.forceRoute ?? routeMessage({ text: request.text, hasAttachment: request.hasAttachment || Boolean(request.attachment), pendingConfirmation: request.pendingConfirmation });
  // Both keys are checked up front: a chat request can hand over to the action model mid-request. The light
  // models are the ones checked, because a hard request falls back to them when the smart model fails.
  for (const route of firstRoute === 'chat' ? ['chat', 'action'] as const : ['action'] as const) {
    if (!keys[providerFor(lightModel(route))]) throw new AiUnavailableError('missing_key');
  }

  const toolbox = createToolbox({ user: request.user, proposals: deps.proposals, memory: deps.memory, loadVaultFiles: deps.loadVaultFiles, now: deps.now,
    isAdmin: request.plan === 'admin', requestText: request.text, hasAttachment: Boolean(request.attachment) });
  const memos: string[] = [];
  const knowledge = knowledgeSnippets(lookupKnowledge(request.text, 3));
  const context = accountContext(request.user, deps.now, request.access);
  const turns: ChatTurn[] = [...trimHistory(request.history), { role: 'user', text: request.text.slice(0, MAX_MESSAGE_CHARS), ...(request.attachment ? { attachment: request.attachment } : {}) }];

  const timeout = AbortSignal.timeout(config.timeoutMs);
  const signal = deps.signal ? AbortSignal.any([deps.signal, timeout]) : timeout;

  const calls: ModelCall[] = [];
  const cards: AssistantCard[] = [];
  let lastEditError: string | undefined;
  // Per-message ceiling (owner, 2026-10-24: 100 Krarok Tokens a message). Before each further tool round the loop
  // stops if the cost so far plus one more round like the last would pass it; the cards prepared so far stay.
  const ceilingUsd = config.messageTokenCap * config.tokenUsd;
  const spentBefore = () => calls.reduce((sum, call) => sum + call.costUsd, 0);

  const run = async (route: Route, handoff?: string): Promise<ProviderResult> => {
    lastEditError = undefined;
    const availableTools = toolsFor(route);
    const allowed = new Set(availableTools.map(tool => tool.name));
    const execute = async (call: ToolCall) => {
      const outcome = allowed.has(call.name) ? await toolbox(call) : { result: { ok: false, error: 'เครื่องมือนี้ไม่เปิดให้ใช้ในคำขอนี้' } };
      if ('memo' in outcome && outcome.memo && !memos.includes(outcome.memo)) memos.push(outcome.memo);
      // This edit tool returns local validation messages, never provider text or raw service errors.
      // Preserve the last actionable failure at the budget boundary without buying another turn.
      // A later tool result clears it, so an earlier, already-resolved failure cannot leak through.
      const validation = outcome.result as { ok?: unknown; error?: unknown } | null;
      lastEditError = allowed.has(call.name) && call.name === 'propose_edit_job'
        && validation?.ok === false && typeof validation.error === 'string'
        ? validation.error.slice(0, 1200) : undefined;
      deps.observe?.(call, outcome);
      return outcome;
    };
    const model = modelFor(route);
    const name = providerFor(model);
    const system = buildSystemPrompt({
      route, plan: request.plan, trialLeft: request.trialLeft, tokensLeft: request.tokensLeft,
      preferredName: request.preferredName, communicationProfile: request.communicationProfile, memories: request.memories,
      nowLocal: bangkokNow(deps.now), pageName: request.pageName, channel: request.channel, knowledge, accountContext: context,
    }) + (handoff ? `\n\nHANDOVER FROM THE CONVERSATION ASSISTANT: ${handoff}` : '');
    // Gemini Flash-Lite thinks least by default; the action model reasons a little before changing data.
    // Claude reasons more on changes (medium) and answers questions at low effort.
    const effort: Effort = name === 'anthropic' ? (route === 'chat' ? 'low' : 'medium') : route === 'chat' && name === 'gemini' ? 'minimal' : 'low';
    // The next round is estimated from the last one with its cache writes priced as reads: the shared rules are
    // written once (the first request of an hour) and read on every round after it.
    let previous = emptyUsage();
    const overBudget = (usage: Usage) => {
      const last = subtractUsage(usage, previous);
      previous = usage;
      const next = costUsd(name, model, { ...last, cachedInputTokens: last.cachedInputTokens + (last.cacheWriteTokens || 0), cacheWriteTokens: 0, cacheWrite1hTokens: 0 });
      return spentBefore() + costUsd(name, model, usage) + next > ceilingUsd;
    };
    const result = await providers[name].run({
      apiKey: keys[name]!, model, system, turns, tools: availableTools,
      maxOutputTokens: config.maxOutputTokens[route], effort, execute,
      maxSteps: config.maxToolSteps, signal, fetchImpl: deps.fetchImpl, overBudget,
    });
    calls.push({ route, provider: name, model: result.model || model, usage: result.usage, costUsd: costUsd(name, model, result.usage), steps: result.steps, toolCalls: result.toolCalls, ...(result.stoppedAt ? { stoppedAt: result.stoppedAt } : {}) });
    cards.push(...result.cards);
    return result;
  };

  // The smart model failing (credit used up, a wrong key, an outage) never stops เลขา: while time is left, the same
  // request is answered again by the light model. Cards from the failed attempt are dropped with it; their saved
  // proposals expire unconfirmed after 30 minutes.
  const attempt = async (route: Route, handoff?: string): Promise<ProviderResult> => {
    if (!smart) return run(route, handoff);
    try { return await run(route, handoff); }
    catch (error) {
      if (!(error instanceof ProviderError) || signal.aborted) throw error;
      console.warn('ai: smart model failed, the light model answers', { model: smart, status: error.status });
      smart = undefined;
      return run(route, handoff);
    }
  };

  let result = await attempt(firstRoute);
  let handedOff = false;
  if (firstRoute === 'chat' && result.handoff !== undefined) {
    handedOff = true;
    result = await attempt('action', result.handoff || request.text);
  }
  // The light model sometimes ends with no text and no card. While time is left, the smart model answers once more
  // instead of the user seeing "ตอนนี้ยังตอบไม่ได้".
  if (!result.text.trim() && !cards.length && !result.stoppedAt && !smart && smartReady && !signal.aborted) {
    smart = config.smartModel;
    result = await attempt(handedOff ? 'action' : firstRoute, handedOff ? request.text : undefined);
  }

  const text = result.text.trim()
    || (result.stoppedAt
      ? cards.some(card => card.kind === 'confirm') ? FALLBACK_TEXT.proposal_at_limit : lastEditError || FALLBACK_TEXT.max_steps
      : cards.length ? '' : FALLBACK_TEXT.empty);
  const total = calls.reduce((sum, call) => sum + call.costUsd, 0);
  return {
    route: handedOff ? 'action' : firstRoute, handedOff, text, cards, calls,
    // A rare message that still ends above the ceiling (its last round) is charged the ceiling; the app pays the rest.
    costUsd: total, tokens: Math.min(krarokTokens(total, config.tokenUsd), config.messageTokenCap), promptVersion: PROMPT_VERSION,
    ...(memos.length ? { memo: memos.join('\n').slice(0, 1500) } : {}),
  };
}

/** Proposals and memories kept in memory: for tests and the model comparison (the handler uses the database). */
export function memoryStores() {
  const proposals = new Map<string, import('./tools.js').Proposal>();
  const remembered: { userId: string; kind: string; value: string }[] = [];
  return {
    proposals: { async save(proposal) { proposals.set(proposal.id, proposal); } } as ProposalStore,
    memory: { async remember(userId, kind, value) { remembered.push({ userId, kind, value }); } } as MemoryStore,
    saved: proposals,
    remembered,
  };
}
