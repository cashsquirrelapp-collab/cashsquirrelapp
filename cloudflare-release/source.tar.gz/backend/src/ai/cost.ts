import type { ProviderName, Usage } from './types.js';

// Real API cost per request, from the providers' published prices (checked 2026-10-24; see
// artifacts/ai-secretary/06-api-research.md). USD per 1M tokens. A model not listed here is charged at the
// most expensive listed rate, so an unknown model can never look cheaper than it is.
export const PRICES: Record<string, { input: number; cachedInput: number; output: number }> = {
  'gemini-3.1-flash-lite': { input: 0.25, cachedInput: 0.025, output: 1.5 },
  'gemini-3.5-flash-lite': { input: 0.3, cachedInput: 0.03, output: 2.5 },
  'gpt-5.4-mini': { input: 0.75, cachedInput: 0.075, output: 4.5 },
  'gpt-5.4-nano': { input: 0.2, cachedInput: 0.02, output: 1.25 },
};
const FALLBACK = { input: 2.5, cachedInput: 0.25, output: 15 };

/**
 * Gemini reports thinking separately from the answer (both billed as output); OpenAI's output count already
 * includes its reasoning tokens. Cached input is part of the input count for both.
 */
export function costUsd(provider: ProviderName, model: string, usage: Usage): number {
  const price = PRICES[model] ?? FALLBACK;
  const fresh = Math.max(0, usage.inputTokens - usage.cachedInputTokens);
  const output = provider === 'gemini' ? usage.outputTokens + usage.thinkingTokens : usage.outputTokens;
  return (fresh * price.input + usage.cachedInputTokens * price.cachedInput + output * price.output) / 1_000_000;
}

/** Krarok Tokens for a request: its real cost divided by the configured rate, rounded up, at least 1. */
export function krarokTokens(cost: number, tokenUsd: number): number {
  return Math.max(1, Math.ceil(cost / tokenUsd - 1e-9));
}
