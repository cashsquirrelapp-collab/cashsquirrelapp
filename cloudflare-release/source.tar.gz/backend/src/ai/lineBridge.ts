import { HttpError } from '../http/guard.js';
import type { LineMessage } from '../services/line.js';
import { lineAppLink, lineCard, lineValueRow } from '../services/lineCards.js';
import type { UserRow } from '../services/lineAssistant.js';
import { aiConfig } from './config.js';
import { lineAssistantReply } from './lineFormat.js';
import { confirmProposal, handleMessage } from './service.js';
import { assistantPlanForUserId, supabaseAssistantDb } from './supabaseDb.js';
import type { ChatTurn } from './types.js';

// LINE talks to the same เลขากระรอก as the app: the same Gemini, rules, tools and Krarok Tokens (one pool per
// account), with answers shaped for LINE (lineFormat.ts). The LINE handler has already checked the account
// link, its lifecycle and Pro before calling here.

export interface LineAnswer { messages: LineMessage[]; text: string }

/** The AI's answer, or null when the real เลขา is not on for this account (the handler keeps its old behaviour). */
export async function lineAssistantAnswer(user: UserRow, text: string, history: ChatTurn[]): Promise<LineAnswer | null> {
  const config = aiConfig(process.env);
  if (!config.enabled) return null;
  const plan = await assistantPlanForUserId(user.user_id);
  if (plan.plan === 'none' || (config.adminsOnly && plan.plan !== 'admin')) return null;
  try {
    const reply = await handleMessage(supabaseAssistantDb, { config }, user.user_id, plan, { text, history, channel: 'line' });
    return { messages: lineAssistantReply(reply.text, reply.cards), text: reply.text };
  } catch (error) {
    // Token, trial and pause answers are messages for the person.
    if (error instanceof HttpError && error.status !== 500) return { messages: [{ type: 'text', text: error.message }], text: error.message };
    throw error;
  }
}

const DONE: Record<string, { title: string; character: 'working' | 'received' | 'cancelled' }> = {
  add_job: { title: 'เพิ่มงานแล้ว', character: 'working' },
  record_payment: { title: 'บันทึกรับเงินแล้ว', character: 'received' },
  edit_job: { title: 'แก้ไขงานแล้ว', character: 'working' },
  delete_job: { title: 'ลบงานแล้ว', character: 'cancelled' },
};

/** ยืนยัน / ยกเลิก on a confirmation card in LINE. */
export async function lineAssistantCommand(user: UserRow, command: { action: 'confirm' | 'cancel'; proposalId: string }): Promise<LineMessage[]> {
  if (command.action === 'cancel') {
    const cancelled = await supabaseAssistantDb.cancelProposal(user.user_id, command.proposalId);
    return [cancelled
      ? lineCard({ title: 'ยกเลิกรายการแล้ว', subtitle: 'รายการนี้ไม่ได้ถูกบันทึก', character: 'cancelled', compact: true, altText: 'ยกเลิกรายการแล้ว ไม่ได้บันทึก',
        body: [{ type: 'text', text: 'พิมพ์บอกเลขาใหม่ได้เลย เมื่อพร้อม', size: 'sm', color: '#6B6560', wrap: true }] })
      : { type: 'text', text: 'รายการนี้ยืนยันไปแล้วหรือหมดเวลาแล้วครับ' }];
  }
  try {
    const done = await confirmProposal(supabaseAssistantDb, user.user_id, command.proposalId);
    const label = DONE[done.kind] ?? { title: 'บันทึกแล้ว', character: 'working' as const };
    return [lineCard({
      title: label.title, subtitle: 'บันทึกในแอปเรียบร้อย', character: label.character, compact: true, altText: label.title,
      body: [lineValueRow('สถานะ', 'บันทึกแล้ว', { bold: false })],
      footer: lineAppLink('/jobs', 'ดูในหน้างาน'),
    })];
  } catch (error) {
    if (error instanceof HttpError && error.status < 500) return [{ type: 'text', text: error.message }];
    throw error;
  }
}
