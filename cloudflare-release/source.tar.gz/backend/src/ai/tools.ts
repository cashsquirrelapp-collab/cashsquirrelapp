import { randomUUID } from 'node:crypto';
import { validateChanges } from '../../../shared/validation.js';
import { isValidWhtRate, whtAmountFor, roundMoney } from '../../../shared/wht.js';
import { calculatePayDate } from '../../../shared/calendar.js';
import { jobsInMonth, monthlyProfitSummary } from '../../../shared/monthlySummary.js';
import { buildDataSnapshot, formatAssistantMonthlySummary, type UserRow } from '../services/lineAssistant.js';
import { knowledgeSnippets, lookupKnowledge } from './knowledge.js';
import type { AssistantCard, Route, ToolCall, ToolOutcome, ToolSpec } from './types.js';

// The tools the models may call. Reads come from the account's own data through the same calculations the app
// uses (buildDataSnapshot, so numbers match the screens). Changes are only *proposed* here: each propose_* tool
// validates against the app's rules and returns a confirmation card; nothing is written until the user confirms
// and the app commits the proposal (see the gateway). No tool takes a user id from the model.

const MAX_ROWS = 10;

export type ProposalKind = 'add_job' | 'record_payment' | 'delete_job' | 'edit_job';
export interface Proposal {
  id: string;
  userId: string;
  kind: ProposalKind;
  /** What commit will write: for jobs, the job id and the full record (or null to delete). */
  jobId: string;
  record: Record<string, unknown> | null;
  title: string;
  changes: { label: string; value: string }[];
  createdAt: number;
}
export interface ProposalStore { save(proposal: Proposal): Promise<void> }
export interface MemoryStore { remember(userId: string, kind: string, value: string): Promise<void> }

/** ฿12,500 or ฿1,250.50 — the way the chat writes money (no space after ฿). */
export const baht = (amount: number) => `฿${Number(amount || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
const MONTHS = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
export const thaiDate = (iso?: string | null) => {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
  return match ? `${Number(match[3])} ${MONTHS[Number(match[2]) - 1]} ${Number(match[1]) + 543}` : '-';
};
const todayBangkok = () => new Date(Date.now() + 7 * 3600_000).toISOString().slice(0, 10);

type Job = NonNullable<UserRow['jobs']>[number] & Record<string, any>;

// Same rule as buildDataSnapshot (statusBehavior in lineAssistant.ts), so a job the overview counts as unpaid is unpaid here too.
function behavior(user: UserRow, statusId: string): 'done' | 'partial' | 'pending' {
  return (user.statuses || []).find(status => status.id === statusId)?.behavior || 'pending';
}
const isWorking = (job: Job) => job.isPosted === false;
const isUnpaid = (user: UserRow, job: Job) => (job.pending || 0) > 0 && behavior(user, job.status || '') !== 'done';
const netOf = (job: Job) => roundMoney((job.value || 0) - whtAmountFor(job.value || 0, job.whtRate || 0));

/** A job as the models see it: enough to answer and to pick the right one, nothing more. */
const jobRow = (user: UserRow, job: Job) => ({
  job_id: job.id, name: job.name, client: job.client || '', value: baht(job.value || 0), pending: baht(job.pending || 0),
  stage: isWorking(job) ? 'กำลังทำ' : 'ส่งงานแล้ว', payment: isUnpaid(user, job) ? ((job.received || 0) > 0 ? 'รับบางส่วน' : 'ยังไม่รับเงิน') : 'รับครบแล้ว',
  delivery_date: thaiDate(job.postDate), pay_date: thaiDate(job.payDate || job.dueDate),
});
const capped = <T,>(rows: T[]) => ({ total: rows.length, shown: Math.min(rows.length, MAX_ROWS), rows: rows.slice(0, MAX_ROWS) });

const obj = (properties: Record<string, unknown>, required: string[] = []): ToolSpec['parameters'] => ({ type: 'object', properties, ...(required.length ? { required } : {}) });
const str = (description: string) => ({ type: 'string', description });
const numArg = (description: string) => ({ type: 'number', description });

const READ_TOOLS: ToolSpec[] = [
  { name: 'feature_lookup', description: 'Look up what the Krarok app can do: a feature, where it is, how to use it, its plan rights and whether it is live. Use before answering any question about the app.', parameters: obj({ query: str('What the user asks about, in their words') }, ['query']) },
  { name: 'money_summary', description: "The month's money figures exactly as the app's overview computes them: received, expenses, net profit, cash flow.", parameters: obj({ month: { type: 'string', enum: ['this', 'last'], description: 'This month or last month' } }) },
  { name: 'receivables', description: 'Money clients still owe: overdue, due today, due within 10 days, and every unpaid job (capped list with the total count).', parameters: obj({}) },
  { name: 'search_jobs', description: 'Find jobs by name or client, optionally by stage and by month (the same "jobs of the month" rule as the app). Returns a capped list with job_id for follow-up tools (never show job_id), plus the count and totals of ALL matches: use those totals, never add up rows yourself.', parameters: obj({ query: str('Words from the job name or client (optional)'), status: { type: 'string', enum: ['all', 'working', 'unpaid', 'closed'], description: 'working = not delivered yet; unpaid = money still owed; closed = fully paid' }, month: { type: 'string', enum: ['all', 'this', 'last'], description: 'Only jobs of this month or last month, as the app counts them (default all)' } }) },
  { name: 'get_job', description: 'One job in detail by job_id (from search_jobs).', parameters: obj({ job_id: str('job_id from search_jobs') }, ['job_id']) },
];
const DOCUMENT_TOOLS: ToolSpec[] = [
  { name: 'search_documents', description: 'Find the account\'s documents (ใบเสนอราคา, ใบแจ้งหนี้, ใบเสร็จ, ใบกำกับภาษี) by client, number or type, newest first. The top matches are shown to the user as document cards with an open button, so do not repeat every field; use a table only for more than three.', parameters: obj({
    query: str('Client name or document number (optional)'),
    type: { type: 'string', enum: ['all', 'quotation', 'invoice', 'receipt', 'taxInvoice', 'receiptTaxInvoice'], description: 'quotation = ใบเสนอราคา, invoice = ใบแจ้งหนี้, receipt = ใบเสร็จ, taxInvoice = ใบกำกับภาษี, receiptTaxInvoice = ใบเสร็จ/ใบกำกับภาษี' },
  }) },
];
const CHAT_ONLY: ToolSpec[] = [
  { name: 'route_to_action', description: 'Hand the request to the action assistant when the user wants to create, change, delete, record a payment, build a document or import a file.', parameters: obj({ summary: str('One line: what the user wants done') }, ['summary']) },
];
const MEMORY_TOOLS: ToolSpec[] = [
  { name: 'remember', description: 'Save something the user explicitly asked you to remember about them (what to call them, how to talk to them, their role, routines, document preferences). Never save guesses from a single message.', parameters: obj({ kind: { type: 'string', enum: ['preferred_name', 'tone', 'role', 'routine', 'document_preference', 'context'] }, value: str('What to remember, short') }, ['kind', 'value']) },
];
const ACTION_TOOLS: ToolSpec[] = [
  { name: 'propose_add_job', description: 'Prepare a new job for the user to confirm, with the same details as the job form in the app. Never guess a detail the user did not give: if something needed is missing the tool answers ok:false with `missing`, and you ask the user for all of it in one short message. Nothing is saved until the user confirms the card.', parameters: obj({
    name: str('Job name'), value: numArg('Job value in baht, before withholding tax'),
    client: str('Client name. If the user says there is none, pass "ไม่ระบุ".'),
    delivered: { type: 'boolean', description: 'true = the work is already delivered (ส่งงานแล้ว); false = still in progress (กำลังทำ)' },
    delivery_date: str('YYYY-MM-DD. Delivered: the day it was delivered (required). In progress: the planned delivery day, if the user gave one.'),
    payment_status: { type: 'string', enum: ['unpaid', 'partial', 'paid'], description: 'unpaid = no money yet; partial = some received (give received_amount); paid = fully paid' },
    received_amount: numArg('Baht already received, when payment_status is partial'),
    paid_date: str('YYYY-MM-DD the money arrived, when payment_status is paid (default today)'),
    credit_term_days: numArg('Credit term: days after delivery until payment is due (เครดิตเทอม), e.g. 0, 7, 15, 30, 45, 60, 90'),
    pay_date: str('YYYY-MM-DD the client must pay by, if the user gave a date instead of a credit term'),
    wht_rate: numArg('Withholding tax percent (หัก ณ ที่จ่าย), usually 0, 1, 3 or 5; 0 if the user says there is none'),
    type: str('Job type (optional)'), note: str('Note (optional)'),
  }, ['name', 'value']) },
  { name: 'propose_record_payment', description: 'Prepare recording money received for a job: in full, or a partial amount. Needs job_id (from search_jobs). Nothing is saved until the user confirms.', parameters: obj({
    job_id: str('job_id from search_jobs'), mode: { type: 'string', enum: ['full', 'partial'] }, amount: numArg('Amount received, for partial'), date: str('Date received, YYYY-MM-DD (optional, default today)'),
  }, ['job_id', 'mode']) },
  { name: 'propose_edit_job', description: "Prepare a change to a job's name, client, value, payment due date or note. Needs job_id. Nothing is saved until the user confirms.", parameters: obj({
    job_id: str('job_id from search_jobs'), name: str('New name'), client: str('New client'), value: numArg('New value in baht'), pay_date: str('New payment due date, YYYY-MM-DD'), note: str('New note'),
  }, ['job_id']) },
  { name: 'propose_delete_job', description: 'Prepare deleting one job. Needs job_id. The card tells the user what disappears; nothing is deleted until they confirm.', parameters: obj({ job_id: str('job_id from search_jobs') }, ['job_id']) },
];

export function toolsFor(route: Route): ToolSpec[] {
  return route === 'chat' ? [...READ_TOOLS, ...DOCUMENT_TOOLS, ...CHAT_ONLY, ...MEMORY_TOOLS] : [...READ_TOOLS, ...DOCUMENT_TOOLS, ...MEMORY_TOOLS, ...ACTION_TOOLS];
}

/** A short picture of the account for the prompt: the month's figures and counts, no lists (tools give lists). */
export function accountContext(user: UserRow): string {
  const snapshot = buildDataSnapshot(user);
  return JSON.stringify({
    this_month: formatAssistantMonthlySummary(snapshot.thisMonth),
    unpaid_jobs: snapshot.unpaid.length, unpaid_total: baht(snapshot.totalPendingAllTime),
    overdue_jobs: snapshot.overdue.length, due_today: snapshot.dueToday.length, working_jobs: snapshot.wip.length,
    note: 'Totals only. Use receivables / search_jobs for the rows.',
  });
}

export interface ToolContext { user: UserRow; proposals: ProposalStore; memory: MemoryStore }

const fail = (message: string): ToolOutcome => ({ result: { ok: false, error: message } });

export function createToolbox(context: ToolContext) {
  const { user } = context;
  const jobs = () => (user.jobs || []) as Job[];
  const findJob = (id: unknown) => jobs().find(job => job.id === id);

  const propose = async (kind: ProposalKind, job: Job, record: Record<string, unknown> | null, title: string, changes: Proposal['changes']): Promise<ToolOutcome> => {
    if (record) {
      // Older jobs can lack fields the app now requires; fill them the way the app's job form does.
      record.type ??= 'ยังไม่ระบุ';
      record.note ??= '';
      try { validateChanges([{ table: 'cashflow_jobs', id: job.id, op: 'set', version: null, data: record }]); }
      catch (error) {
        const fields = Array.isArray((error as any)?.issues) ? (error as any).issues.map((issue: any) => (issue.path || []).join('.')).filter(Boolean) : [];
        return fail(`ข้อมูลไม่ผ่านการตรวจของแอป${fields.length ? ` (${[...new Set(fields)].join(', ')})` : ''}`);
      }
    }
    const proposal: Proposal = { id: `p_${randomUUID()}`, userId: user.user_id, kind, jobId: job.id, record, title, changes, createdAt: Date.now() };
    await context.proposals.save(proposal);
    const card: AssistantCard = { kind: 'confirm', id: proposal.id, title, changes };
    return { result: { ok: true, proposal_id: proposal.id, saved: false, note: 'Shown to the user as a card. Not saved until they confirm.' }, card };
  };

  return async function execute(call: ToolCall): Promise<ToolOutcome> {
    const args = call.args || {};
    switch (call.name) {
      case 'feature_lookup':
        return { result: knowledgeSnippets(lookupKnowledge(String(args.query || ''), 3)) };
      case 'money_summary': {
        const snapshot = buildDataSnapshot(user);
        const month = args.month === 'last' ? snapshot.lastMonth : snapshot.thisMonth;
        // The chat draws the month's money as its summary card (same figures as the overview), so the answer
        // can stay to a line or two.
        const profit = monthlyProfitSummary(month);
        const [y, m] = month.monthKey.split('-').map(Number);
        const card: AssistantCard = { kind: 'summary', period: `${MONTHS[m - 1]} ${y + 543}`, income: baht(profit.received), expense: baht(profit.totalExpense), balance: baht(profit.netProfit) };
        return { result: { ...formatAssistantMonthlySummary(month), card_shown: 'A summary card with รายรับ, รายจ่าย and เงินคงเหลือ is shown under your answer; do not repeat all of it.' }, card };
      }
      case 'receivables': {
        const snapshot = buildDataSnapshot(user);
        return { result: {
          total_owed: baht(snapshot.totalPendingAllTime),
          overdue: capped(snapshot.overdue.map(row => ({ name: row.name, client: row.client, pending: baht(row.pending), when: row.overdueText }))),
          due_today: capped(snapshot.dueToday.map(row => ({ name: row.name, client: row.client, pending: baht(row.pending) }))),
          due_within_10_days: capped(snapshot.dueSoon.map(row => ({ name: row.name, client: row.client, pending: baht(row.pending), when: row.dueText }))),
          all_unpaid: capped(snapshot.unpaid.map(row => ({ name: row.name, client: row.client, pending: baht(row.pending), due: thaiDate(row.dueDate), when: row.dueText }))),
        } };
      }
      case 'search_jobs': {
        const query = String(args.query || '').trim().toLowerCase();
        const status = String(args.status || 'all');
        const local = new Date(Date.now() + 7 * 3600_000);
        const monthKey = args.month === 'this' ? local.toISOString().slice(0, 7)
          : args.month === 'last' ? new Date(Date.UTC(local.getUTCFullYear(), local.getUTCMonth() - 1, 1)).toISOString().slice(0, 7) : null;
        const inMonth = monthKey ? new Set(jobsInMonth(jobs() as any, monthKey).map(job => job.id)) : null;
        const rows = jobs().filter(job => (!inMonth || inMonth.has(job.id)) &&
          (!query || `${job.name} ${job.client || ''} ${job.type || ''}`.toLowerCase().includes(query))
          && (status === 'all' || (status === 'working' && isWorking(job)) || (status === 'unpaid' && isUnpaid(user, job))
            || (status === 'closed' && !isWorking(job) && !isUnpaid(user, job))));
        return { result: {
          ...capped(rows.map(job => jobRow(user, job))),
          ...(monthKey ? { month: monthKey } : {}),
          total_value: baht(rows.reduce((sum, job) => sum + (job.value || 0), 0)),
          total_pending: baht(rows.reduce((sum, job) => sum + (isUnpaid(user, job) ? job.pending || 0 : 0), 0)),
        } };
      }
      case 'search_documents': {
        const LABEL: Record<string, string> = { quotation: 'ใบเสนอราคา', invoice: 'ใบแจ้งหนี้', receipt: 'ใบเสร็จรับเงิน', taxInvoice: 'ใบกำกับภาษี', receiptTaxInvoice: 'ใบเสร็จ / ใบกำกับภาษี' };
        type Doc = { id: string; documentType: string; documentNo?: string; createdDate?: string; dueDate?: string; client?: { name?: string }; items?: { quantity?: number; price?: number; discount?: number }[]; vatRate?: number };
        const query = String(args.query || '').trim().toLowerCase();
        const type = String(args.type || 'all');
        // Same total as the documents page (documentMath.calculateDocumentTotals): lines less discounts, plus VAT.
        const totalOf = (doc: Doc) => {
          const subtotal = (doc.items || []).reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.price) || 0) - (Number(item.discount) || 0), 0);
          return subtotal + (doc.vatRate ? Math.round((subtotal * doc.vatRate / 100 + Number.EPSILON) * 100) / 100 : 0);
        };
        const docs = (((user as unknown as { invoices?: Doc[] }).invoices) || [])
          .filter(doc => LABEL[doc.documentType] && (type === 'all' || doc.documentType === type)
            && (!query || `${doc.documentNo || ''} ${doc.client?.name || ''}`.toLowerCase().includes(query)))
          .sort((a, b) => String(b.createdDate || '').localeCompare(String(a.createdDate || '')));
        const rows = docs.map(doc => ({ document_id: doc.id, type: LABEL[doc.documentType], number: doc.documentNo || '-', client: doc.client?.name || '-', date: thaiDate(doc.createdDate), amount: baht(totalOf(doc)), ...(doc.dueDate ? { due: thaiDate(doc.dueDate) } : {}) }));
        const cards: AssistantCard[] = docs.slice(0, 3).map(doc => {
          const tab = doc.documentType === 'receiptTaxInvoice' ? 'taxInvoice' : doc.documentType;
          return { kind: 'document', docType: LABEL[doc.documentType], number: doc.documentNo || '-', client: doc.client?.name || '-', amount: baht(totalOf(doc)), path: `/invoice?${new URLSearchParams({ type: tab, document: doc.id })}` };
        });
        const result = { ...capped(rows), cards_shown: cards.length, note: cards.length ? 'The first matches are shown as document cards under your answer.' : 'No matching document.' };
        // One card per document; the gateway shows all cards from a request, so hand back the first and keep the rest on the result.
        return { result, ...(cards[0] ? { card: cards[0] } : {}), ...(cards.length > 1 ? { extraCards: cards.slice(1) } : {}) } as ToolOutcome;
      }
      case 'get_job': {
        const job = findJob(args.job_id);
        return job ? { result: { ...jobRow(user, job), type: job.type || '', wht_rate: job.whtRate || 0, received: baht(job.received || 0), note: job.note || '' } } : fail('ไม่พบงานนี้ในบัญชี');
      }
      case 'remember': {
        const value = String(args.value || '').trim().slice(0, 200);
        if (!value) return fail('ไม่มีข้อความให้จำ');
        await context.memory.remember(user.user_id, String(args.kind || 'context'), value);
        return { result: { ok: true } };
      }
      case 'route_to_action':
        return { result: { ok: true, handed_over: true }, handoff: String(args.summary || '').trim().slice(0, 300) || 'The user wants something done (see their last message).' };
      case 'propose_add_job': {
        // The same details the app's job form asks for (JobFormDrawer). Anything the payment schedule depends on
        // must come from the user, never from a default: the tool lists what is missing for the model to ask.
        const value = Number(args.value);
        const name = String(args.name || '').trim();
        const isDate = (raw: unknown) => /^\d{4}-\d{2}-\d{2}$/.test(String(raw || ''));
        const missing: string[] = [];
        if (!name) missing.push('ชื่องาน');
        if (!Number.isFinite(value) || value <= 0) missing.push('มูลค่างาน');
        const client = String(args.client ?? '').trim();
        if (!client) missing.push('ลูกค้า (หรือ "ไม่ระบุ")');
        const delivered = typeof args.delivered === 'boolean' ? args.delivered : null;
        if (delivered === null) missing.push('ส่งงานแล้วหรือยังกำลังทำ');
        if (delivered === true && !isDate(args.delivery_date)) missing.push('วันที่ส่งงาน');
        const payment = ['unpaid', 'partial', 'paid'].includes(String(args.payment_status)) ? String(args.payment_status) as 'unpaid' | 'partial' | 'paid' : null;
        if (!payment) missing.push('สถานะการชำระ (ยังไม่จ่าย / จ่ายบางส่วน / จ่ายครบแล้ว)');
        if (payment === 'partial' && !(Number(args.received_amount) > 0)) missing.push('ยอดที่ได้รับแล้ว');
        const hasTerm = args.credit_term_days !== undefined && args.credit_term_days !== null && Number.isFinite(Number(args.credit_term_days));
        if (payment !== 'paid' && !hasTerm && !isDate(args.pay_date)) missing.push('เครดิตเทอม (กี่วันหลังส่งงาน) หรือวันครบกำหนดรับเงิน');
        const whtGiven = args.wht_rate !== undefined && args.wht_rate !== null && String(args.wht_rate) !== '';
        if (!whtGiven) missing.push('หัก ณ ที่จ่ายกี่ % (ไม่มีก็ได้)');
        if (missing.length) {
          return { result: { ok: false, missing, note: 'Not prepared. Ask the user for all of these in one short message (a short list is fine), then call again. Never fill them in yourself.' } };
        }
        const wht = Number(args.wht_rate);
        if (!isValidWhtRate(wht)) return fail('อัตราหัก ณ ที่จ่ายไม่ถูกต้อง');
        const today = todayBangkok();
        const postDate = isDate(args.delivery_date) ? String(args.delivery_date) : '';
        let creditTerm = hasTerm ? Math.max(0, Math.round(Number(args.credit_term_days))) : 0;
        if (!hasTerm && isDate(args.pay_date) && postDate) creditTerm = Math.max(0, Math.round((Date.parse(String(args.pay_date)) - Date.parse(postDate)) / 86400000));
        const whtAmount = whtAmountFor(value, wht);
        const net = roundMoney(value - whtAmount);
        const received = payment === 'paid' ? net : payment === 'partial' ? roundMoney(Math.min(Number(args.received_amount), net)) : 0;
        if (payment === 'partial' && received >= net) return fail('ยอดที่ได้รับเท่ากับหรือเกินยอดที่ต้องรับ ให้ใช้สถานะจ่ายครบแล้วแทน');
        const behaviorFor = payment === 'paid' ? 'done' : payment === 'partial' ? 'partial' : 'pending';
        const statuses = (user.statuses || []) as { id: string; behavior: string }[];
        const status = statuses.find(item => item.id === behaviorFor && item.behavior === behaviorFor)?.id
          ?? statuses.find(item => item.behavior === behaviorFor && item.id !== 'installment')?.id ?? behaviorFor;
        const payDate = payment === 'paid' ? (isDate(args.paid_date) ? String(args.paid_date) : today)
          : isDate(args.pay_date) ? String(args.pay_date)
          : postDate ? calculatePayDate(postDate, creditTerm, false) : null;
        const job = {
          id: randomUUID(), name, type: args.type ? String(args.type).trim() : 'ยังไม่ระบุ', client: client === 'ไม่ระบุ' ? '' : client,
          value, received, pending: roundMoney(Math.max(0, net - received)), status, creditTerm, postDate, startDate: today,
          isPosted: Boolean(delivered), payDate, note: args.note ? String(args.note) : '', whtRate: wht, whtAmount, excludeHolidays: false, installments: [],
          paymentStatus: payment === 'paid' ? 'paid' : payment === 'partial' ? 'partial' : 'unpaid',
          ...(payment === 'partial' ? { depositDate: today, depositAmount: received } : {}),
        } as unknown as Job;
        return propose('add_job', job, job as unknown as Record<string, unknown>, 'เพิ่มงานใหม่ 1 งาน', [
          { label: 'งาน', value: name }, { label: 'ลูกค้า', value: client }, { label: 'มูลค่า', value: baht(value) },
          { label: 'สถานะงาน', value: delivered ? `ส่งงานแล้ว ${thaiDate(postDate)}` : postDate ? `กำลังทำ · จะส่ง ${thaiDate(postDate)}` : 'กำลังทำ' },
          { label: 'การชำระ', value: payment === 'paid' ? `จ่ายครบแล้ว ${thaiDate(payDate)}` : payment === 'partial' ? `รับแล้ว ${baht(received)} · ค้าง ${baht(net - received)}` : 'ยังไม่จ่าย' },
          ...(payment !== 'paid' ? [{ label: 'ครบกำหนดรับเงิน', value: payDate ? `${thaiDate(payDate)} (เครดิต ${creditTerm} วัน)` : `เครดิต ${creditTerm} วันหลังส่งงาน` }] : []),
          { label: 'หัก ณ ที่จ่าย', value: wht ? `${wht}% (${baht(whtAmount)})` : 'ไม่มี' },
        ]);
      }
      case 'propose_record_payment': {
        const job = findJob(args.job_id);
        if (!job) return fail('ไม่พบงานนี้ในบัญชี');
        if (!isUnpaid(user, job)) return fail('งานนี้รับเงินครบแล้ว');
        const net = netOf(job);
        const date = /^\d{4}-\d{2}-\d{2}$/.test(String(args.date || '')) ? String(args.date) : todayBangkok();
        if (args.mode === 'partial') {
          const amount = roundMoney(Number(args.amount));
          if (!Number.isFinite(amount) || amount <= 0) return fail('ต้องระบุยอดที่ได้รับ');
          if (amount >= net) return fail('ยอดนี้เท่ากับหรือเกินยอดที่ต้องรับ ให้บันทึกเป็นรับครบแทน');
          const record = { ...job, status: 'partial', received: amount, pending: roundMoney(Math.max(0, net - amount)), paymentStatus: 'partial', depositDate: date, depositAmount: amount, lastActivityAt: new Date().toISOString() };
          return propose('record_payment', job, record, 'บันทึกรับเงินบางส่วน', [{ label: 'งาน', value: job.name }, { label: 'รับแล้ว', value: baht(amount) }, { label: 'คงเหลือ', value: baht(record.pending) }, { label: 'วันที่รับ', value: thaiDate(date) }]);
        }
        const record = { ...job, status: 'done', received: net, pending: 0, paymentStatus: 'paid', payDate: date, lastActivityAt: new Date().toISOString() };
        return propose('record_payment', job, record, 'บันทึกรับเงินครบ', [{ label: 'งาน', value: job.name }, { label: 'ลูกค้า', value: job.client || '-' }, { label: 'ยอดรับ', value: baht(net) }, { label: 'วันที่รับ', value: thaiDate(date) }]);
      }
      case 'propose_edit_job': {
        const job = findJob(args.job_id);
        if (!job) return fail('ไม่พบงานนี้ในบัญชี');
        const record: Record<string, unknown> = { ...job, lastActivityAt: new Date().toISOString() };
        const changes: Proposal['changes'] = [{ label: 'งาน', value: job.name }];
        if (typeof args.name === 'string' && args.name.trim()) { record.name = args.name.trim(); changes.push({ label: 'ชื่อใหม่', value: record.name as string }); }
        if (typeof args.client === 'string') { record.client = args.client.trim(); changes.push({ label: 'ลูกค้า', value: (record.client as string) || '-' }); }
        if (args.value !== undefined) {
          const value = Number(args.value);
          if (!Number.isFinite(value) || value <= 0) return fail('มูลค่าต้องมากกว่า 0');
          const wht = whtAmountFor(value, job.whtRate || 0);
          const net = roundMoney(value - wht);
          if ((job.received || 0) > net) return fail('มูลค่าใหม่น้อยกว่ายอดที่รับไปแล้ว');
          Object.assign(record, { value, whtAmount: wht, pending: roundMoney(Math.max(0, net - (job.received || 0))) });
          changes.push({ label: 'มูลค่า', value: `${baht(job.value || 0)} → ${baht(value)}` });
        }
        if (args.pay_date !== undefined) {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(String(args.pay_date))) return fail('วันที่ต้องเป็น YYYY-MM-DD');
          record.payDate = String(args.pay_date);
          changes.push({ label: 'ครบกำหนดรับเงิน', value: `${thaiDate(job.payDate)} → ${thaiDate(record.payDate as string)}` });
        }
        if (typeof args.note === 'string') { record.note = args.note; changes.push({ label: 'บันทึก', value: args.note || '-' }); }
        if (changes.length === 1) return fail('ไม่มีอะไรให้เปลี่ยน');
        return propose('edit_job', job, record, 'แก้ไขงาน', changes);
      }
      case 'propose_delete_job': {
        const job = findJob(args.job_id);
        if (!job) return fail('ไม่พบงานนี้ในบัญชี');
        return propose('delete_job', job, null, 'ลบงาน 1 งาน', [
          { label: 'งาน', value: job.name }, { label: 'ลูกค้า', value: job.client || '-' }, { label: 'มูลค่า', value: baht(job.value || 0) },
          { label: 'ผลกระทบ', value: 'งานนี้จะหายจากรายการ รายงาน และเงินค้างรับ' },
        ]);
      }
      default:
        return fail(`ไม่มีเครื่องมือ ${call.name}`);
    }
  };
}
