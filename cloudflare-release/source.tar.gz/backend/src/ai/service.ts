import { randomUUID } from 'node:crypto';
import { HttpError } from '../http/guard.js';
import type { UserRow } from '../services/lineAssistant.js';
import type { AiConfig } from './config.js';
import { AiUnavailableError, failedRouting, runAssistant, type AssistantReply } from './gateway.js';
import type { RoutingRecord } from './routingPolicy.js';
import type { PromptSlots } from './prompt.js';
import { applyCardEdit, cardValue, createToolbox, EDITABLE_FIELDS, type MemoryStore, type Proposal, type ProposalStore } from './tools.js';
import { learnedPairs, learnFromConfirmed, mergePairs, pairFromCardEdit, type CorrectionDomain, type LearnPair } from './learning.js';
import type { KnowledgeSignal } from './signals.js';
import { ProviderError, type AssistantCard, type ChatTurn, type Provider, type ProviderName } from './types.js';
import type { VaultFile } from '../../../shared/vault.js';
import { proposalBaseVersion, proposalChanges, proposalTarget } from './proposals.js';
import { documentPath } from './documentActions.js';
import { MEMORY_LIMIT, overLimit, replacedMemory, selectMemories, type MemoryKind, type MemoryRow } from './memory.js';

// What one เลขากระรอก request does around the model: who may use it, how many Krarok Tokens are left, charging the
// real cost after the answer, and applying a proposal when the user presses confirm. The database sits behind
// AssistantDb so the rules can be tested without one (the Supabase version is in supabaseDb.ts).

export type AssistantPlan = 'pro' | 'trial' | 'admin' | 'none';
/** Tokens held while the model runs; the real cost replaces it afterwards (a request costs about 2). */
export const RESERVE_TOKENS = 5;

export interface StoredProposal extends Proposal { baseVersion: number | null }
export type ReserveResult =
  | { ok: true; usedTokens: number; usedRequests: number }
  | { ok: false; reason: 'tokens' | 'requests' | 'daily_cap' };

export interface AssistantDb {
  loadAccount(userId: string): Promise<{ user: UserRow; versions: Record<string, number>; absentRecords?: string[] }>;
  /** Read metadata only. Called lazily with the authenticated ID, never a model-supplied scope. */
  listVaultFiles?(userId: string): Promise<VaultFile[]>;
  reserve(input: { userId: string; cycle: string; requestId: string; tokens: number; tokenLimit: number | null; requestLimit: number | null; dailyCapUsd: number }): Promise<ReserveResult>;
  settle(input: { userId: string; requestId: string; tokens: number; costUsd: number; model: string | null; route: string | null; promptVersion: string | null; release: boolean }): Promise<void>;
  usage(userId: string, cycle: string): Promise<{ tokens: number; requests: number }>;
  saveProposal(proposal: StoredProposal): Promise<void>;
  claimProposal(userId: string, id: string): Promise<StoredProposal | null>;
  finishProposal(userId: string, id: string, status: 'applied' | 'pending' | 'cancelled' | 'stale'): Promise<void>;
  cancelProposal(userId: string, id: string): Promise<boolean>;
  /** A pending, unexpired proposal of this user, with the tool call that prepared it (null when not editable). */
  getProposal?(userId: string, id: string): Promise<StoredProposal | null>;
  /** The app's own save (cashflow_apply_changes): false when the job changed since the version given. */
  applyChanges(userId: string, changes: unknown[]): Promise<boolean>;
  memories(userId: string): Promise<MemoryRow[]>;
  remember(userId: string, kind: string, value: string, limit: number): Promise<void>;
  /** Memory v2 (20261025090000_ai_learning.sql): save or replace one memory with its history; evict the given rows. */
  saveMemory?(userId: string, input: { kind: string; value: string; source: 'explicit' | 'correction'; channel: 'app' | 'line'; replace?: MemoryRow & { version?: number }; evict?: MemoryRow[] }): Promise<string | null>;
  /** Delete these memories of this user (the user asked), with their history's text. Returns how many. */
  forgetMemories?(userId: string, rows: MemoryRow[], channel: 'app' | 'line'): Promise<number>;
  /** The memories one message used: last used now (retention, least used go first). */
  touchMemories?(userId: string, ids: string[]): Promise<void>;
  /** A correction the user confirmed, for the account's correction history (package B). */
  saveCorrection?(userId: string, input: LearnPair & { proposalId: string; memoryId: string | null }): Promise<void>;
  /** The answers this subject was corrected to in the last 60 days, newest first. */
  recentCorrections?(userId: string, domain: CorrectionDomain, subject: string): Promise<string[]>;
  /** Feature knowledge signals for the owner's report (package D). */
  saveSignals?(userId: string, signals: KnowledgeSignal[], channel: 'app' | 'line', promptVersion: string): Promise<void>;
  /** Why the request went to which model, per-model cost and the outcome, on its usage row (routing V2). */
  saveRouting?(userId: string, requestId: string, routing: RoutingRecord): Promise<void>;
}

/** 'YYYY-MM' in Bangkok: the calendar month, for admins and Pro granted by an admin (no renewal date). */
export const tokenCycle = (now = new Date()) => new Date(now.getTime() + 7 * 3600_000).toISOString().slice(0, 7);

const BANGKOK = 7 * 3600_000;
/** The same day of the month as the anchor, `months` later (31 Jan + 1 month = 28/29 Feb). Bangkok dates. */
function shiftMonths(anchor: { y: number; m: number; d: number }, months: number) {
  const first = new Date(Date.UTC(anchor.y, anchor.m + months, 1));
  const last = new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth() + 1, 0)).getUTCDate();
  return new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth(), Math.min(anchor.d, last)) - BANGKOK);
}

/**
 * Pro tokens renew every month on the renewal day (owner's choice, 2026-10-24): a plan renewing on the 15th resets
 * on the 15th of every month, also for 6-month and yearly plans. Returns the cycle's start date (Bangkok, the key
 * the usage rows are filed under) and when the next one starts.
 */
export function renewalCycle(periodEnd: string, now = new Date()): { cycle: string; resetsAt: Date } {
  const end = new Date(new Date(periodEnd).getTime() + BANGKOK);
  const anchor = { y: end.getUTCFullYear(), m: end.getUTCMonth(), d: end.getUTCDate() };
  // Months from the anchor back (negative) or forward to the cycle that contains now.
  let k = (now.getUTCFullYear() - anchor.y) * 12 + (now.getUTCMonth() - anchor.m) + 1;
  while (shiftMonths(anchor, k).getTime() > now.getTime()) k -= 1;
  while (shiftMonths(anchor, k + 1).getTime() <= now.getTime()) k += 1;
  const start = shiftMonths(anchor, k);
  return { cycle: new Date(start.getTime() + BANGKOK).toISOString().slice(0, 10), resetsAt: shiftMonths(anchor, k + 1) };
}

export interface PlanInfo { plan: AssistantPlan; periodEnd?: string | null }
const asPlan = (value: AssistantPlan | PlanInfo): PlanInfo => (typeof value === 'string' ? { plan: value } : value);

/** Limits for a plan: Pro has a monthly token allowance, the trial one small allowance for the whole trial, admins no cap (still counted). */
export function allowance(value: AssistantPlan | PlanInfo, config: AiConfig, now = new Date()) {
  const { plan, periodEnd } = asPlan(value);
  if (plan === 'trial') return { cycle: 'trial', resetsAt: null, tokenLimit: config.trialTokens, requestLimit: null };
  const month = () => {
    const local = new Date(now.getTime() + BANGKOK);
    return { cycle: tokenCycle(now), resetsAt: new Date(Date.UTC(local.getUTCFullYear(), local.getUTCMonth() + 1, 1) - BANGKOK) };
  };
  const period = plan === 'pro' && periodEnd ? renewalCycle(periodEnd, now) : month();
  if (plan === 'admin') return { ...period, tokenLimit: null, requestLimit: null };
  return { ...period, tokenLimit: config.proTokensPerCycle, requestLimit: null };
}

export const thaiDay = (date: Date) => {
  const local = new Date(date.getTime() + BANGKOK);
  const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  return `${local.getUTCDate()} ${months[local.getUTCMonth()]} ${local.getUTCFullYear() + 543}`;
};

const NO_ACCESS = 'เลขากระรอกเป็นสิทธิ์ของสมาชิก Pro';
export function refuse(reason: 'tokens' | 'requests' | 'daily_cap', resetsAt: Date | null, trial = false): never {
  if (reason === 'requests' || (reason === 'tokens' && trial)) throw new HttpError(402, 'สิทธิ์ทดลองใช้เลขากระรอกครบแล้ว อัปเกรดเป็น Pro เพื่อใช้งานต่อ', 'ai_trial_used');
  if (reason === 'tokens') throw new HttpError(402, `โทเคนของรอบนี้หมดแล้ว จะได้รับใหม่วันที่ ${resetsAt ? thaiDay(resetsAt) : 'รอบถัดไป'}`, 'ai_tokens_used');
  throw new HttpError(503, 'เลขากระรอกพักการใช้งานชั่วคราว กรุณาลองใหม่ภายหลัง', 'ai_daily_cap');
}

/** One burst limit per account for เลขา messages, shared by the app and LINE (same scope and key). */
export const MESSAGE_RATE = { scope: 'assistant-message', limit: 20, seconds: 60 } as const;

export interface UsageStatus { enabled: boolean; plan: AssistantPlan; tokensLeft: number | null; trialLeft: number | null; resetsAt: string | null; tokenLimit: number | null; requestLimit: number | null }
export async function usageStatus(db: AssistantDb, config: AiConfig, userId: string, value: AssistantPlan | PlanInfo, now = new Date()): Promise<UsageStatus> {
  const { plan } = asPlan(value);
  if (!config.enabled || plan === 'none') return { enabled: config.enabled, plan, tokensLeft: null, trialLeft: null, resetsAt: null, tokenLimit: null, requestLimit: null };
  const limits = allowance(value, config, now);
  const used = await db.usage(userId, limits.cycle);
  return {
    enabled: true, plan,
    tokensLeft: limits.tokenLimit === null ? null : Math.max(0, limits.tokenLimit - used.tokens),
    trialLeft: limits.requestLimit === null ? null : Math.max(0, limits.requestLimit - used.requests),
    resetsAt: limits.resetsAt ? limits.resetsAt.toISOString() : null,
    tokenLimit: limits.tokenLimit, requestLimit: limits.requestLimit,
  };
}

export interface MessageInput { text: string; history?: ChatTurn[]; pageName?: string; channel?: 'app' | 'line'; attachment?: { name: string; mimeType: string; data: string } }
export interface MessageDeps { config: AiConfig; providers?: Partial<Record<ProviderName, Provider>>; fetchImpl?: typeof fetch; now?: Date; signal?: AbortSignal }
export interface MessageResult extends Pick<AssistantReply, 'text' | 'cards' | 'route' | 'tokens' | 'memo'> { tokensLeft: number | null; trialLeft: number | null }

export async function handleMessage(db: AssistantDb, deps: MessageDeps, userId: string, value: AssistantPlan | PlanInfo, input: MessageInput): Promise<MessageResult> {
  const { config } = deps;
  const { plan } = asPlan(value);
  if (!config.enabled) throw new HttpError(503, 'เลขากระรอกยังไม่เปิดให้ใช้งาน', 'ai_disabled');
  if (plan === 'none') throw new HttpError(403, NO_ACCESS, 'ai_pro_only');
  const limits = allowance(value, config, deps.now);
  const requestId = randomUUID();
  const reserved = await db.reserve({ userId, cycle: limits.cycle, requestId, tokens: limits.requestLimit !== null ? 0 : RESERVE_TOKENS,
    tokenLimit: limits.tokenLimit, requestLimit: limits.requestLimit, dailyCapUsd: config.dailyCostCapUsd });
  if (!reserved.ok) refuse(reserved.reason, limits.resetsAt, plan === 'trial');

  let reply: AssistantReply;
  let selected: ReturnType<typeof selectMemories> | undefined;
  const started = Date.now();
  const channel = input.channel === 'line' ? 'line' as const : 'app' as const;
  try {
    const [{ user, versions, absentRecords }, memories] = await Promise.all([db.loadAccount(userId), db.memories(userId)]);
    if (user.user_id !== userId) throw new HttpError(403, 'ข้อมูลบัญชีไม่ตรงกับผู้ใช้งาน', 'ai_account_mismatch');
    const proposals: ProposalStore = { save: proposal => db.saveProposal({ ...proposal,
      baseVersion: proposalBaseVersion(proposal, versions, absentRecords) }) };
    // Memory v2 (owner, 2026-10-25): the same thing said again replaces the old one, over 40 the least used go, and
    // every change is kept in the memory's history. Before the migration runs, the old save is used.
    let current: MemoryRow[] = memories;
    const memory: MemoryStore = {
      remember: async (owner, kind, value) => {
        if (!db.saveMemory) { await db.remember(owner, kind, value, MEMORY_LIMIT); return { ok: true }; }
        const replace = replacedMemory(current, kind as MemoryKind, value);
        const stamp = new Date().toISOString();
        const next = replace ? current.map(row => (row.id === replace.id ? { ...row, value, updated_at: stamp } : row)) : [{ id: 'new', kind, value, updated_at: stamp }, ...current];
        const evict = overLimit(next).filter(row => row.id !== 'new');
        const id = await db.saveMemory(owner, { kind, value, source: 'explicit', channel, ...(replace ? { replace } : {}), ...(evict.length ? { evict } : {}) });
        current = next.filter(row => !evict.includes(row)).map(row => (row.id === 'new' ? { ...row, id: id ?? 'new' } : row));
        return { ok: true, replaced: Boolean(replace) };
      },
      list: async () => current.filter(row => row.id !== 'new'),
      forget: async (owner, rows) => {
        if (!db.forgetMemories) return 0;
        const count = await db.forgetMemories(owner, rows, channel);
        current = current.filter(row => !rows.some(gone => gone.id === row.id));
        return count;
      },
    };
    selected = selectMemories(memories, input.text, undefined, { hasAttachment: Boolean(input.attachment) });
    const tokensLeft = limits.tokenLimit === null ? undefined : Math.max(0, limits.tokenLimit - reserved.usedTokens + RESERVE_TOKENS);
    reply = await runAssistant({
      user, plan, text: input.text, history: input.history, pageName: input.pageName, channel: input.channel, attachment: input.attachment,
      preferredName: selected.preferredName, communicationProfile: selected.communicationProfile, memories: selected.memories,
      trialLeft: limits.requestLimit === null ? undefined : Math.max(0, limits.requestLimit - reserved.usedRequests),
      tokensLeft,
      access: { period_end: asPlan(value).periodEnd ?? null, tokens_reset_at: limits.resetsAt?.toISOString() ?? null, token_limit: limits.tokenLimit },
    }, { config, proposals, memory, providers: deps.providers, fetchImpl: deps.fetchImpl, now: deps.now, signal: deps.signal,
      loadVaultFiles: db.listVaultFiles ? () => db.listVaultFiles!(userId) : undefined });
  } catch (error) {
    // A failed answer costs nothing.
    await db.settle({ userId, requestId, tokens: 0, costUsd: 0, model: null, route: null, promptVersion: null, release: true }).catch(() => undefined);
    // Which route the failed request had, and how it failed (no user words); best effort like the release above.
    await (async () => db.saveRouting?.(userId, requestId, { ...failedRouting(input, config, error, Date.now() - started), channel }))().catch(() => undefined);
    if (error instanceof AiUnavailableError) throw new HttpError(503, 'เลขากระรอกยังไม่พร้อมใช้งาน', 'ai_unavailable');
    if (error instanceof ProviderError || (error as Error)?.name === 'TimeoutError' || (error as Error)?.name === 'AbortError') {
      throw new HttpError(503, 'เลขากระรอกตอบไม่ทันในตอนนี้ กรุณาลองใหม่อีกครั้ง', 'ai_provider');
    }
    throw error;
  }

  // Pro and the trial pay the real cost in Krarok Tokens (a request-count limit, if set, charges nothing).
  const charged = limits.requestLimit !== null ? 0 : reply.tokens;
  const last = reply.calls.at(-1);
  await db.settle({ userId, requestId, tokens: charged, costUsd: reply.costUsd, model: last?.model ?? null, route: reply.route, promptVersion: reply.promptVersion, release: false });
  // The routing log rides on the same usage row, written separately so that it can never block the charge above
  // (before 20261025130000_ai_routing_log.sql runs, the column is missing and this does nothing).
  if (reply.routing) await db.saveRouting?.(userId, requestId, { ...reply.routing, channel }).catch(() => undefined);
  // The memories this answer used stay fresh (unused ones expire after 12 months); a failure here costs nothing.
  const used = (selected?.rows ?? []).map(row => row.id).filter(id => /^[0-9a-f-]{36}$/.test(id));
  if (used.length) await db.touchMemories?.(userId, used).catch(() => undefined);
  // What the feature knowledge missed, for the owner's weekly report (package D); never charged, never blocks.
  if (reply.signals?.length) await db.saveSignals?.(userId, reply.signals, input.channel === 'line' ? 'line' : 'app', reply.promptVersion).catch(() => undefined);
  return {
    text: reply.text, cards: reply.cards, route: reply.route, tokens: charged, ...(reply.memo ? { memo: reply.memo } : {}),
    tokensLeft: limits.tokenLimit === null ? null : Math.max(0, limits.tokenLimit - (reserved.usedTokens - RESERVE_TOKENS + charged)),
    trialLeft: limits.requestLimit === null ? null : Math.max(0, limits.requestLimit - reserved.usedRequests),
  };
}

/**
 * The user changed fields on a confirmation card (owner, 2026-10-24: "แก้ไขยอดได้ในแชทเลย"). The same tool prepares
 * the card again from the original call with those fields changed, with every check it always runs; no model call,
 * no tokens. The new card replaces the old one, which is cancelled.
 */
export async function reviseProposal(db: AssistantDb, userId: string, proposalId: string, edits: Record<string, string | number>, options: { isAdmin?: boolean } = {}): Promise<{ card: AssistantCard }> {
  const stored = await db.getProposal?.(userId, proposalId);
  const allowed = stored?.tool ? EDITABLE_FIELDS[stored.tool] : undefined;
  if (!stored || stored.userId !== userId || !stored.tool || !stored.args || !allowed) {
    throw new HttpError(409, 'รายการนี้แก้ในการ์ดไม่ได้แล้ว บอกเลขาได้ว่าจะแก้อะไร', 'ai_revise_unavailable');
  }
  const args: Record<string, unknown> = { ...stored.args };
  const earlier = learnedPairs(stored.args);
  delete args.__learn;
  const was: Record<string, unknown> = {};
  for (const [field, raw] of Object.entries(edits)) {
    if (!allowed.includes(field)) throw new HttpError(400, 'แก้ช่องนี้ในการ์ดไม่ได้', 'ai_revise_field');
    was[field] = cardValue(stored.tool, args, stored.record as Record<string, unknown> | null, field);
    applyCardEdit(stored.tool, args, field, String(raw ?? '').trim().slice(0, 200));
  }
  // What the user changed on เลขา's card is a lesson, learned only if they then confirm it (package B).
  const lessons = mergePairs(earlier, Object.keys(edits).map(field => pairFromCardEdit(stored.tool!, field, was[field], cardValue(stored.tool!, args, null, field), args))
    .filter((pair): pair is LearnPair => Boolean(pair)));
  // An edited quotation keeps its number (the old card is cancelled, so the number was never used).
  const number = (stored.record as { documentNo?: unknown } | null)?.documentNo;
  if (stored.tool === 'propose_add_document' && typeof number === 'string' && number && !args.document_no) args.document_no = number;
  const { user, versions, absentRecords } = await db.loadAccount(userId);
  if (user.user_id !== userId) throw new HttpError(403, 'ข้อมูลบัญชีไม่ตรงกับผู้ใช้งาน', 'ai_account_mismatch');
  const proposals: ProposalStore = { save: proposal => db.saveProposal({ ...proposal, baseVersion: proposalBaseVersion(proposal, versions, absentRecords) }) };
  const toolbox = createToolbox({ user, proposals, memory: { remember: async () => undefined }, isAdmin: options.isAdmin, learn: lessons });
  const outcome = await toolbox({ id: 'revise', name: stored.tool, args });
  if (outcome.card?.kind !== 'confirm') {
    const result = outcome.result as { error?: string; missing?: string[] } | null;
    throw new HttpError(422, result?.error || (result?.missing?.length ? `ยังขาด: ${result.missing.join(', ')}` : 'แก้รายการนี้ไม่สำเร็จ'), 'ai_revise_invalid');
  }
  await db.cancelProposal(userId, proposalId).catch(() => false);
  return { card: outcome.card };
}

export type ConfirmResult = { status: 'applied'; kind: Proposal['kind']; jobId?: string; recordId?: string; documentId?: string; path?: string };

/** Apply a proposal the user confirmed, through the app's own save with the version the AI read. */
export async function confirmProposal(db: AssistantDb, userId: string, proposalId: string, options: { channel?: 'app' | 'line' } = {}): Promise<ConfirmResult> {
  const proposal = await db.claimProposal(userId, proposalId);
  if (!proposal) throw new HttpError(409, 'รายการนี้ยืนยันไปแล้วหรือหมดเวลา กรุณาขอให้เลขาเตรียมใหม่', 'ai_proposal_gone');
  if (proposal.userId !== userId) throw new HttpError(403, 'ข้อมูลบัญชีไม่ตรงกับผู้ใช้งาน', 'ai_account_mismatch');
  let changes;
  try {
    changes = proposalChanges(proposal, proposal.baseVersion);
  } catch {
    await db.finishProposal(userId, proposalId, 'stale');
    throw new HttpError(409, 'ข้อมูลที่เตรียมไว้ไม่ผ่านการตรวจของแอป กรุณาขอให้เลขาเตรียมใหม่', 'ai_proposal_invalid');
  }
  let applied: boolean;
  try { applied = await db.applyChanges(userId, changes); }
  catch (error) {
    // Not applied: the user may press confirm again.
    await db.finishProposal(userId, proposalId, 'pending').catch(() => undefined);
    throw error;
  }
  if (!applied) {
    await db.finishProposal(userId, proposalId, 'stale');
    throw new HttpError(409, 'รายการนี้ถูกแก้ไขจากอีกช่องทางหลังเลขาเตรียมไว้ กรุณาขอให้เลขาเตรียมใหม่', 'ai_proposal_stale');
  }
  await db.finishProposal(userId, proposalId, 'applied');
  // A confirmed correction becomes this account's rule (package B); learning never costs the confirmation.
  await learnFromConfirmed(db, userId, proposal, options.channel ?? 'app').catch(() => console.warn('assistant: correction not learned'));
  const target = proposalTarget(proposal.kind);
  if (target.table === 'cashflow_jobs') return { status: 'applied', kind: proposal.kind, jobId: proposal.jobId };
  const path = target.table === 'cashflow_invoices' ? (target.op === 'delete' ? '/invoice' : documentPath({ id: proposal.jobId, documentType: proposal.record!.documentType as 'quotation' | 'invoice' }))
    : target.table === 'cashflow_expenses' ? '/incomeExpense' : target.table === 'cashflow_goals' ? '/split' : proposal.kind === 'edit_issuer_profile' ? '/invoice' : '/settings';
  return { status: 'applied', kind: proposal.kind, recordId: proposal.jobId, path,
    ...(target.table === 'cashflow_invoices' && target.op !== 'delete' ? { documentId: proposal.jobId } : {}) };
}
