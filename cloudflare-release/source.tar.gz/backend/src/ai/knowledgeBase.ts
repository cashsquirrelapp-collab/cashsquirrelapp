import { isPhaseOneFeatureAvailable } from '../../../shared/featureAvailability.js';
import { PRO_PRICING } from '../../../shared/proPricing.js';

// Maintained against implemented screens. Runtime status and account permissions remain authoritative.
export interface AppFeature {
  id: string;
  navigation: string;
  name_th: string;
  name_en: string;
  route: string;
  status: 'live' | 'admin_only';
  description: string;
  availability?: string;
  how_to: readonly string[];
  limits?: readonly string[];
  keywords: readonly string[];
  verified_from: string;
}
function feature(entry: Omit<AppFeature, 'status'>): AppFeature {
  return { ...entry, status: isPhaseOneFeatureAvailable(entry.navigation, false) ? 'live' : 'admin_only' };
}

export const KNOWLEDGE_BASE = {
  version: 'kb-2026-10-24.2',
  route_pattern: '/{page}/{workspace}; workspace is the current permitted workspace slug, never invent it.',
  availability: 'นี่คือฟีเจอร์ที่มีในระบบ เมนูจำกัดสิทธิ์เปิดได้สำหรับผู้ดูแลที่ยืนยันสิทธิ์กับบัญชีปัจจุบัน ผู้ใช้ทั่วไปอาจไม่เห็นเมนูนั้น AI, LINE, แจ้งเตือน และชำระเงินยังขึ้นกับสิทธิ์และสถานะบริการจริง ห้ามสรุปว่าผู้ใช้เข้าไม่ได้โดยไม่ดูบริบทสิทธิ์',
  plans: {
    free: 'เครื่องมือเงินหลักและเอกสารใหม่ 10 ฉบับต่อเดือน; สิทธิ์ AI ตรวจจากสถานะบัญชี หน้าตัวอย่างไม่ใช่ AI จริง',
    trial: 'สิทธิ์ Pro ตามวันสิ้นสุดและโควตาที่บัญชีได้รับ; โควตา AI ตรวจจากสถานะปัจจุบัน ไม่รับประกันจำนวนข้อความต่อโทเคน',
    pro: 'ราคาโปรโมชั่น ฿' + PRO_PRICING.month.total + '/เดือน, ฿' + PRO_PRICING.halfYear.total + '/6 เดือน, ฿' + PRO_PRICING.year.total.toLocaleString('en-US') + '/ปี; เอกสารไม่จำกัดและบริการ Pro ตามสถานะบัญชี; AI ใช้โควตาตามสถานะบริการ',
    admin: 'ผู้ดูแลเห็นเมนูจำกัดสิทธิ์; หน้าภาพรวมผู้ดูแลต้องมีสิทธิ์ดูสถิติผู้ดูแลเพิ่มเติม',
  },
  features: [
    feature({
      id: 'dashboard', navigation: 'dashboard', name_th: 'ภาพรวม', name_en: 'Overview', route: '/dashboard/{workspace}',
      description: 'สรุปมูลค่างาน รับเงินจริง รอรับเงิน รายจ่าย กำไรสุทธิ และกราฟของเดือนที่เลือก พร้อมรายการที่ต้องติดตาม',
      how_to: ['เลือกเดือนด้านบน', 'กดกำไรสุทธิเพื่อเปิดงบรายเดือน หรือใช้ปุ่มลัดรับเงิน เพิ่มรายรับ และเพิ่มรายจ่าย'],
      limits: ['ข้อมูลที่บันทึกในแอป ไม่ใช่ยอดบัญชีธนาคารแบบสด'],
      keywords: ['ภาพรวม', 'หน้าแรก', 'dashboard', 'overview', 'สรุปเดือน', 'กำไร'],
      verified_from: 'frontend/src/features/dashboard/DashboardTab.tsx',
    }),
    feature({
      id: 'jobs', navigation: 'jobs', name_th: 'งาน', name_en: 'Jobs', route: '/jobs/{workspace}',
      description: 'จัดการงานและรายรับ ค้นหาและกรองเดือน ลูกค้า ประเภทงาน สถานะงาน/ชำระ บันทึกส่งงาน มัดจำ รับบางส่วน แบ่งงวด และเครดิตเทอม',
      how_to: ['กดเพิ่มงาน กรอกชื่องาน มูลค่า และรายละเอียด', 'เปิดงานเพื่อแก้ไข หรือกดส่งงานแล้ว/รับเงินแล้วเลือกยอดและวันที่', 'ใช้ปุ่มนำเข้าและส่งออกบนหน้างานสำหรับไฟล์ข้อมูล'],
      limits: ['ยอดรับสะสมต้องไม่เกินยอดสุทธิหลังหัก ณ ที่จ่าย; งวดชำระต้องมากกว่า 0', 'เลขาเสนอเพิ่ม แก้ไข ลบงาน และรับเงินผ่านการ์ดยืนยัน; ยังไม่บันทึกจนกดยืนยัน'],
      keywords: ['งาน', 'โปรเจกต์', 'โปรเจค', 'jobs', 'project', 'รับเงิน', 'ส่งงาน', 'เครดิตเทอม', 'แบ่งงวด', 'มัดจำ'],
      verified_from: 'frontend/src/features/jobs/JobsTab.tsx, JobFormDrawer.tsx, JobPaymentDialog.tsx',
    }),
    feature({
      id: 'calendar', navigation: 'calendar', name_th: 'ปฏิทิน', name_en: 'Calendar', route: '/calendar/{workspace}',
      description: 'ดูกำหนดส่งงานและกำหนดรับเงินตามวันที่ เพื่อวางแผนและติดตามงาน',
      how_to: ['เลือกเดือนและวันที่ในปฏิทิน', 'กดรายการเพื่อดูงานและกำหนดรับเงิน'],
      keywords: ['ปฏิทิน', 'calendar', 'กำหนดส่ง', 'กำหนดรับ', 'วันส่งงาน', 'ตารางงาน'],
      verified_from: 'frontend/src/features/calendar/CalendarTab.tsx',
    }),
    feature({
      id: 'receivables', navigation: 'receivables', name_th: 'เงินรอรับ', name_en: 'Receivables', route: '/receivables/{workspace}',
      description: 'ติดตามยอดค้างรับ งานเกินกำหนด ครบกำหนดวันนี้ และใกล้ถึงกำหนด เป็นเมนูย่อยของปฏิทิน',
      how_to: ['เปิดปฏิทิน → เงินรอรับ', 'เลือกสถานะที่ต้องติดตาม แล้วเปิดงานเพื่อบันทึกรับเงินจริง'],
      keywords: ['เงินรอรับ', 'ค้างรับ', 'ลูกหนี้', 'ทวงเงิน', 'เกินกำหนด', 'receivables', 'overdue'],
      verified_from: 'frontend/src/features/receivables/ReceivablesTab.tsx',
    }),
    feature({
      id: 'expenses', navigation: 'incomeExpense', name_th: 'รายรับ–รายจ่าย', name_en: 'Income and expenses', route: '/incomeExpense/{workspace}',
      description: 'ดูรายรับ บันทึกรายจ่ายตามจำนวน หมวดหมู่ วันที่ และจัดการรายการประจำ',
      how_to: ['เปิดรายรับ–รายจ่าย เลือกช่วงที่ต้องการ', 'เพิ่มรายจ่าย ใส่ยอด หมวดหมู่ และวันที่ หรือจัดการรายการประจำ'],
      keywords: ['รายรับรายจ่าย', 'รายรับ–รายจ่าย', 'รายจ่าย', 'ค่าใช้จ่าย', 'รายจ่ายประจำ', 'incomeExpense', 'expenses', 'expense'],
      verified_from: 'frontend/src/features/incomeExpense/IncomeExpenseTab.tsx',
    }),
    feature({
      id: 'goals', navigation: 'split', name_th: 'เป้าหมาย', name_en: 'Goals', route: '/split/{workspace}',
      description: 'สร้างเป้าหมายเงินออม ตั้งยอดและสัดส่วนจัดสรร ติดตามเงินที่บันทึกและความคืบหน้า',
      availability: 'เมนูขึ้นกับการเปิดฟีเจอร์เป้าหมายและรูปแบบการใช้งานในตั้งค่าด้วย',
      how_to: ['กดสร้างเป้าหมาย ตั้งชื่อและยอดเป้าหมาย', 'กำหนดสัดส่วนจัดสรรและบันทึกเงินเข้า/ออก', 'เปิดเป้าหมายเพื่อดูรายละเอียดและประวัติ'],
      limits: ['เป็นการจัดสรรและบันทึกในแอป ไม่ได้โอนเงินจริงเข้าธนาคาร'],
      keywords: ['เป้าหมาย', 'ออมเงิน', 'เงินออม', 'แบ่งเงิน', 'จัดสรร', 'goals', 'split'],
      verified_from: 'frontend/src/features/goals/SplitTab.tsx; frontend/src/app/App.tsx',
    }),
    feature({
      id: 'report', navigation: 'report', name_th: 'รายงาน', name_en: 'Reports', route: '/report/{workspace}',
      description: 'วิเคราะห์รายได้ตามเดือน ลูกค้า ประเภทงาน และเครดิตเทอม; ส่งออกรายรับรายเดือนหรือทั้งปีเป็น Excel และสรุปรายงาน/ข้อมูลงานเป็น CSV',
      how_to: ['เปิดรายงาน เลือกภาพรวม ลูกค้า ประเภทงาน หรือเครดิตเทอม และช่วงข้อมูล', 'ส่งออกทั้งปี: ส่งออก → รายรับรายเดือน / ทั้งปี (Excel) → ทั้งปี → เลือกปี → ดาวน์โหลด Excel', 'ปีไทยแสดง พ.ศ. เช่น 2569 = ค.ศ. 2026; ไฟล์ทั้งปีมี 2 ชีต: สรุปรายเดือน และรายการทั้งหมด', 'รายรับส่งออกยึดวันที่รับเงินจริง รวมแต่ละงวด แสดงยอดก่อนหัก ภาษีหัก ณ ที่จ่าย และรับจริง'],
      limits: ['รายงานละเอียดและตัวเลือกบางอย่างขึ้นกับ Pro', 'ยอดทั้งปีต้องอ่านทั้งปีที่ระบุ ไม่ใช้ยอดเดือนปัจจุบันแทน', 'เลขาสรุปข้อมูลได้; ดาวน์โหลดไฟล์ผ่านปุ่มส่งออกในหน้าเว็บ'],
      keywords: ['รายงาน', 'report', 'reports', 'ส่งออก', 'export', 'excel', 'xlsx', 'csv', 'รายรับทั้งปี', 'รายได้ทั้งปี', 'รายงานประจำปี', 'annual', 'yearly', 'ทั้งปี', 'รายได้ตามลูกค้า', 'ประเภทงาน'],
      verified_from: 'frontend/src/features/report/ReportTab.tsx, IncomeExport.tsx',
    }),
    feature({
      id: 'tax', navigation: 'tax', name_th: 'ภาษี', name_en: 'Tax', route: '/tax/{workspace}',
      description: 'เตรียมข้อมูลภาษีรายปี แยกรับเงินจริงครึ่งปี/ทั้งปี บันทึกค่าใช้จ่ายหักได้ ค่าลดหย่อน เครดิตภาษี และภาษีประเมินที่ยืนยันแล้ว ส่งออก Excel/CSV ได้',
      how_to: ['เลือกปีภาษี', 'ตรวจรายรับและหัก ณ ที่จ่าย กรอกค่าใช้จ่ายหักได้และค่าลดหย่อนที่ตรวจสอบแล้ว', 'กรอกภาษีประเมินจากแบบปัจจุบันหรือผู้เชี่ยวชาญเพื่อดูยอดชำระเพิ่ม/ชำระไว้เกิน', 'กดส่งออก Excel หรือ CSV เพื่อเตรียมเอกสารประกอบ'],
      limits: ['รายจ่ายในบัญชีแสดงอ้างอิง ไม่หักเป็นค่าใช้จ่ายทางภาษีอัตโนมัติ', 'แอปไม่ตัดสินหน้าที่ยื่น ประเภทเงินได้ หรือภาษีขั้นต่ำ และไม่ยื่นภาษีแทน'],
      keywords: ['ภาษี', 'ปีภาษี', 'tax', 'ภงด', 'ภ.ง.ด.', 'ลดหย่อน', 'ภาษีครึ่งปี', 'ยื่นภาษี'],
      verified_from: 'frontend/src/features/tax/TaxTab.tsx',
    }),
    feature({
      id: 'documents', navigation: 'invoice', name_th: 'เอกสาร', name_en: 'Documents', route: '/invoice/{workspace}',
      description: 'สร้างใบเสนอราคา ใบแจ้งหนี้ ใบเสร็จ ใบกำกับภาษี และใบเสร็จ/ใบกำกับภาษี เชื่อมเอกสารถัดไปกับงาน/ลูกค้า พิมพ์หรือบันทึก PDF',
      how_to: ['เปิดเอกสาร เลือกชนิดแล้วกดสร้าง', 'เลือกงาน/ลูกค้า ตรวจข้อมูลผู้ออกและรายละเอียด', 'บันทึกแล้วใช้พิมพ์/PDF หรือออกเอกสารถัดไปตามประเภทที่รองรับ'],
      limits: ['Free สร้างใหม่ได้ 10 ฉบับต่อเดือน; Pro ไม่จำกัดตามสิทธิ์บัญชี', 'เลขาค้นหาเอกสารที่บันทึกแล้วได้ แต่เครื่องมือเสนองานไม่ได้สร้างเอกสารแทนหน้านี้'],
      keywords: ['เอกสาร', 'ใบเสนอราคา', 'ใบแจ้งหนี้', 'ใบเสร็จ', 'ใบกำกับภาษี', 'quotation', 'invoice', 'documents', 'receipt', 'pdf'],
      verified_from: 'frontend/src/features/invoices',
    }),
    feature({
      id: 'vault', navigation: 'vault', name_th: 'คลังเอกสาร', name_en: 'File vault', route: '/vault/{workspace}',
      description: 'เก็บไฟล์ใบ 50 ทวิ สัญญา PO และหลักฐานรายจ่าย ค้นหา กรอง ผูกกับงาน/รายจ่าย เปิดดู ดาวน์โหลด และแก้ไขข้อมูลไฟล์',
      how_to: ['เปิดเอกสาร → คลังเอกสาร → เพิ่มเอกสาร', 'ระบุประเภทและผูกกับงานหรือรายจ่าย', 'ค้นหา/กรองประเภทหรือปีที่อัปโหลด; เปิดเมนูไฟล์เพื่อดู ดาวน์โหลด แก้ไขข้อมูล หรือลบ', 'ดาวน์โหลดไฟล์ที่แสดงเป็น ZIP รวมแยกโฟลเดอร์ตามงานได้'],
      limits: ['รองรับ PDF, JPG, PNG, WEBP ไม่เกิน 10 MB ต่อไฟล์', 'ผลค้นหาของเลขาเป็นข้อมูลรายการไฟล์ ไม่ใช่เนื้อหาที่อ่านจากภาพ/PDF; ห้ามอ้างว่าตรวจเนื้อหาแล้วจากชื่อไฟล์'],
      keywords: ['คลังเอกสาร', 'คลังไฟล์', 'vault', 'สัญญา', 'ใบสั่งซื้อ', 'purchase order', 'ไฟล์แนบ', 'อัปโหลด'],
      verified_from: 'frontend/src/features/vault/VaultPage.tsx, VaultTab.tsx',
    }),
    feature({
      id: 'wht50', navigation: 'wht50', name_th: 'ติดตามใบ 50 ทวิ', name_en: 'Withholding certificates', route: '/wht50/{workspace}',
      description: 'ติดตามหนังสือรับรองหัก ณ ที่จ่ายของงานที่รับเงินจริงแล้ว ตามปีภาษีและสถานะใบรับรอง พร้อมเชื่อมไฟล์ในคลัง',
      how_to: ['เปิดเอกสาร → ติดตามใบ 50 ทวิ', 'เลือกปีภาษีและสถานะ แล้วเปิดงานเพื่อแนบ/ดูใบรับรอง', 'รายการไม่มีวันที่รับเงินจริงแยกไว้ในไม่ระบุปีภาษี'],
      limits: ['ระบบจัดงานหัก 1% เป็น e-WHT และไม่นับเป็นรายการรอใบ; เป็นกฎแสดงผลของแอป ไม่ใช่การตรวจยืนยันกับกรมสรรพากร', 'ดูสถานะตามข้อมูลและหลักฐาน ไม่สรุปสิทธิ์เครดิตภาษีจากชื่อไฟล์เพียงอย่างเดียว'],
      keywords: ['50 ทวิ', '50ทวิ', 'wht50', 'wht', 'withholding', 'หนังสือรับรอง', 'ใบรับรองหัก', 'e-withholding'],
      verified_from: 'frontend/src/features/vault/Wht50Page.tsx, Wht50Panel.tsx, vaultStatus.ts',
    }),
    feature({
      id: 'team', navigation: 'groups', name_th: 'ทีม', name_en: 'Teams', route: '/groups/{workspace}',
      description: 'จัดการทีม สมาชิก บทบาท และพื้นที่การเงินร่วมตามสิทธิ์; ผู้ดูแลในโหมดจริงจัดการทีมได้',
      availability: 'ผู้ใช้ทั่วไป/ผู้เยี่ยมชมที่เห็นหน้าตัวอย่างทีมจะเห็นข้อมูลตัวอย่าง ไม่เรียก API ทีม; โหมดจริงต้องผ่านสิทธิ์ผู้ดูแลและทีม',
      how_to: ['เปิดทีม เลือกหรือสร้างทีมเมื่อมีสิทธิ์', 'จัดการสมาชิก/บทบาทตามสิทธิ์', 'เลือกพื้นที่การเงินที่ได้รับอนุญาตจากตัวเลือกพื้นที่ทำงาน'],
      limits: ['ข้อมูลตัวอย่างทีมไม่ใช่สมาชิกหรือยอดจริง; เลขาไม่มีเครื่องมือเพิ่มสมาชิกหรือเปลี่ยนสิทธิ์ทีม'],
      keywords: ['ทีม', 'กลุ่ม', 'สมาชิกทีม', 'เชิญสมาชิก', 'groups', 'team', 'teams', 'พื้นที่ร่วม'],
      verified_from: 'frontend/src/features/groups/GroupsTab.tsx; frontend/src/app/App.tsx',
    }),
    feature({
      id: 'adminDashboard', navigation: 'adminDashboard', name_th: 'ภาพรวมผู้ดูแล', name_en: 'Admin dashboard', route: '/adminDashboard/{workspace}',
      description: 'หน้าผู้ดูแลสำหรับภาพรวมระบบ การใช้ฟีเจอร์ รายได้/Pro รายบัญชี ข้อความจากผู้ใช้ และจัดการระบบ',
      availability: 'ต้องเป็นผู้ดูแลและมีสิทธิ์ดูสถิติผู้ดูแลของบัญชีปัจจุบัน; ไม่ใช่รายงานการเงินส่วนตัว',
      how_to: ['เมื่อมีสิทธิ์ เปิดภาพรวมผู้ดูแล เลือกหมวดและช่วงข้อมูล', 'เปิดรายบัญชีหรือจัดการระบบเฉพาะรายการที่สิทธิ์อนุญาต'],
      limits: ['เลขาไม่มีเครื่องมืออ่านสถิติผู้ดูแลหรือข้อมูลบัญชีอื่น; ห้ามใช้ยอดส่วนตัวแทนสถิติระบบ'],
      keywords: ['ผู้ดูแล', 'แอดมิน', 'admin', 'adminDashboard', 'สถิติระบบ', 'จัดการระบบ'],
      verified_from: 'frontend/src/features/groups/AdminDashboard.tsx; frontend/src/app/App.tsx',
    }),
    feature({
      id: 'assistant', navigation: 'assistant', name_th: 'เลขากระรอก', name_en: 'AI secretary', route: '/assistant/{workspace}',
      description: 'เลขา AI เชื่อม Gemini เมื่อบัญชีและบริการพร้อม ช่วยอธิบายเว็บ ค้นข้อมูลที่บันทึก สรุปเงิน และเสนอเพิ่ม/แก้ไข/ลบงานหรือรับเงินให้ยืนยัน มีพิมพ์ด้วยเสียงและอ่านคำตอบออกเสียง',
      availability: 'หน้าแชตตามสิทธิ์ Pro/ทดลองใช้/ผู้ดูแล; การเชื่อมจริงขึ้นกับสถานะ AI การเปิดบริการ และโควตา ถ้าแสดงโหมดตัวอย่างไม่ใช่คำตอบ AI จริงและไมค์ถอดเสียงปิดอยู่',
      how_to: ['พิมพ์คำถามหรือเปิดเลขาจากมุมหน้าจอ', 'กดไมค์ อนุญาตไมค์ พูดพร้อมดูคลื่นเสียง → หยุด → รอถอดเสียง → ตรวจและแก้ข้อความ → กดส่งเอง', 'ระหว่างอัดเก็บเสียงในเครื่อง; หยุดแล้วจึงส่งถอดเสียงหนึ่งครั้ง สูงสุด 60 วินาที; ยกเลิกก่อนส่งถอดเสียงทิ้งเสียงและรักษาร่างเดิม', 'การถอดเสียงและส่งแชตเป็นคนละคำขอที่อาจใช้โควตา; ไม่ส่งแชตอัตโนมัติหลังหยุด', 'กดอ่านออกเสียงที่คำตอบเพื่อให้เบราว์เซอร์อ่าน; การแก้ข้อมูลต้องยืนยันการ์ด'],
      limits: ['สิทธิ์และโทเคนยึดสถานะจริง ไม่รับประกันจำนวนข้อความต่อโทเคน', 'ค้นข้อมูลไฟล์ไม่เท่ากับอ่านเนื้อหา; สร้างเอกสาร/นำเข้าข้อมูลผ่านหน้าที่เกี่ยวข้อง'],
      keywords: ['เลขา', 'assistant', 'ai', 'gemini', 'แชต', 'แชท', 'ไมค์', 'เสียง', 'ถอดเสียง', 'พูด', 'waveform', 'microphone', 'transcribe'],
      verified_from: 'frontend/src/features/assistant/assistantApi.ts, useDictation.ts, audioRecorder.ts, VoiceComposer.tsx; backend/src/ai',
    }),
    feature({
      id: 'feedback', navigation: 'feedback', name_th: 'บอกเรา', name_en: 'Feedback', route: '/feedback/{workspace}',
      description: 'ส่งความคิดเห็น แจ้งปัญหา เสนอไอเดีย และติดตามบทสนทนากับทีม',
      how_to: ['เปิดบอกเรา เลือกประเภท เขียนรายละเอียดแล้วส่ง', 'เปิดเรื่องเดิมเพื่อติดตามและตอบกลับ'],
      keywords: ['บอกเรา', 'feedback', 'แจ้งปัญหา', 'เสนอไอเดีย', 'ข้อเสนอแนะ', 'ติดต่อทีม'],
      verified_from: 'frontend/src/features/feedback',
    }),
    feature({
      id: 'plans', navigation: 'plans', name_th: 'การสมัครสมาชิก', name_en: 'Subscription', route: '/plans/{workspace}',
      description: 'ดูสิทธิ์และสถานะสมาชิก เปรียบเทียบ Free/Pro และเลือกระยะเวลา Pro ตามข้อเสนอที่แสดง',
      availability: 'มีขั้นตอนชำระเงิน; เปิดรับเงินจริงเมื่อ API ยืนยัน checkout_ready และการตั้งค่าชำระเงินพร้อม ห้ามเหมารวมว่าปิดชำระเงินหรือพร้อมทุกบัญชี',
      how_to: ['เปิดการสมัครสมาชิก (บางหน้าชื่ออัปเกรด)', 'ตรวจสิทธิ์ ราคา วันหมดอายุ และเลือกแพ็กเกจที่หน้าเว็บเปิดให้ดำเนินการ'],
      limits: ['เลขาไม่มีเครื่องมือซื้อแพ็กเกจ เปลี่ยนบิล หรือชำระเงินแทน'],
      keywords: ['แพ็กเกจ', 'แพคเกจ', 'ราคา', 'สมาชิก', 'อัปเกรด', 'upgrade', 'plans', 'subscription', 'checkout', 'pro', 'free', 'trial', 'ทดลองใช้'],
      verified_from: 'frontend/src/features/billing/PlansTab.tsx; shared/proPricing.ts',
    }),
    feature({
      id: 'settings', navigation: 'settings', name_th: 'ตั้งค่า', name_en: 'Settings', route: '/settings/{workspace}',
      description: 'จัดการโปรไฟล์ ข้อมูลผู้ออกเอกสาร ภาษา ธีม รูปแบบการใช้งาน การแจ้งเตือน LINE นำเข้า/สำรองข้อมูล และบัญชี',
      how_to: ['เปิดตั้งค่า เลือกหมวดที่ต้องการ', 'การตั้งค่าเกี่ยวกับสมาชิกหรือบริการใช้ได้ตามสิทธิ์และสถานะบัญชี'],
      limits: ['เลขาอ่านการตั้งค่าที่เครื่องมืออนุญาตได้ แต่ไม่มีเครื่องมือแก้ตั้งค่าหรือลบบัญชี'],
      keywords: ['ตั้งค่า', 'settings', 'โปรไฟล์', 'profile', 'ผู้ออกเอกสาร', 'ภาษา', 'ธีม', 'บัญชี', 'สำรองข้อมูล'],
      verified_from: 'frontend/src/features/settings/SettingsTab.tsx, SettingsParts.tsx',
    }),
    feature({
      id: 'import', navigation: 'jobs', name_th: 'นำเข้าข้อมูล', name_en: 'Import', route: '/jobs/{workspace} หรือ /settings/{workspace}',
      description: 'นำเข้างาน/รายจ่ายจากตาราง และเรียกคืนข้อมูลสำรอง JSON จับคู่คอลัมน์และตรวจรายการก่อนบันทึก',
      how_to: ['เปิดงาน → นำเข้า หรือ ตั้งค่า → นำเข้า/ข้อมูลสำรอง', 'เลือกไฟล์ จับคู่คอลัมน์ ตรวจตัวอย่างและรายการซ้ำ ก่อนยืนยัน', 'ตารางรองรับ xlsx, xlsm, xls, csv, ods, txt; JSON สำหรับข้อมูลสำรอง'],
      limits: ['เลขาไม่มีเครื่องมือนำเข้าไฟล์หรือสร้างเอกสาร; เสนองานหนึ่งรายการไม่ใช่การนำเข้าไฟล์'],
      keywords: ['นำเข้า', 'import', 'อิมพอร์ต', 'จับคู่คอลัมน์', 'คืนข้อมูล', 'ข้อมูลสำรอง', 'ไฟล์ excel'],
      verified_from: 'frontend/src/features/import; frontend/src/features/settings',
    }),
    feature({
      id: 'notifications', navigation: 'notifications', name_th: 'การแจ้งเตือน', name_en: 'Notifications', route: 'กระดิ่ง และ /settings/{workspace}',
      description: 'ติดตามกำหนดรับเงินและแจ้งเตือนในแอป ตั้งค่าสรุป/เตือนผ่านช่องทางที่บัญชีรองรับ',
      availability: 'อีเมล/LINE และการส่งอัตโนมัติขึ้นกับ Pro การเชื่อมบัญชี การตั้งค่า และสถานะระบบ',
      how_to: ['เปิดกระดิ่งเพื่อดูรายการ', 'ตั้งค่า → การแจ้งเตือน เพื่อเลือกช่องทางและรายการที่เปิดรับ'],
      keywords: ['แจ้งเตือน', 'notifications', 'กระดิ่ง', 'เตือนรับเงิน', 'เตือนครบกำหนด', 'อีเมลสรุป'],
      verified_from: 'frontend/src/features/notifications; frontend/src/features/settings',
    }),
    feature({
      id: 'line', navigation: 'line', name_th: 'LINE', name_en: 'LINE assistant', route: '/settings/{workspace}',
      description: 'เชื่อม LINE ของบัญชีเพื่อคุยกับเลขา รับสรุป/แจ้งเตือน และทำรายการที่บริการ LINE รองรับ',
      availability: 'ต้องมีสิทธิ์ที่รองรับ เชื่อมบัญชีสำเร็จ และบริการ LINE พร้อม; อย่าสรุปว่าเชื่อมแล้วจากชื่อบัญชี',
      how_to: ['ตั้งค่า → LINE แล้วทำตามขั้นตอนเชื่อมบัญชี', 'ตรวจสถานะเชื่อมต่อและแจ้งเตือนก่อนใช้ผ่าน LINE'],
      limits: ['เลขาในเว็บไม่มีเครื่องมือส่งข้อความหาลูกค้าหรือเพื่อนใน LINE'],
      keywords: ['line', 'ไลน์', 'ไลน', 'เชื่อมไลน์', 'เชื่อม line'],
      verified_from: 'frontend/src/features/settings; backend/src/line',
    }),
  ],
  not_available: [
    { ask: 'ดึงยอดหรือโอนเงินจากบัญชีธนาคารอัตโนมัติ', keywords: ['เชื่อมธนาคาร', 'ดึงยอดธนาคาร', 'โอนเงินอัตโนมัติ', 'bank sync'], answer: 'ยังไม่มีการดึงยอดธนาคารหรือโอนเงินจริงอัตโนมัติ; บันทึกรับเงินและรายจ่ายตามรายการจริง' },
    { ask: 'ยื่นภาษีกับกรมสรรพากรแทนผู้ใช้', keywords: ['ยื่นภาษีแทน', 'ส่งภาษีให้', 'ยื่นให้'], answer: 'แอปช่วยเตรียมข้อมูลและเอกสารประกอบ แต่ไม่ยื่นแบบแทน' },
    { ask: 'ระบบจ่ายเงินเดือนพนักงาน', keywords: ['จ่ายเงินเดือนพนักงาน', 'payroll'], answer: 'ยังไม่มีระบบเงินเดือน; บันทึกรายจ่ายได้ตามรายการที่เกิดขึ้น' },
  ],
} as const;
