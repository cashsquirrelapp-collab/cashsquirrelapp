// Generated from artifacts/ai-secretary/03-knowledge-base.json (with search keywords). Update both together.
// The secretary answers questions about the app only from these entries.

export const KNOWLEDGE_BASE = {
 "version": "kb-2026-10-24.1",
 "app_version": "75b625e (pkg44)",
 "route_pattern": "/{page}/{workspace}  e.g. /jobs/cash-squirrel — the workspace part is the account's own slug",
 "plans": {
  "free": "Core money tools; 10 new documents a month; no AI (เลขากระรอก answers with labelled samples only).",
  "trial": "3 days with Pro rights for accounts created from 25 Oct 2569 (14 days for older accounts). AI during the trial: 25 Krarok Tokens in total (about 10 ordinary messages).",
  "pro": "฿159 / month, ฿849 / 6 months, ฿1,490 / year (shared/proPricing.ts). Unlimited documents, LINE assistant, automatic reminders, LINE summaries, AI by tokens. Checkout is closed at the moment.",
  "admin": "The team: sees every feature, including those not released yet."
 },
 "features": [
  {
   "id": "dashboard",
   "name_th": "ภาพรวม",
   "name_en": "Overview",
   "route": "/dashboard/{workspace}",
   "status": "live",
   "description": "สรุปเดือนที่เลือก: มูลค่างานเดือนนี้ รับเงินจริงเดือนนี้ รอรับเงิน รายจ่ายเดือนนี้ กำไรสุทธิ กราฟรายรับ-รายจ่าย และรายการเงินที่ต้องติดตาม",
   "how_to": [
    "เปลี่ยนเดือนที่ปุ่มเดือนมุมขวาบน",
    "กด กำไรสุทธิ เพื่อเปิดงบรายเดือน",
    "ปุ่มลัด: รับเงินด่วน, เพิ่มรายรับ, เพิ่มรายจ่าย, เพิ่มเติม"
   ],
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "jobs",
    "receivables",
    "expenses"
   ],
   "verified_from": "frontend/src/features/dashboard/DashboardTab.tsx",
   "keywords": [
    "ภาพรวม",
    "หน้าแรก",
    "สรุปเดือน",
    "กำไร",
    "overview",
    "dashboard"
   ]
  },
  {
   "id": "jobs",
   "name_th": "งาน",
   "name_en": "Jobs",
   "route": "/jobs/{workspace}",
   "status": "live",
   "description": "รายการงาน/แหล่งรายได้ทั้งหมด แบ่งแท็บ ทั้งหมด / กำลังทำ / รอรับเงิน / ปิดงานแล้ว ค้นหา เลือกเดือน เรียงลำดับ และกรองตามสถานะงาน การชำระ ประเภทงาน",
   "how_to": [
    "กด เพิ่มงาน มุมขวาบน",
    "แถวงานมีปุ่ม ส่งงานแล้ว และ รับเงิน (เลือกรับครบหรือรับบางส่วน พร้อมวันที่)",
    "ทุกการเปลี่ยนสถานะกด เลิกทำ ได้จากแถบด้านล่าง",
    "ปุ่ม นำเข้าจาก Excel และ ส่งออก อยู่บนหัวหน้า"
   ],
   "inputs": {
    "required": [
     "ชื่องาน",
     "มูลค่างาน"
    ],
    "optional": [
     "ลูกค้า",
     "ประเภทงาน",
     "หัก ณ ที่จ่าย (%)",
     "วันส่งงาน",
     "ระยะเวลารับเงิน (วัน, ไม่นับเสาร์-อาทิตย์และวันหยุดได้)",
     "สถานะงาน: กำลังทำ/ส่งงานแล้ว",
     "ยอดที่รับแล้ว / มัดจำ",
     "แบ่งงวด",
     "บันทึก"
    ]
   },
   "limits": [
    "ยอดที่รับแล้วต้องไม่เกินยอดรับสุทธิ (มูลค่าหลังหัก ณ ที่จ่าย)",
    "แบ่งงวดทุกงวดต้องมากกว่า 0 บาท"
   ],
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "receivables",
    "calendar",
    "documents",
    "import"
   ],
   "verified_from": "frontend/src/features/jobs/JobsTab.tsx, JobFormDrawer.tsx, JobPaymentDialog.tsx",
   "keywords": [
    "งาน",
    "โปรเจกต์",
    "โปรเจค",
    "project",
    "job",
    "รับเงิน",
    "ส่งงาน",
    "แบ่งงวด",
    "มัดจำ",
    "หัก ณ ที่จ่าย",
    "ภาษีหัก",
    "wht"
   ]
  },
  {
   "id": "calendar",
   "name_th": "ปฏิทิน",
   "name_en": "Calendar",
   "route": "/calendar/{workspace}",
   "status": "live",
   "description": "ปฏิทินวันรับเงินและวันส่งงาน มีมุมมองไทม์ไลน์เงินเข้า",
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "receivables",
    "jobs"
   ],
   "verified_from": "frontend/src/features/calendar/",
   "keywords": [
    "ปฏิทิน",
    "ไทม์ไลน์",
    "calendar",
    "timeline"
   ]
  },
  {
   "id": "receivables",
   "name_th": "เงินค้างรับ",
   "name_en": "Receivables",
   "route": "/receivables/{workspace}",
   "status": "live",
   "description": "เงินที่ลูกค้ายังไม่จ่าย เรียงจากเลยกำหนด ครบกำหนดวันนี้ และใกล้ครบกำหนด อยู่ใต้เมนูปฏิทิน",
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "jobs",
    "notifications",
    "line"
   ],
   "verified_from": "shared/featureAvailability.ts (receivables), frontend/src/app/App.tsx NAV_ITEMS",
   "keywords": [
    "ค้างรับ",
    "ค้างจ่าย",
    "รอรับเงิน",
    "ยังไม่จ่าย",
    "ทวง",
    "receivable",
    "owed"
   ]
  },
  {
   "id": "expenses",
   "name_th": "รายจ่าย",
   "name_en": "Expenses",
   "route": "/incomeExpense/{workspace}",
   "status": "live",
   "description": "บันทึกรายจ่ายพร้อมหมวด จำนวนเงิน และวันที่ ตั้งเป็นรายจ่ายประจำทุกเดือนได้",
   "how_to": [
    "กด เพิ่มรายจ่าย",
    "ติ๊ก ประจำ เพื่อเพิ่มเข้ารายจ่ายประจำทุกเดือน",
    "แก้หรือเอารายการประจำออกที่ จัดการรายจ่ายประจำ ในหน้ารายจ่าย"
   ],
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "dashboard"
   ],
   "verified_from": "frontend/src/features/incomeExpense/IncomeExpenseTab.tsx, ExpenseDrawer.tsx",
   "keywords": [
    "รายจ่าย",
    "ค่าใช้จ่าย",
    "รายจ่ายประจำ",
    "ประจำ",
    "expense",
    "recurring"
   ]
  },
  {
   "id": "documents",
   "name_th": "เอกสาร",
   "name_en": "Documents",
   "route": "/invoice/{workspace}",
   "status": "live",
   "description": "ออกเอกสาร A4: ใบเสนอราคา (QT), ใบแจ้งหนี้ (INV), ใบเสร็จรับเงิน (REC), ใบกำกับภาษี (TAX) และใบเสร็จรับเงิน/ใบกำกับภาษี (RTX) ออกต่อเป็นเอกสารถัดไปได้ (ใบเสนอราคา → ใบแจ้งหนี้ → ใบเสร็จ) เติมข้อมูลลูกค้าที่เคยบันทึก พิมพ์หรือบันทึก PDF",
   "how_to": [
    "ไปเมนู เอกสาร",
    "กด ออกเอกสารใหม่ แล้วเลือกประเภท",
    "จากเอกสารเดิม ใช้ ออกต่อเป็น… เพื่อสร้างเอกสารถัดไปจากข้อมูลเดิม"
   ],
   "limits": [
    "บัญชีฟรีสร้างเอกสารใหม่ได้ 10 ฉบับต่อเดือน ฉบับที่ 11 จะขึ้นชวนอัปเกรด",
    "Pro ไม่จำกัด"
   ],
   "plans": {
    "free": "10 new documents / month",
    "trial": true,
    "pro": true
   },
   "related": [
    "jobs",
    "vault"
   ],
   "verified_from": "frontend/src/features/invoices/DocumentA4.tsx, documentAvailability.ts, backend/src/services/documentQuota.ts",
   "keywords": [
    "เอกสาร",
    "ใบเสนอราคา",
    "ใบแจ้งหนี้",
    "ใบเสร็จ",
    "ใบกำกับภาษี",
    "บิล",
    "invoice",
    "quotation",
    "receipt",
    "tax invoice",
    "pdf",
    "พิมพ์"
   ]
  },
  {
   "id": "import",
   "name_th": "นำเข้าข้อมูล",
   "name_en": "Import",
   "route": "/jobs/{workspace} (ปุ่ม นำเข้าจาก Excel) หรือ /settings/{workspace}",
   "status": "live",
   "description": "นำเข้างาน/รายจ่ายจาก Excel, CSV, ODS หรือกู้คืนไฟล์สำรอง .json ระบบเดาคอลัมน์ให้ยืนยัน อัปเดตรายการเดิมได้ ย้อนกลับได้ และกระทบยอดกับหน้าภาพรวม",
   "inputs": {
    "file_types": [
     ".xlsx",
     ".xlsm",
     ".xls",
     ".csv",
     ".ods",
     ".txt",
     ".json (backup)"
    ]
   },
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "jobs",
    "expenses"
   ],
   "verified_from": "frontend/src/features/import/ImportWizard.tsx",
   "keywords": [
    "นำเข้า",
    "excel",
    "csv",
    "import",
    "ไฟล์",
    "สำรอง",
    "backup"
   ]
  },
  {
   "id": "notifications",
   "name_th": "แจ้งเตือน",
   "name_en": "Notifications",
   "route": "กระดิ่งมุมขวาบน + /settings/{workspace}",
   "status": "live",
   "description": "แจ้งเตือนในแอป งานเลยกำหนด และแจ้งเตือนกำหนดรับเงินทุกเช้า 08:00 ทางอีเมลและ LINE",
   "plans": {
    "free": "in-app",
    "trial": true,
    "pro": "email + LINE every morning"
   },
   "related": [
    "line",
    "receivables"
   ],
   "verified_from": "shared/featureAvailability.ts (notifications), frontend/src/features/billing/PlansTab.tsx benefits",
   "keywords": [
    "แจ้งเตือน",
    "เตือน",
    "กระดิ่ง",
    "notification",
    "reminder"
   ]
  },
  {
   "id": "line",
   "name_th": "LINE เลขาการเงิน",
   "name_en": "LINE assistant",
   "route": "เชื่อมที่ /settings/{workspace}",
   "status": "live",
   "description": "เชื่อมบัญชี LINE กับ LINE OA ของกระรอกตุนเงิน บันทึกงาน/รายจ่ายด้วยการพิมพ์ใน LINE ดูเงินรอรับ งานที่กำลังทำ สรุปเดือนนี้ และกดตอบแจ้งเตือนรับเงิน (ได้รับแล้ว / ยังไม่ได้ / ได้ไม่ครบ)",
   "plans": {
    "free": false,
    "trial": true,
    "pro": true
   },
   "related": [
    "notifications",
    "assistant"
   ],
   "verified_from": "backend/src/services/lineAssistant.ts, frontend/src/features/billing/PlansTab.tsx",
   "keywords": [
    "line",
    "ไลน์",
    "เชื่อมไลน์"
   ]
  },
  {
   "id": "assistant",
   "name_th": "เลขากระรอก",
   "name_en": "Krarok Secretary",
   "route": "/assistant/{workspace} + ปุ่มน้องกระรอกมุมจอทุกหน้า (Pro)",
   "status": "preview",
   "description": "หน้าแชตเลขา ตอนนี้เป็นตัวอย่างหน้าจอ คำตอบเป็นข้อมูลตัวอย่าง ยังไม่ได้เชื่อม AI (กำลังพัฒนา)",
   "plans": {
    "free": "samples only",
    "trial": "25 Krarok Tokens for the whole trial",
    "pro": "tokens (planned)"
   },
   "related": [
    "line"
   ],
   "verified_from": "frontend/src/features/assistant/assistantApi.ts",
   "keywords": [
    "เลขา",
    "เลขากระรอก",
    "ai",
    "แชต",
    "chat"
   ]
  },
  {
   "id": "feedback",
   "name_th": "บอกเรา",
   "name_en": "Feedback",
   "route": "/feedback/{workspace}",
   "status": "live",
   "description": "ส่งความเห็น แจ้งปัญหา หรือเสนอไอเดียถึงทีม คุยต่อในเธรดเดิมได้",
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [],
   "verified_from": "frontend/src/features/feedback/",
   "keywords": [
    "บอกเรา",
    "ฟีดแบ็ก",
    "feedback",
    "เสนอไอเดีย",
    "แจ้งปัญหา"
   ]
  },
  {
   "id": "settings",
   "name_th": "ตั้งค่า",
   "name_en": "Settings",
   "route": "/settings/{workspace}",
   "status": "live",
   "description": "ข้อมูลโปรไฟล์และผู้ออกเอกสาร ภาษาไทย/อังกฤษ ธีมสว่าง/มืด แจ้งเตือน เชื่อม LINE นำเข้าไฟล์ สลับบัญชี (คอม/iPad สูงสุด 4 บัญชี) และลบบัญชี",
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [
    "line",
    "import"
   ],
   "verified_from": "frontend/src/features/settings/SettingsTab.tsx",
   "keywords": [
    "ตั้งค่า",
    "setting",
    "ภาษา",
    "ธีม",
    "โหมดมืด",
    "สลับบัญชี",
    "ลบบัญชี",
    "โปรไฟล์"
   ]
  },
  {
   "id": "plans",
   "name_th": "อัปเกรด",
   "name_en": "Plans",
   "route": "/plans/{workspace}",
   "status": "live",
   "description": "ราคา Pro ฿159 ต่อเดือน, ฿849 ต่อ 6 เดือน, ฿1,490 ต่อปี ตอนนี้ปิดรับชำระชั่วคราว",
   "plans": {
    "free": true,
    "trial": true,
    "pro": true
   },
   "related": [],
   "verified_from": "shared/proPricing.ts, frontend/src/features/billing/PlansTab.tsx",
   "keywords": [
    "pro",
    "โปร",
    "ราคา",
    "อัปเกรด",
    "แพ็กเกจ",
    "สมัคร",
    "plan",
    "price"
   ]
  },
  {
   "id": "tax",
   "name_th": "ภาษี",
   "name_en": "Tax",
   "route": "/tax/{workspace}",
   "status": "admin_only",
   "description": "ประมาณการภาษีรายปี ส่งออก Excel — ยังไม่เปิดให้ผู้ใช้ทั่วไป",
   "verified_from": "shared/featureAvailability.ts",
   "keywords": [
    "ภาษี",
    "tax",
    "ลดหย่อน"
   ]
  },
  {
   "id": "report",
   "name_th": "รายงาน",
   "name_en": "Reports",
   "route": "/report/{workspace}",
   "status": "admin_only",
   "description": "รายงานและวิเคราะห์รายได้ตามลูกค้า — ยังไม่เปิดให้ผู้ใช้ทั่วไป",
   "verified_from": "shared/featureAvailability.ts",
   "keywords": [
    "รายงาน",
    "วิเคราะห์",
    "report"
   ]
  },
  {
   "id": "goals",
   "name_th": "เป้าหมาย",
   "name_en": "Goals",
   "route": "/split/{workspace}",
   "status": "admin_only",
   "description": "เป้าหมายเงินออม — ยังไม่เปิดให้ผู้ใช้ทั่วไป",
   "verified_from": "shared/featureAvailability.ts",
   "keywords": [
    "เป้าหมาย",
    "ออม",
    "goal",
    "saving"
   ]
  },
  {
   "id": "vault",
   "name_th": "คลังเอกสาร",
   "name_en": "Vault",
   "route": "/vault/{workspace}",
   "status": "admin_only",
   "description": "เก็บไฟล์ 50 ทวิ สัญญา ใบสั่งซื้อ สลิปรายจ่าย — ยังไม่เปิดให้ผู้ใช้ทั่วไป",
   "verified_from": "shared/featureAvailability.ts",
   "keywords": [
    "คลังเอกสาร",
    "vault",
    "เก็บไฟล์",
    "สลิป"
   ]
  },
  {
   "id": "wht50",
   "name_th": "50 ทวิ",
   "name_en": "WHT certificates",
   "route": "/wht50/{workspace}",
   "status": "admin_only",
   "description": "ติดตามหนังสือรับรองหัก ณ ที่จ่าย งานหัก 1% เป็น e-WHT ไม่ต้องรอใบ — ยังไม่เปิดให้ผู้ใช้ทั่วไป",
   "verified_from": "shared/featureAvailability.ts",
   "keywords": [
    "50 ทวิ",
    "50ทวิ",
    "หนังสือรับรอง",
    "wht"
   ]
  },
  {
   "id": "team",
   "name_th": "ทีม",
   "name_en": "Team",
   "route": "/groups/{workspace}",
   "status": "admin_only",
   "description": "บัญชีการเงินร่วมของทีม ผู้ใช้ทั่วไปเห็นเป็นทีมตัวอย่าง ยังไม่ส่งคำเชิญจริง",
   "verified_from": "shared/featureAvailability.ts, tests/e2e/groups.spec.ts",
   "keywords": [
    "ทีม",
    "team",
    "กลุ่ม",
    "group"
   ]
  }
 ],
 "not_available": [
  {
   "ask": "ดึงยอดเงินเข้าจากบัญชีธนาคารอัตโนมัติ",
   "answer": "ยังไม่มี ต้องกดรับเงินเองในหน้างาน เสนอไอเดียได้ที่ บอกเรา"
  },
  {
   "ask": "ยื่นภาษีกับกรมสรรพากรแทนผู้ใช้",
   "answer": "ยังไม่มี แอปช่วยเตรียมตัวเลขเท่านั้น"
  },
  {
   "ask": "จ่ายเงินเดือนพนักงาน",
   "answer": "ยังไม่มี"
  }
 ],
 "update_process": [
  "ทุกแพ็กเกจที่เปลี่ยน/เปิดฟีเจอร์ ให้แก้ entry ที่เกี่ยวข้องและขึ้น version",
  "status มาจาก shared/featureAvailability.ts เสมอ — ควรสร้างไฟล์นี้อัตโนมัติจากโค้ดในขั้น build เพื่อไม่ให้ความรู้ของเลขาเก่ากว่าแอป",
  "Gateway ส่งให้โมเดลเฉพาะ entry ที่ตรงคำถาม (ค้นจากชื่อไทย/อังกฤษและคำพ้อง) ไม่ส่งทั้งไฟล์"
 ]
} as const;
