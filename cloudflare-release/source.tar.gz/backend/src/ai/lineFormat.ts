import { lineAppLink, lineCard, lineValueRow, LINE_CARD_COLORS } from '../services/lineCards.js';
import type { LineMessage } from '../services/line.js';
import type { AssistantCard } from './types.js';

// เลขากระรอก answers in LINE (owner, 2026-10-24: "ส่วนของ LINE AI ยังไม่เชื่อม ทำให้มันเชื่อมด้วย"). LINE shows
// neither Markdown nor tables, so an answer becomes short plain lines, and the chat's cards become the app's own
// formal LINE cards. A confirmation card gets ยืนยัน / ยกเลิก buttons that come back as `ai:confirm:<id>` /
// `ai:cancel:<id>` postbacks; nothing is saved before the user presses ยืนยัน.

const LINE_MAX_MESSAGES = 5;
const LINE_TEXT_MAX = 4800;

/** Plain LINE text from the model's Markdown: a table becomes one "• a · b · c" line per row. */
export function markdownToLineText(markdown: string): string {
  const lines = markdown.replace(/\r/g, '').split('\n');
  const out: string[] = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const isRow = /^\s*\|.*\|\s*$/.test(line);
    if (isRow) {
      const next = lines[i + 1] ?? '';
      // The header row (followed by |---|) only names the columns; the rows say enough on their own.
      if (/^\s*\|?\s*:?-{3,}/.test(next)) { i += 1; continue; }
      if (/^\s*\|?\s*:?-{3,}/.test(line)) continue;
      const cells = line.trim().replace(/^\||\|$/g, '').split('|').map(cell => cell.trim()).filter(cell => cell && cell !== '-');
      if (cells.length) out.push(`• ${cells.join(' · ')}`);
      continue;
    }
    out.push(line
      .replace(/^\s*#{1,6}\s+/, '')
      .replace(/^\s*[-*]\s+/, '• ')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/`([^`]+)`/g, '$1'));
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, LINE_TEXT_MAX);
}

/** The postback a confirmation card's buttons send, or null. Ids are checked again when the proposal is claimed. */
export function decodeAssistantAction(data: string): { action: 'confirm' | 'cancel'; proposalId: string } | null {
  const match = /^ai:(confirm|cancel):(p_[0-9a-f-]{36})$/.exec(data);
  return match ? { action: match[1] as 'confirm' | 'cancel', proposalId: match[2] } : null;
}
/** The text command a postback turns into (what the chat shows as the user's tap), and back. */
export const assistantCommand = (action: 'confirm' | 'cancel', proposalId: string) => `${action === 'confirm' ? 'ยืนยันรายการเลขา' : 'ยกเลิกรายการเลขา'} ${proposalId}`;
export function parseAssistantCommand(text: string): { action: 'confirm' | 'cancel'; proposalId: string } | null {
  const match = /^(ยืนยัน|ยกเลิก)รายการเลขา (p_[0-9a-f-]{36})$/.exec(text.trim());
  return match ? { action: match[1] === 'ยืนยัน' ? 'confirm' : 'cancel', proposalId: match[2] } : null;
}

function cardMessage(card: AssistantCard): LineMessage | null {
  if (card.kind === 'summary') {
    return lineCard({
      title: 'สรุปการเงิน', subtitle: card.period, character: 'report', compact: true,
      metric: { label: 'เงินคงเหลือ', value: card.balance },
      body: [lineValueRow('รายรับ', card.income, { color: LINE_CARD_COLORS.positive }), lineValueRow('รายจ่าย', card.expense, { color: LINE_CARD_COLORS.negative })],
      altText: `สรุปการเงิน ${card.period} รายรับ ${card.income} รายจ่าย ${card.expense} คงเหลือ ${card.balance}`,
      footer: lineAppLink('/dashboard', 'ดูภาพรวมในแอป'),
    });
  }
  if (card.kind === 'document') {
    const link = `${card.path}${card.path.includes('?') ? '&' : '?'}from=line`;
    return lineCard({
      title: card.docType, subtitle: card.number, character: 'document', compact: true,
      body: [lineValueRow('ลูกค้า', card.client, { bold: false }), lineValueRow('ยอดเงิน', card.amount)],
      altText: `${card.docType} ${card.number} · ${card.client} · ${card.amount}`,
      footer: lineAppLink(link, 'เปิดเอกสาร / PDF'),
    });
  }
  if (card.kind === 'confirm') {
    const message = lineCard({
      title: card.title, subtitle: 'รอยืนยัน · ยังไม่บันทึก', character: 'review', compact: true,
      body: card.changes.slice(0, 8).map(row => lineValueRow(row.label, row.value, { bold: false })),
      note: 'กดยืนยันภายใน 30 นาทีเพื่อบันทึก ถ้ารายการถูกแก้จากที่อื่นก่อน ระบบจะไม่เขียนทับ',
      altText: `รอยืนยัน: ${card.title}`,
    }) as Extract<LineMessage, { type: 'flex' }>;
    message.contents = {
      ...(message.contents as object),
      footer: { type: 'box', layout: 'horizontal', spacing: 'sm', paddingAll: '20px', paddingTop: '0px', contents: [
        { type: 'button', style: 'secondary', color: LINE_CARD_COLORS.subtle, height: 'sm', flex: 1,
          action: { type: 'postback', label: 'ยกเลิก', data: `ai:cancel:${card.id}`, displayText: 'ยกเลิกรายการ' } },
        { type: 'button', style: 'primary', color: LINE_CARD_COLORS.accent, height: 'sm', flex: 2,
          action: { type: 'postback', label: 'ยืนยัน', data: `ai:confirm:${card.id}`, displayText: 'ยืนยันรายการ' } },
      ] },
    };
    return message;
  }
  return null;
}

/** One LINE reply: the answer in at most two text bubbles, then up to three cards (LINE allows five messages). */
export function lineAssistantReply(text: string, cards: AssistantCard[]): LineMessage[] {
  const plain = markdownToLineText(text);
  const parts = plain ? plain.split(/\n{2,}/).map(part => part.trim()).filter(Boolean) : [];
  const bubbles = parts.length > 2 ? [parts[0], parts.slice(1).join('\n\n')] : parts;
  const cardMessages = cards.map(cardMessage).filter((message): message is LineMessage => Boolean(message)).slice(0, 3);
  const messages: LineMessage[] = [...bubbles.map(part => ({ type: 'text' as const, text: part })), ...cardMessages];
  return messages.length ? messages.slice(0, LINE_MAX_MESSAGES) : [{ type: 'text', text: 'ขออภัยครับ ตอนนี้ยังตอบไม่ได้ ลองพิมพ์ใหม่อีกครั้งนะครับ' }];
}
