import { lineAppLink, lineCard, lineValueRow, LINE_CARD_COLORS } from '../services/lineCards.js';
import type { LineMessage } from '../services/line.js';
import type { AssistantCard } from './types.js';

// เลขากระรอก answers in LINE (owner, 2026-10-24: "ส่วนของ LINE AI ยังไม่เชื่อม ทำให้มันเชื่อมด้วย"). LINE shows
// neither Markdown nor tables, so an answer becomes short plain lines, and the chat's cards become the app's own
// formal LINE cards. A confirmation card gets ยืนยัน / ยกเลิก buttons that come back as `ai:confirm:<id>` /
// `ai:cancel:<id>` postbacks; nothing is saved before the user presses ยืนยัน.

const LINE_MAX_MESSAGES = 5;
const LINE_TEXT_MAX = 4800;

const MONEY_CELL = /฿\s*-?[\d,]|-?[\d,]+(\.\d+)?\s*บาท$/;
const MAX_LIST_ITEMS = 5;

/** One table row as a LINE item: "• name · amount", the other cells on a second, indented line. */
function rowItem(cells: string[]): string {
  const [name, ...rest] = cells;
  const moneyAt = rest.findIndex(cell => MONEY_CELL.test(cell));
  const money = moneyAt >= 0 ? rest.splice(moneyAt, 1)[0] : '';
  const head = `• ${name}${money ? ` · ${money}` : ''}`;
  return rest.length ? `${head}\n   ${rest.join(' · ')}` : head;
}

/** "1. ลูกค้าคือใคร  2. ส่งงานแล้วหรือยัง" written on one line becomes one question per line. */
function splitInlineList(line: string): string[] {
  if (!/(^|\s)1[.)]\s/.test(line) || !/\s2[.)]\s/.test(line)) return [line];
  // Split only where the numbering continues (2, 3, 4…), so "เครดิต 15, 30) วัน" stays whole.
  const parts: string[] = [];
  let expected = 2;
  let from = 0;
  for (const match of line.matchAll(/\s+(\d{1,2})[.)]\s/g)) {
    if (Number(match[1]) !== expected) continue;
    parts.push(line.slice(from, match.index));
    from = match.index! + match[0].length - match[0].trimStart().length;
    expected += 1;
  }
  parts.push(line.slice(from));
  // "ขอรายละเอียดครับ 1. ลูกค้า": the lead-in keeps its own line.
  const lead = /^(.*?\S)\s+(1[.)]\s.*)$/.exec(parts[0]);
  if (lead && !/^1[.)]\s/.test(parts[0])) parts.splice(0, 1, lead[1], lead[2]);
  return parts.map(part => part.trim()).filter(Boolean);
}

/** A long paragraph becomes one sentence per line (Thai has no full stop: split after ครับ/ค่ะ, ! or ?). */
function sentenceLines(line: string): string[] {
  if (line.length <= 90 || /^\s*(•|\d{1,2}[.)]\s)/.test(line)) return [line];
  return line.split(/(?<=ครับ|ค่ะ|คะ|[!?])\s+(?=\S)|(?<=[a-z0-9)]\.)\s+(?=[A-Z])/u).map(part => part.trim()).filter(Boolean);
}

const isItem = (line: string) => line.startsWith('• ');
const isContinuation = (line: string) => /^ {2,}\S/.test(line);

/** At most five items in a row (the rest is in the app), with a blank line around every list. */
function shapeLists(lines: string[]): string[] {
  const out: string[] = [];
  for (let i = 0; i < lines.length; i += 1) {
    if (!isItem(lines[i])) { out.push(lines[i]); continue; }
    const items: string[][] = [];
    while (i < lines.length && (isItem(lines[i]) || (items.length && isContinuation(lines[i])))) {
      if (isItem(lines[i])) items.push([lines[i]]); else items[items.length - 1].push(lines[i]);
      i += 1;
    }
    i -= 1;
    if (out.length && out[out.length - 1] !== '') out.push('');
    const shown = items.length > MAX_LIST_ITEMS + 1 ? items.slice(0, MAX_LIST_ITEMS) : items;
    out.push(...shown.flat());
    if (shown.length < items.length) out.push(`• …และอีก ${items.length - shown.length} รายการ ดูต่อในแอป`);
    if (i + 1 < lines.length && lines[i + 1] !== '') out.push('');
  }
  return out;
}

/** Plain LINE text from the model's Markdown, shaped for a phone (owner, 2026-10-24: "ยาวเหยียด ตัวหนังสือติดกัน"). */
export function markdownToLineText(markdown: string): string {
  const lines = markdown.replace(/\r/g, '').split('\n');
  const out: string[] = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const isRow = /^\s*\|.*\|\s*$/.test(line);
    if (isRow) {
      const next = lines[i + 1] ?? '';
      // The header row (followed by |---|) only names the columns; the rows say enough on their own.
      if (/^\s*\|?\s*:?-{3,}/.test(next)) { i += 1; continue; }
      if (/^\s*\|?\s*:?-{3,}/.test(line)) continue;
      const cells = line.trim().replace(/^\||\|$/g, '').split('|').map(cell => cell.trim().replace(/\*\*([^*]+)\*\*/g, '$1')).filter(cell => cell && cell !== '-');
      if (cells.length) out.push(...rowItem(cells).split('\n'));
      continue;
    }
    const plain = line
      .replace(/^\s*#{1,6}\s+/, '')
      .replace(/^\s*[-*]\s+/, '• ')
      .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .trimEnd();
    for (const part of splitInlineList(plain)) out.push(...sentenceLines(part));
  }
  return shapeLists(out).join('\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, LINE_TEXT_MAX);
}

/** The postback a confirmation card's buttons send, or null. Ids are checked again when the proposal is claimed. */
export function decodeAssistantAction(data: string): { action: 'confirm' | 'cancel'; proposalId: string } | null {
  const match = /^ai:(confirm|cancel):(p_[0-9a-f-]{36})$/.exec(data);
  return match ? { action: match[1] as 'confirm' | 'cancel', proposalId: match[2] } : null;
}
/** The text command a postback turns into (what the chat shows as the user's tap), and back. */
export const assistantCommand = (action: 'confirm' | 'cancel', proposalId: string) => `${action === 'confirm' ? 'ยืนยันรายการเลขา' : 'ยกเลิกรายการเลขา'} ${proposalId}`;
export function parseAssistantCommand(text: string): { action: 'confirm' | 'cancel'; proposalId: string } | null {
  const match = /^(ยืนยัน|ยกเลิก)รายการเลขา (p_[0-9a-f-]{36})$/.exec(text.trim());
  return match ? { action: match[1] === 'ยืนยัน' ? 'confirm' : 'cancel', proposalId: match[2] } : null;
}

function cardMessage(card: AssistantCard): LineMessage | null {
  if (card.kind === 'summary') {
    return lineCard({
      title: 'สรุปการเงิน', subtitle: card.period, character: 'report', compact: true,
      metric: { label: 'เงินคงเหลือ', value: card.balance },
      body: [lineValueRow('รายรับ', card.income, { color: LINE_CARD_COLORS.positive }), lineValueRow('รายจ่าย', card.expense, { color: LINE_CARD_COLORS.negative })],
      altText: `สรุปการเงิน ${card.period} รายรับ ${card.income} รายจ่าย ${card.expense} คงเหลือ ${card.balance}`,
      footer: lineAppLink('/dashboard', 'ดูภาพรวมในแอป'),
    });
  }
  if (card.kind === 'document') {
    const link = `${card.path}${card.path.includes('?') ? '&' : '?'}from=line`;
    return lineCard({
      title: card.docType, subtitle: card.number, character: 'document', compact: true,
      body: [lineValueRow('ลูกค้า', card.client, { bold: false }), lineValueRow('ยอดเงิน', card.amount)],
      altText: `${card.docType} ${card.number} · ${card.client} · ${card.amount}`,
      footer: lineAppLink(link, 'เปิดเอกสาร / PDF'),
    });
  }
  if (card.kind === 'confirm') {
    const message = lineCard({
      title: card.title, subtitle: 'รอยืนยัน · ยังไม่บันทึก', character: 'review', compact: true,
      body: card.changes.slice(0, 8).map(row => lineValueRow(row.label, row.value, { bold: false })),
      note: 'กดยืนยันภายใน 30 นาทีเพื่อบันทึก ถ้ารายการถูกแก้จากที่อื่นก่อน ระบบจะไม่เขียนทับ',
      altText: `รอยืนยัน: ${card.title}`,
    }) as Extract<LineMessage, { type: 'flex' }>;
    message.contents = {
      ...(message.contents as object),
      footer: { type: 'box', layout: 'horizontal', spacing: 'sm', paddingAll: '20px', paddingTop: '0px', contents: [
        { type: 'button', style: 'secondary', color: LINE_CARD_COLORS.subtle, height: 'sm', flex: 1,
          action: { type: 'postback', label: 'ยกเลิก', data: `ai:cancel:${card.id}`, displayText: 'ยกเลิกรายการ' } },
        { type: 'button', style: 'primary', color: LINE_CARD_COLORS.accent, height: 'sm', flex: 2,
          action: { type: 'postback', label: 'ยืนยัน', data: `ai:confirm:${card.id}`, displayText: 'ยืนยันรายการ' } },
      ] },
    };
    return message;
  }
  return null;
}

/** One LINE reply: the answer in at most two text bubbles, then up to three cards (LINE allows five messages). */
export function lineAssistantReply(text: string, cards: AssistantCard[]): LineMessage[] {
  const plain = markdownToLineText(text);
  const parts = plain ? plain.split(/\n{2,}/).map(part => part.trim()).filter(Boolean) : [];
  const bubbles = parts.length > 2 ? [parts[0], parts.slice(1).join('\n\n')] : parts;
  const cardMessages = cards.map(cardMessage).filter((message): message is LineMessage => Boolean(message)).slice(0, 3);
  const messages: LineMessage[] = [...bubbles.map(part => ({ type: 'text' as const, text: part })), ...cardMessages];
  return messages.length ? messages.slice(0, LINE_MAX_MESSAGES) : [{ type: 'text', text: 'ขออภัยครับ ตอนนี้ยังตอบไม่ได้ ลองพิมพ์ใหม่อีกครั้งนะครับ' }];
}
