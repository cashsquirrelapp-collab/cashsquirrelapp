import { KNOWLEDGE_BASE } from './knowledgeBase.js';

// Finds the app-knowledge entries a question is about, so the model gets a few relevant entries instead of the
// whole knowledge base. Plain text matching on names, keywords and descriptions; no model call.

type Feature = (typeof KNOWLEDGE_BASE)['features'][number];
type Missing = (typeof KNOWLEDGE_BASE)['not_available'][number];

const norm = (text: string) => text.toLowerCase().replace(/\s+/g, ' ').trim();

function score(feature: Feature, query: string): number {
  let total = 0;
  if (query.includes(norm(feature.name_th))) total += 6;
  if (query.includes(norm(feature.name_en))) total += 4;
  for (const keyword of feature.keywords) if (query.includes(norm(keyword))) total += keyword.length >= 4 ? 3 : 2;
  return total;
}

export interface KnowledgeHit { features: Feature[]; missing: Missing[] }

export function lookupKnowledge(question: string, limit = 3): KnowledgeHit {
  const query = norm(question);
  const features = KNOWLEDGE_BASE.features
    .map(feature => ({ feature, points: score(feature, query) }))
    .filter(row => row.points > 0)
    .sort((a, b) => b.points - a.points)
    .slice(0, limit)
    .map(row => row.feature);
  const missing = KNOWLEDGE_BASE.not_available.filter(item =>
    norm(item.ask).split(' ').some(word => word.length >= 4 && query.includes(word)));
  return { features, missing };
}

// Plain words for the model to repeat, instead of internal codes (the user never sees admin_only or a web path).
const STATUS_TEXT: Record<string, string> = {
  live: 'เปิดให้ใช้แล้ว',
  admin_only: 'ยังไม่เปิดให้ผู้ใช้ทั่วไป (ทีมงานกำลังทดสอบ)',
  preview: 'เปิดให้ลองใช้บางส่วน',
  coming_soon: 'เร็ว ๆ นี้',
};

/** Compact text for the system prompt: what the entry says, where it is, plan rights and its live status. */
export function knowledgeSnippets(hit: KnowledgeHit): string {
  const lines: string[] = [];
  for (const feature of hit.features) {
    const how = 'how_to' in feature && feature.how_to ? ` วิธีใช้: ${(feature.how_to as readonly string[]).join(' / ')}.` : '';
    const limits = 'limits' in feature && feature.limits ? ` ข้อจำกัด: ${(feature.limits as readonly string[]).join(' / ')}.` : '';
    const plans = 'plans' in feature && feature.plans ? ` สิทธิ์: ${JSON.stringify(feature.plans)}.` : '';
    lines.push(`- [${feature.id}] เมนู ${feature.name_th} (${feature.name_en}) — ${STATUS_TEXT[feature.status] ?? 'ยังไม่แน่ชัด'}. ${feature.description}.${how}${limits}${plans}`);
  }
  for (const item of hit.missing) lines.push(`- [not_available] ${item.ask}: ${item.answer}`);
  if (!lines.length) lines.push('- (no entry matched; if the user asks about a feature, call feature_lookup, and never guess)');
  lines.push(`- Plans: ${KNOWLEDGE_BASE.plans.free} | Trial: ${KNOWLEDGE_BASE.plans.trial} | Pro: ${KNOWLEDGE_BASE.plans.pro}`);
  return lines.join('\n');
}
