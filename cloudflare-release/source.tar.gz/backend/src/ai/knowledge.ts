import { KNOWLEDGE_BASE, type AppFeature } from './knowledgeBase.js';

// Finds the app-knowledge entries a question is about, so the model gets a few relevant entries instead of the
// whole knowledge base. Plain text matching on names, keywords and descriptions; no model call.

type Missing = (typeof KNOWLEDGE_BASE)['not_available'][number];

const norm = (text: string) => text.toLowerCase()
  .replace(/[๐-๙]/g, digit => String('๐๑๒๓๔๕๖๗๘๙'.indexOf(digit)))
  .replace(/\s+/g, ' ').trim();

// ASCII words/IDs must not match substrings (e.g. "ai" in "paid" or "pro" in "profile").
function contains(query: string, term: string): boolean {
  const value = norm(term);
  if (!value) return false;
  if (/^[a-z0-9 _-]+$/.test(value)) {
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp('(^|[^a-z0-9_])' + escaped + '($|[^a-z0-9_])').test(query);
  }
  return query.includes(value);
}

function score(feature: AppFeature, query: string): number {
  let total = 0;
  if ([feature.id, feature.navigation].some(alias => contains(query, alias))) total += 30;
  if (contains(query, feature.name_th)) total += feature.name_th.length > 3 ? 6 : 1;
  if (contains(query, feature.name_en)) total += 6;
  for (const keyword of feature.keywords) if (contains(query, keyword)) total += keyword.length >= 4 ? 3 : 1;
  const annual = /ทั้งปี|รายปี|ประจำปี|annual|yearly|(?:ปี|พ\.?ศ\.?|ค\.?ศ\.?)\s*(?:20|25)\d{2}/.test(query);
  if (feature.id === 'report' && annual && /รายรับ|รายได้|รายงาน|ส่งออก|สรุป|income|report|export/.test(query)) total += 15;
  if (feature.id === 'tax' && /ปีภาษี|ภาษี|tax/.test(query)) total += 12;
  if (feature.id === 'wht50' && /50\s*ทวิ|wht50/.test(query)) total += 15;
  if (feature.id === 'import' && /นำเข้า|import/.test(query)) total += 12;
  return total;
}

export interface KnowledgeHit { features: AppFeature[]; missing: Missing[]; catalog?: boolean }

export function lookupKnowledge(question: string, limit = 3): KnowledgeHit {
  const query = norm(question);
  const asksCapabilities = /ทำอะไรได้บ้าง|ช่วยอะไรได้บ้าง|ฟีเจอร์อะไรบ้าง|(?:แอป|เว็บ|ฟีเจอร์|ความสามารถ|เมนู).*มีอะไรบ้าง|what can (you|this app|krarok) do/.test(query);
  const focusedFeature = KNOWLEDGE_BASE.features.some(entry => entry.id !== 'assistant' && (
    contains(query, entry.id) || contains(query, entry.navigation)
    || (entry.name_th.length > 2 && contains(query, entry.name_th))
  ));
  const catalog = /ทุกฟีเจอร์|ทุกฟีเจอ|ฟีเจอร์ทั้งหมด|เมนูทั้งหมด|ทุกเมนู|ความสามารถทั้งหมด|all features|all menus/.test(query)
    || (asksCapabilities && !focusedFeature);
  if (catalog) return { features: [...KNOWLEDGE_BASE.features], missing: [], catalog: true };
  const features = KNOWLEDGE_BASE.features
    .map(feature => ({ feature, points: score(feature, query) }))
    .filter(row => row.points > 0)
    .sort((a, b) => b.points - a.points)
    .slice(0, Math.max(1, Math.min(10, Number.isFinite(limit) ? Math.floor(limit) : 3)))
    .map(row => row.feature);
  const missing = KNOWLEDGE_BASE.not_available.filter(item =>
    item.keywords.some(keyword => contains(query, keyword)));
  return { features, missing };
}

// Routes ground navigation; the assistant normally explains menu labels instead of exposing placeholders.
const STATUS_TEXT: Record<string, string> = {
  live: 'มีเมนูในรุ่นปัจจุบัน; ตรวจสิทธิ์/สถานะบริการที่เกี่ยวข้อง',
  admin_only: 'เมนูจำกัดสิทธิ์: ผู้ดูแลที่มีสิทธิ์ครบเปิดได้; ผู้ใช้ทั่วไปอาจไม่เห็น',
};

/** Compact text for the system prompt: what the entry says, where it is, plan rights and its live status. */
export function knowledgeSnippets(hit: KnowledgeHit): string {
  const lines: string[] = hit.features.length ? [KNOWLEDGE_BASE.availability] : [];
  if (hit.catalog) lines.push('COMPLETE FEATURE CATALOG: give a compact overview of all these areas; expand steps only for the area the user asks about.');
  for (const feature of hit.features) {
    const status = hit.catalog ? (feature.status === 'admin_only' ? 'จำกัดสิทธิ์ผู้ดูแล' : 'ตามสิทธิ์บัญชี/บริการ') : STATUS_TEXT[feature.status];
    const details = hit.catalog ? '' : [
      feature.availability ? ` เงื่อนไข: ${feature.availability}.` : '',
      ` วิธีใช้: ${feature.how_to.join(' / ')}.`,
      feature.limits?.length ? ` ข้อจำกัด: ${feature.limits.join(' / ')}.` : '',
    ].join('');
    lines.push(`- [${feature.id}] ${feature.name_th} (${feature.name_en}) | route: ${feature.route} | ${status}. ${feature.description}.${details}`);
  }
  for (const item of hit.missing) lines.push(`- [not_available] ${item.ask}: ${item.answer}`);
  if (!lines.length) lines.push('- (no entry matched; if the user asks about a feature, call feature_lookup, and never guess)');
  if (!hit.catalog && hit.features.some(feature => feature.id === 'plans')) {
    lines.push(`- Plans: ${KNOWLEDGE_BASE.plans.free} | Trial: ${KNOWLEDGE_BASE.plans.trial} | Pro: ${KNOWLEDGE_BASE.plans.pro} | Admin: ${KNOWLEDGE_BASE.plans.admin}`);
  }
  return lines.join('\n');
}
