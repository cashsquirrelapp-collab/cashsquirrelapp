-- เลขากระรอก learning report (owner-approved plan, package D, 2026-10-25). READ ONLY: it changes nothing.
-- Run it in the Supabase SQL editor (weekly, or whenever you like) and copy the one JSON result back to Claude Code;
-- Claude Code proposes changes to the feature knowledge, prompts or tools from it, and you approve them.
-- No user ids, e-mails or names leave this query; questions were stored without numbers or contact details.
with
  usage7 as (select * from public.cashflow_ai_usage where status = 'settled' and created_at >= now() - interval '7 days'),
  usage30 as (select * from public.cashflow_ai_usage where status = 'settled' and created_at >= now() - interval '30 days'),
  props30 as (select * from public.cashflow_ai_proposals where created_at >= now() - interval '30 days'),
  corr30 as (select * from public.cashflow_ai_corrections where created_at >= now() - interval '30 days'),
  sig7 as (select * from public.cashflow_ai_knowledge_signals where created_at >= now() - interval '7 days'),
  sig30 as (select * from public.cashflow_ai_knowledge_signals where created_at >= now() - interval '30 days')
select jsonb_build_object(
  'generated_at', now(),
  -- Cost: per message (the real provider cost in USD and the Krarok tokens charged), by route and by model.
  'cost_7_days', (select jsonb_build_object('messages', count(*), 'usd_total', round(coalesce(sum(cost_usd), 0), 4),
    'usd_per_message', round(coalesce(avg(cost_usd), 0), 6), 'tokens_per_message', round(coalesce(avg(tokens), 0), 2),
    'active_accounts', count(distinct user_id)) from usage7),
  'cost_by_route_7_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select coalesce(route, 'none') as route, count(*) as messages, round(avg(cost_usd), 6) as usd_per_message from usage7 group by route order by 2 desc) r),
  'cost_by_model_7_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select coalesce(model, 'none') as model, count(*) as messages, round(avg(cost_usd), 6) as usd_per_message from usage7 group by model order by 2 desc) r),
  'usd_per_active_account_30_days', (select round(coalesce(sum(cost_usd) / nullif(count(distinct user_id), 0), 0), 4) from usage30),
  -- Commands: cards prepared, confirmed and cancelled per kind (document success = confirmed / prepared).
  'cards_30_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select kind, count(*) as prepared, count(*) filter (where status = 'applied') as confirmed, count(*) filter (where status = 'cancelled') as cancelled
    from props30 group by kind order by 2 desc) r),
  -- Corrections: what people fixed, and how often per 100 confirmed cards (lower is better).
  'corrections_30_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select domain, count(*) as corrections, count(distinct user_id) as accounts from corr30 group by domain order by 2 desc) r),
  'corrections_per_100_confirmed_cards', (select round(100.0 * (select count(*) from corr30) / nullif((select count(*) from props30 where status = 'applied'), 0), 1)),
  'expense_category_fixes_per_100_new_expenses', (select round(100.0 * (select count(*) from corr30 where domain = 'expense_category')
    / nullif((select count(*) from props30 where kind = 'add_expense' and status = 'applied'), 0), 1)),
  -- Feature knowledge: what people could not find, asked for, or got a wrong menu answer about.
  'signals_7_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select kind, coalesce(feature_id, '-') as feature, count(*) as times, count(distinct user_id) as accounts from sig7 group by kind, feature_id order by 3 desc limit 30) r),
  'questions_7_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select kind, question, count(*) as times from sig7 where question is not null group by kind, question order by 3 desc limit 25) r),
  'wrong_answers_by_prompt_30_days', (select coalesce(jsonb_agg(row_to_json(r)), '[]') from (
    select s.prompt_version, count(*) as wrong_answers, (select count(*) from usage30 u where u.prompt_version = s.prompt_version) as messages
    from sig30 s where s.kind = 'wrong_answer' group by s.prompt_version order by 1) r),
  -- Memory: how many accounts keep memories, and of which kinds.
  'memories', (select jsonb_build_object('accounts', count(distinct user_id), 'total', count(*),
    'by_kind', (select coalesce(jsonb_object_agg(kind, n), '{}') from (select kind, count(*) as n from public.cashflow_ai_memories group by kind) k)) from public.cashflow_ai_memories)
) as report;
