import test from 'node:test';
import assert from 'node:assert/strict';
import { aiConfig } from '../backend/src/ai/config';
import { costUsd, krarokTokens } from '../backend/src/ai/cost';
import { AiUnavailableError, memoryStores, runAssistant } from '../backend/src/ai/gateway';
import { lookupKnowledge } from '../backend/src/ai/knowledge';
import { buildSystemPrompt } from '../backend/src/ai/prompt';
import { geminiProvider } from '../backend/src/ai/providers/gemini';
import { openaiProvider } from '../backend/src/ai/providers/openai';
import { routeMessage } from '../backend/src/ai/router';
import { createToolbox, toolsFor } from '../backend/src/ai/tools';
import type { UserRow } from '../backend/src/services/lineAssistant';

// เลขากระรอก AI Gateway with fake provider responses: no network, no keys, no cost.

const day = (offset: number) => new Date(Date.now() + 7 * 3600_000 + offset * 86400_000).toISOString().slice(0, 10);
const fixture = (): UserRow => ({
  user_id: '22222222-2222-4222-8222-222222222222',
  statuses: [], goals: [], expenses: [], settings: {},
  jobs: [
    { id: 'job-logo', name: 'ออกแบบโลโก้ ตัวอย่าง', client: 'ร้านตัวอย่าง', value: 12000, received: 0, pending: 12000, status: 'pending', creditTerm: 30, postDate: day(-40), payDate: day(-10), isPosted: true },
    { id: 'job-web', name: 'เว็บไซต์ตัวอย่าง', client: 'บริษัท ตัวอย่าง จำกัด', value: 30000, received: 10000, pending: 19700, status: 'partial', whtRate: 1, whtAmount: 300, creditTerm: 30, postDate: day(-5), payDate: day(3), isPosted: true },
    { id: 'job-video', name: 'ตัดต่อวิดีโอ', client: 'ร้านตัวอย่าง', value: 5000, received: 0, pending: 5000, status: 'pending', creditTerm: 0, payDate: null, isPosted: false },
    { id: 'job-done', name: 'ถ่ายภาพสินค้า', client: 'ลูกค้าตัวอย่าง', value: 8000, received: 8000, pending: 0, status: 'done', creditTerm: 0, postDate: day(-2), payDate: day(-2), isPosted: true },
  ],
});
const config = (over: Record<string, string> = {}) => aiConfig({ AI_ENABLED: 'true', GEMINI_API_KEY: 'test-gemini', OPENAI_API_KEY: 'test-openai', AI_ACTION_MODEL: 'gpt-5.4-mini', ...over });

type Sent = { url: string; headers: Record<string, string>; body: any };
function fakeFetch(replies: unknown[], sent: Sent[], status = 200): typeof fetch {
  return (async (url: string, init: RequestInit) => {
    sent.push({ url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) });
    const next = replies.shift();
    if (!next) throw new Error('no more fake replies');
    const reply = next as { status?: number; json: unknown };
    return new Response(JSON.stringify(reply.json), { status: reply.status ?? status, headers: { 'content-type': 'application/json' } });
  }) as unknown as typeof fetch;
}
const geminiText = (text: string, usage = { promptTokenCount: 1000, candidatesTokenCount: 40, thoughtsTokenCount: 10 }) =>
  ({ json: { candidates: [{ content: { role: 'model', parts: [{ text }] } }], usageMetadata: usage } });
const geminiCall = (name: string, args: Record<string, unknown>) =>
  ({ json: { candidates: [{ content: { role: 'model', parts: [{ functionCall: { name, args, id: `c-${name}` }, thoughtSignature: 'sig-1' }] } }], usageMetadata: { promptTokenCount: 900, candidatesTokenCount: 20 } } });
const openaiCall = (name: string, args: Record<string, unknown>) =>
  ({ json: { output: [{ type: 'reasoning', id: 'rs_1', encrypted_content: 'x' }, { type: 'function_call', call_id: `call-${name}`, name, arguments: JSON.stringify(args) }], usage: { input_tokens: 1500, output_tokens: 60, input_tokens_details: { cached_tokens: 1000 }, output_tokens_details: { reasoning_tokens: 30 } } } });
const openaiText = (text: string) =>
  ({ json: { output: [{ type: 'message', content: [{ type: 'output_text', text }] }], usage: { input_tokens: 1700, output_tokens: 50 } } });

test('router: questions stay on the chat model, requests to change data go to the action model', () => {
  assert.equal(routeMessage({ text: 'เดือนนี้ได้เงินเท่าไหร่แล้ว' }), 'chat');
  assert.equal(routeMessage({ text: 'ลบงานยังไง' }), 'chat');
  assert.equal(routeMessage({ text: 'ออกใบแจ้งหนี้ได้ไหม' }), 'chat');
  assert.equal(routeMessage({ text: 'มีฟีเจอร์ออกใบกำกับภาษีไหม' }), 'chat');
  assert.equal(routeMessage({ text: 'บัญชีฟรีออกเอกสารได้กี่ใบ' }), 'chat');
  assert.equal(routeMessage({ text: 'เพิ่มงานออกแบบโลโก้ 5000' }), 'action');
  assert.equal(routeMessage({ text: 'ร้านตัวอย่างโอนมาแล้ว รับเงินครบแล้ว' }), 'action');
  assert.equal(routeMessage({ text: 'ทำใบเสนอราคาให้หน่อย' }), 'action');
  assert.equal(routeMessage({ text: 'สวัสดี', hasAttachment: true }), 'action');
  assert.equal(routeMessage({ text: 'ยืนยัน', pendingConfirmation: true }), 'action');
});

test('cost: Gemini thinking is billed as output, OpenAI cached input is cheaper, unknown models cost the most', () => {
  const usage = { inputTokens: 1_000_000, cachedInputTokens: 0, outputTokens: 1_000_000, thinkingTokens: 1_000_000 };
  assert.equal(costUsd('gemini', 'gemini-3.1-flash-lite', usage), 0.25 + 1.5 * 2);
  assert.equal(costUsd('openai', 'gpt-5.4-mini', { ...usage, cachedInputTokens: 500_000 }), 0.5 * 0.75 + 0.5 * 0.075 + 4.5);
  assert.ok(costUsd('openai', 'some-new-model', usage) > costUsd('openai', 'gpt-5.4-mini', usage));
  assert.equal(krarokTokens(0.0000001, 0.001), 1);
  assert.equal(krarokTokens(0.0021, 0.001), 3);
  assert.equal(krarokTokens(0.002, 0.001), 2);
});

test('config: off unless AI_ENABLED is exactly true, limits clamped', () => {
  assert.equal(aiConfig({}).enabled, false);
  assert.equal(aiConfig({ AI_ENABLED: 'yes' }).enabled, false);
  assert.equal(aiConfig({ AI_ENABLED: 'TRUE' }).enabled, true);
  assert.equal(aiConfig({}).adminsOnly, true, 'admins only until switched to everyone');
  assert.equal(aiConfig({ AI_ADMINS_ONLY: 'false' }).adminsOnly, false);
  assert.equal(aiConfig({ AI_MAX_TOOL_STEPS: '99' }).maxToolSteps, 8);
  assert.deepEqual([aiConfig({}).chatModel, aiConfig({}).actionModel], ['gemini-3.5-flash-lite', 'gemini-3.5-flash-lite'], 'Gemini only by default');
});

test('knowledge: a question finds the matching app feature', () => {
  assert.ok(lookupKnowledge('ใบเสนอราคาอยู่ตรงไหน').features.some(feature => feature.id === 'documents'));
  assert.ok(lookupKnowledge('50 ทวิ คืออะไร').features.some(feature => feature.id === 'wht50'));
});

test('prompt: the shared part comes first and is the same for every user (so providers can cache it)', () => {
  const base = { route: 'chat' as const, plan: 'pro' as const, nowLocal: '24 ต.ค. 2569 10:00', knowledge: '-', accountContext: '{}' };
  const a = buildSystemPrompt({ ...base, preferredName: 'ก' });
  const b = buildSystemPrompt({ ...base, preferredName: 'ข', plan: 'trial', trialLeft: 2 });
  const shared = a.slice(0, a.indexOf('\n\nUSER'));
  assert.ok(shared.length > 1500);
  assert.ok(b.startsWith(shared));
  assert.match(b, /AI requests left: 2/);
});

test('tools: the chat model cannot propose changes, the action model can', () => {
  const chat = toolsFor('chat').map(tool => tool.name);
  const action = toolsFor('action').map(tool => tool.name);
  assert.ok(chat.includes('route_to_action') && !chat.some(name => name.startsWith('propose_')));
  assert.ok(action.includes('propose_add_job') && !action.includes('route_to_action'));
  for (const tool of [...toolsFor('chat'), ...toolsFor('action')]) assert.equal(tool.parameters.type, 'object');
});

test('tools: reads use the account data, lists are capped and never include other accounts', async () => {
  const stores = memoryStores();
  const execute = createToolbox({ user: fixture(), ...stores });
  const owed = await execute({ id: '1', name: 'receivables', args: {} }) as { result: any };
  assert.equal(owed.result.all_unpaid.total, 3);
  assert.equal(owed.result.overdue.rows[0].name, 'ออกแบบโลโก้ ตัวอย่าง');
  const working = await execute({ id: '2', name: 'search_jobs', args: { status: 'working' } }) as { result: any };
  assert.deepEqual(working.result.rows.map((row: any) => row.job_id), ['job-video']);
  const byClient = await execute({ id: '3', name: 'search_jobs', args: { query: 'ร้านตัวอย่าง' } }) as { result: any };
  assert.equal(byClient.result.total, 2);
  const missing = await execute({ id: '4', name: 'get_job', args: { job_id: 'someone-elses-job' } }) as { result: any };
  assert.equal(missing.result.ok, false);
});

test('tools: proposals are validated and saved as proposals only, with a confirmation card', async () => {
  const stores = memoryStores();
  const user = fixture();
  const execute = createToolbox({ user, ...stores });
  assert.equal(((await execute({ id: '1', name: 'propose_add_job', args: { name: 'งานใหม่' } })).result as any).ok, false);
  assert.equal(((await execute({ id: '2', name: 'propose_add_job', args: { name: 'งานใหม่', value: 1000, wht_rate: 150 } })).result as any).ok, false);
  const added = await execute({ id: '3', name: 'propose_add_job', args: { name: 'แปลเอกสาร', value: 4000, client: 'ลูกค้าตัวอย่าง', wht_rate: 3, credit_term_days: 30 } });
  assert.equal(added.card?.kind, 'confirm');
  assert.equal((added.result as any).saved, false);
  const proposal = stores.saved.get((added.result as any).proposal_id)!;
  assert.equal(proposal.kind, 'add_job');
  assert.equal(proposal.record!.pending, 3880);
  assert.equal(proposal.record!.whtAmount, 120);
  assert.equal(user.jobs!.length, 4, 'nothing is written to the account');

  const full = await execute({ id: '4', name: 'propose_record_payment', args: { job_id: 'job-web', mode: 'full', date: '2026-10-24' } });
  const fullRecord = stores.saved.get((full.result as any).proposal_id)!.record!;
  assert.deepEqual([fullRecord.status, fullRecord.received, fullRecord.pending, fullRecord.payDate], ['done', 29700, 0, '2026-10-24']);
  assert.equal(((await execute({ id: '5', name: 'propose_record_payment', args: { job_id: 'job-web', mode: 'partial', amount: 29700 } })).result as any).ok, false);
  assert.equal(((await execute({ id: '6', name: 'propose_record_payment', args: { job_id: 'job-done', mode: 'full' } })).result as any).ok, false);
  const partial = await execute({ id: '7', name: 'propose_record_payment', args: { job_id: 'job-logo', mode: 'partial', amount: 2000, date: '2026-10-24' } });
  const partialRecord = stores.saved.get((partial.result as any).proposal_id)!.record!;
  assert.deepEqual([partialRecord.status, partialRecord.received, partialRecord.pending], ['partial', 2000, 10000]);

  const removed = await execute({ id: '8', name: 'propose_delete_job', args: { job_id: 'job-video' } });
  assert.equal(stores.saved.get((removed.result as any).proposal_id)!.record, null);
  assert.equal(((await execute({ id: '9', name: 'propose_edit_job', args: { job_id: 'job-web', value: 5000 } })).result as any).ok, false, 'value below what was already received');
});

test('Gemini adapter: key in the header, thinking level set, tool results sent back with the model turn unchanged', async () => {
  const sent: Sent[] = [];
  const stores = memoryStores();
  const result = await geminiProvider.run({
    apiKey: 'test-gemini', model: 'gemini-3.1-flash-lite', system: 'SYSTEM', turns: [{ role: 'user', text: 'เดือนนี้ได้เงินเท่าไหร่' }],
    tools: toolsFor('chat'), maxOutputTokens: 600, effort: 'minimal', execute: createToolbox({ user: fixture(), ...stores }),
    fetchImpl: fakeFetch([geminiCall('money_summary', { month: 'this' }), geminiText('เดือนนี้รับแล้ว ฿8,000 ครับ')], sent),
  });
  assert.equal(result.text, 'เดือนนี้รับแล้ว ฿8,000 ครับ');
  assert.equal(sent[0].headers['x-goog-api-key'], 'test-gemini');
  assert.ok(!sent[0].url.includes('test-gemini'), 'the key never goes in the URL');
  assert.equal(sent[0].body.generationConfig.thinkingConfig.thinkingLevel, 'minimal');
  const second = sent[1].body.contents;
  assert.equal(second[1].parts[0].thoughtSignature, 'sig-1');
  assert.equal(second[2].parts[0].functionResponse.name, 'money_summary');
  assert.equal(second[2].parts[0].functionResponse.id, 'c-money_summary');
  assert.deepEqual(result.usage, { inputTokens: 1900, cachedInputTokens: 0, outputTokens: 60, thinkingTokens: 10 });
});

test('Gemini adapter: a model that rejects the thinking setting is retried once without it', async () => {
  const sent: Sent[] = [];
  const result = await geminiProvider.run({
    apiKey: 'k', model: 'gemini-x', system: 'S', turns: [{ role: 'user', text: 'hi' }], tools: [], maxOutputTokens: 100, effort: 'minimal',
    execute: async () => ({ result: null }),
    fetchImpl: fakeFetch([{ status: 400, json: { error: { message: 'thinking_level is not supported' } } }, geminiText('hello')], sent),
  });
  assert.equal(result.text, 'hello');
  assert.equal(sent[1].body.generationConfig.thinkingConfig, undefined);
});

test('OpenAI adapter: nothing stored at OpenAI, reasoning handed back, tool output by call id', async () => {
  const sent: Sent[] = [];
  const stores = memoryStores();
  const result = await openaiProvider.run({
    apiKey: 'test-openai', model: 'gpt-5.4-mini', system: 'SYSTEM', turns: [{ role: 'user', text: 'งานไหนยังไม่ส่ง' }],
    tools: toolsFor('action'), maxOutputTokens: 1200, effort: 'low', execute: createToolbox({ user: fixture(), ...stores }),
    fetchImpl: fakeFetch([openaiCall('search_jobs', { status: 'working' }), openaiText('ยังไม่ส่ง 1 งานครับ')], sent),
  });
  assert.equal(result.text, 'ยังไม่ส่ง 1 งานครับ');
  assert.equal(sent[0].headers.authorization, 'Bearer test-openai');
  assert.equal(sent[0].body.store, false);
  assert.deepEqual(sent[0].body.include, ['reasoning.encrypted_content']);
  const input = sent[1].body.input;
  assert.equal(input[1].type, 'reasoning');
  assert.equal(input[3].type, 'function_call_output');
  assert.equal(input[3].call_id, 'call-search_jobs');
  assert.equal(JSON.parse(input[3].output).rows[0].job_id, 'job-video');
});

test('gateway: off by default, and a missing key stops it before any call', async () => {
  const stores = memoryStores();
  const request = { user: fixture(), plan: 'pro' as const, text: 'สวัสดี' };
  await assert.rejects(runAssistant(request, { config: aiConfig({}), ...stores }), (error: unknown) => error instanceof AiUnavailableError && error.reason === 'disabled');
  const sent: Sent[] = [];
  await assert.rejects(runAssistant(request, { config: config({ OPENAI_API_KEY: '' }), ...stores, fetchImpl: fakeFetch([], sent) }), (error: unknown) => error instanceof AiUnavailableError && error.reason === 'missing_key');
  await assert.rejects(runAssistant(request, { config: aiConfig({ AI_ENABLED: 'true' }), ...stores, fetchImpl: fakeFetch([], sent) }), (error: unknown) => error instanceof AiUnavailableError && error.reason === 'missing_key');
  assert.equal(sent.length, 0);
});

test('gateway: the chat model hands a change to the action model, which returns a card; cost covers both', async () => {
  const sent: Sent[] = [];
  const stores = memoryStores();
  const user = fixture();
  const reply = await runAssistant({ user, plan: 'pro', text: 'ช่วยจดงานแปลเอกสารให้ลูกค้าตัวอย่าง 4,000 บาท' }, {
    config: config(), ...stores,
    fetchImpl: fakeFetch([
      geminiCall('route_to_action', { summary: 'เพิ่มงานแปลเอกสาร 4,000 บาท ลูกค้าตัวอย่าง' }),
      openaiCall('propose_add_job', { name: 'แปลเอกสาร', value: 4000, client: 'ลูกค้าตัวอย่าง' }),
      openaiText('เตรียมงานแปลเอกสาร ฿4,000 ไว้แล้ว กดยืนยันบนการ์ดเพื่อบันทึกครับ'),
    ], sent),
  });
  assert.equal(reply.route, 'action');
  assert.equal(reply.handedOff, true);
  assert.deepEqual(reply.calls.map(call => call.provider), ['gemini', 'openai']);
  assert.equal(reply.cards[0].kind, 'confirm');
  assert.match(sent[1].body.instructions, /HANDOVER FROM THE CONVERSATION ASSISTANT: เพิ่มงานแปลเอกสาร/);
  assert.ok(reply.costUsd > 0 && reply.tokens >= 1);
  assert.equal(user.jobs!.length, 4, 'nothing saved before the user confirms');
  assert.equal(stores.saved.size, 1);
});

test('gateway: a model stuck in tool calls stops at the step limit with a polite reply', async () => {
  const stores = memoryStores();
  const loops = Array.from({ length: 4 }, () => geminiCall('receivables', {}));
  const reply = await runAssistant({ user: fixture(), plan: 'pro', text: 'ใครค้างจ่ายบ้าง' }, { config: config(), ...stores, fetchImpl: fakeFetch(loops, []) });
  assert.equal(reply.calls[0].stoppedAt, 'max_steps');
  assert.match(reply.text, /หลายขั้นตอน/);
});

test('attachments: only real pictures and PDFs up to 4 MB, checked by their first bytes', async () => {
  const { checkAttachment, ATTACHMENT_MAX_BYTES } = await import('../backend/src/ai/attachment');
  const b64 = (bytes: number[]) => Buffer.from(bytes).toString('base64');
  const jpeg = b64([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 4, 5]);
  assert.equal(checkAttachment({ name: 'สลิป.jpg', mimeType: 'image/jpeg', data: jpeg }).mimeType, 'image/jpeg');
  assert.equal(checkAttachment({ name: 'quote.pdf', mimeType: 'application/pdf', data: b64([...Buffer.from('%PDF-1.7 ...')]) }).mimeType, 'application/pdf');
  const refused = (input: { name: string; mimeType: string; data: string }, status: number) =>
    assert.throws(() => checkAttachment(input), (error: any) => error.status === status);
  refused({ name: 'x.jpg', mimeType: 'image/jpeg', data: b64([...Buffer.from('<html>not a picture</html>')]) }, 400);
  refused({ name: 'x.pdf', mimeType: 'application/pdf', data: jpeg }, 400);
  refused({ name: 'x.jpg', mimeType: 'image/jpeg', data: 'not base64!' }, 400);
  refused({ name: 'x.jpg', mimeType: 'image/jpeg', data: Buffer.alloc(ATTACHMENT_MAX_BYTES + 3, 0xff).toString('base64') }, 413);
  assert.equal(checkAttachment({ name: 'a\u0000b\u001f.jpg', mimeType: 'image/jpeg', data: jpeg }).name, 'ab.jpg');
});

test('a picture goes to Gemini as inline data before the words, and the request is routed to the action model', async () => {
  const sent: Sent[] = [];
  const stores = memoryStores();
  const data = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 9, 9]).toString('base64');
  await runAssistant({ user: fixture(), plan: 'pro', text: 'สลิปนี้ของงานไหน', attachment: { name: 'slip.jpg', mimeType: 'image/jpeg', data } },
    { config: config({ AI_ACTION_MODEL: 'gemini-3.5-flash-lite' }), ...stores, fetchImpl: fakeFetch([geminiText('สลิปนี้ ฿3,500 ครับ')], sent) });
  const last = sent[0].body.contents.at(-1);
  assert.deepEqual(last.parts[0], { inlineData: { mimeType: 'image/jpeg', data } });
  assert.equal(last.parts[1].text, 'สลิปนี้ของงานไหน');
  assert.match(sent[0].body.systemInstruction.parts[0].text, /MODE: action/);
  assert.match(sent[0].body.systemInstruction.parts[0].text, /ATTACHMENTS:/);
});
