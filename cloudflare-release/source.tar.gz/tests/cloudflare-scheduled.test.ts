import test from 'node:test';
import assert from 'node:assert/strict';
import { scheduledPaths } from '../cloudflare/schedule.js';
import { runScheduledJobs } from '../migration/scheduled-runner.js';

test('monthly jobs both run when the first returns HTTP 200 with a delivery failure', async () => {
  const paths = scheduledPaths('0 1 1 * *');
  const invoked: string[] = [];
  const logs: unknown[] = [];
  await assert.rejects(runScheduledJobs(paths, async path => {
    invoked.push(path);
    return Response.json(path.endsWith('send-monthly-report')
      ? { processed: 2, sent: 1, failed: 1, recipient: 'must-not-enter-logs@example.invalid' }
      : { processed: 1, sent: 1, failed: 0 });
  }, result => logs.push(result)), /Scheduled jobs failed|scheduled jobs failed/);
  assert.deepEqual(invoked, ['/api/send-monthly-report', '/api/send-wht50-reminder']);
  assert.equal(JSON.stringify(logs).includes('must-not-enter-logs'), false);
  assert.deepEqual(logs.map(log => (log as { outcome: string }).outcome), ['failed', 'ok']);
});

test('uncertain delivery and account-reminder failures fail scheduled executions', async () => {
  for (const body of [{ uncertain: 1 }, { markerFailed: 1 }, { reminderFailed: 1 }, { channels: { email: { failed: 1 } } }]) {
    await assert.rejects(runScheduledJobs(['/api/close-expired-accounts'], async () => Response.json(body), () => {}));
  }
});

test('successful scheduled execution accepts zero failures and known cron mapping', async () => {
  assert.deepEqual(scheduledPaths('0 1 * * *'), ['/api/send-overdue-digest']);
  assert.deepEqual(scheduledPaths('0 2 * * *'), ['/api/close-expired-accounts']);
  await runScheduledJobs(scheduledPaths('0 1 * * *'), async () => Response.json({ processed: 0, failed: 0, skipped: 0 }), () => {});
});
