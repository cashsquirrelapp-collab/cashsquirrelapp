import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import { detectSignals, lookupSignal, redactQuestion } from '../backend/src/ai/signals';

// Package D (owner, 2026-10-25: "ทำชุด D ต่อ"): what the feature knowledge misses is noticed by rules (no model call)
// and kept without numbers; database/ai_learning_report.sql turns it, with cost, cards and corrections, into one
// read-only JSON report the owner runs in Supabase. Synthetic data only.

const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';

test('signals: not found, not available, asked for, and a menu answer the user says was wrong', () => {
  assert.deepEqual(detectSignals('ปุ่มสแกนบาร์โค้ดอยู่ตรงไหนในแอป').map(signal => signal.kind), ['not_found']);
  assert.equal(detectSignals('ออกใบทวิ 50 ได้ไหม')[0]?.kind, 'not_available');
  assert.equal(detectSignals('เมนูปฏิทินภาษีอยู่ตรงไหนในแอป')[0]?.kind, 'not_available', 'a feature not open to everyone yet');
  const asked = detectSignals('อยากให้มีระบบเชื่อมบัญชีธนาคาร 1234567890 อัตโนมัติ');
  assert.deepEqual(asked.map(signal => [signal.kind, signal.question]), [['feature_request', 'อยากให้มีระบบเชื่อมบัญชีธนาคาร # อัตโนมัติ']]);
  const wrong = detectSignals('ผิด ไม่มีเมนูนี้', [{ role: 'user', text: 'ใบเสนอราคาอยู่ตรงไหน' }, { role: 'assistant', text: 'อยู่ในเมนูตั้งค่าครับ' }]);
  assert.deepEqual(wrong.map(signal => [signal.kind, signal.question]), [['wrong_answer', 'ใบเสนอราคาอยู่ตรงไหน']]);
  assert.ok(wrong[0].feature_id, 'the feature the question was about');
  // Ordinary money questions and replies to non-app answers are not signals.
  assert.deepEqual(detectSignals('เดือนนี้ได้เงินเท่าไหร่'), []);
  assert.deepEqual(detectSignals('ไม่ใช่ ร้านกาแฟ', [{ role: 'user', text: 'เพิ่มงานโลโก้ 3000' }, { role: 'assistant', text: 'ลูกค้าคือร้านอาหารใช่ไหม' }]), []);
  assert.equal(lookupSignal('จองคิวลูกค้า')?.kind, 'not_found');
  assert.equal(lookupSignal('ปฏิทินภาษีส่วนตัว'), null, 'known to the knowledge, only not open yet');
  assert.equal(lookupSignal('ใบเสนอราคา'), null);
  assert.equal(redactQuestion('ส่งไปที่ boss@example.com โทร 081-234-5678 ยอด 12,500'), 'ส่งไปที่ [อีเมล] โทร # ยอด #');
});

async function database() {
  const db = new PGlite();
  await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
    create schema auth; create table auth.users(id uuid primary key); insert into auth.users values('${A}'),('${B}');`);
  for (const file of ['database/ai_secretary.sql', 'database/ai_account_actions.sql', 'supabase/migrations/20261024120000_ai_proposal_args.sql', 'supabase/migrations/20261025090000_ai_learning.sql']) {
    await db.exec(await readFile(file, 'utf8'));
  }
  return db;
}

test('the report: cost per message, cards confirmed, corrections per 100, signals, wrong answers per prompt, memories', async () => {
  const db = await database();
  const uuid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
  const prop = (n: number, kind: string, status: string, user = A) => `('p_${uuid(n)}','${user}','${kind}','r${n}','t','[]','${status}')`;
  await db.exec(`
    insert into public.cashflow_ai_usage(request_id,user_id,cycle_key,tokens,status,cost_usd,model,route,prompt_version) values
      ('${uuid(1)}','${A}','2026-10',4,'settled',0.004,'gemini-3.5-flash-lite','chat','secretary-v13'),
      ('${uuid(2)}','${A}','2026-10',20,'settled',0.02,'claude-sonnet-5-5','action','secretary-v13'),
      ('${uuid(3)}','${B}','2026-10',6,'settled',0.006,'gemini-3.5-flash-lite','chat','secretary-v13'),
      ('${uuid(4)}','${B}','2026-10',0,'released',0,null,null,null);
    insert into public.cashflow_ai_proposals(id,user_id,kind,job_id,title,changes,status) values
      ${[prop(10, 'add_expense', 'applied'), prop(11, 'add_expense', 'applied'), prop(12, 'add_expense', 'cancelled'), prop(13, 'add_document', 'applied', B), prop(14, 'add_document', 'pending', B)].join(',')};
    insert into public.cashflow_ai_corrections(user_id,domain,subject,after_value) values ('${A}','expense_category','ร้านสมาน','ค่าอุปกรณ์/ซอฟต์แวร์');
    insert into public.cashflow_ai_knowledge_signals(user_id,kind,feature_id,question,channel,prompt_version) values
      ('${A}','not_found',null,'ปฏิทินภาษีอยู่ไหน','app','secretary-v13'), ('${B}','not_found',null,'ปฏิทินภาษีอยู่ไหน','line','secretary-v13'),
      ('${A}','wrong_answer','documents','ใบเสนอราคาอยู่ตรงไหน','app','secretary-v13');
    insert into public.cashflow_ai_memories(user_id,kind,value) values ('${A}','emoji','ไม่ใช้อีโมจิ'),('${A}','correction','x'),('${B}','tone','สั้น ๆ');`);
  const report = (await db.query<{ report: any }>(await readFile('database/ai_learning_report.sql', 'utf8'))).rows[0].report;
  assert.deepEqual(report.cost_7_days, { messages: 3, usd_total: 0.03, usd_per_message: 0.01, tokens_per_message: 10, active_accounts: 2 });
  assert.equal(report.usd_per_active_account_30_days, 0.015);
  assert.deepEqual(report.cost_by_route_7_days.map((row: any) => [row.route, row.messages]), [['chat', 2], ['action', 1]]);
  const cards = Object.fromEntries(report.cards_30_days.map((row: any) => [row.kind, [row.prepared, row.confirmed, row.cancelled]]));
  assert.deepEqual(cards, { add_expense: [3, 2, 1], add_document: [2, 1, 0] });
  assert.equal(report.corrections_per_100_confirmed_cards, 33.3);
  assert.equal(report.expense_category_fixes_per_100_new_expenses, 50);
  assert.deepEqual(report.questions_7_days[0], { kind: 'not_found', question: 'ปฏิทินภาษีอยู่ไหน', times: 2 });
  assert.deepEqual(report.wrong_answers_by_prompt_30_days, [{ prompt_version: 'secretary-v13', wrong_answers: 1, messages: 3 }]);
  assert.deepEqual(report.memories, { accounts: 2, total: 3, by_kind: { emoji: 1, correction: 1, tone: 1 } });
  // Nothing that identifies an account leaves the report.
  const text = JSON.stringify(report);
  for (const id of [A, B]) assert.equal(text.includes(id), false);
  // Read only.
  assert.doesNotMatch(await readFile('database/ai_learning_report.sql', 'utf8'), /\b(insert|update|delete|drop|alter|create|truncate|grant)\b/i);
});
