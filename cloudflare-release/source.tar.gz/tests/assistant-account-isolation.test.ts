import { afterEach, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { seal } from '../backend/src/security/cookies';
import { routeHandler } from '../backend/src/http/router';
import type { UserRow } from '../backend/src/services/lineAssistant';

// Full router -> session -> repository -> service -> gateway -> tools regression tests.
// Every outgoing request is intercepted. These are synthetic accounts and fake model replies;
// an unrecognised URL throws, so this suite cannot contact a database, Auth or a paid provider.
process.env.APP_URL = 'https://assistant-isolation.example.test';
process.env.SUPABASE_URL = 'https://assistant-isolation.supabase.co';
process.env.SUPABASE_PUBLISHABLE_KEY = 'synthetic-publishable';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'synthetic-service-role';
process.env.SESSION_SECRET = 'assistant-isolation-test-secret-'.repeat(4);
process.env.AI_ENABLED = 'true';
process.env.AI_ADMINS_ONLY = 'false';
process.env.GEMINI_API_KEY = 'synthetic-model-key';
process.env.AI_CHAT_MODEL = 'gemini-3.5-flash-lite';
process.env.AI_ACTION_MODEL = 'gemini-3.5-flash-lite';

const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const owners = [A, B];
const tag = (id: string) => id === A ? 'ACCOUNT_A_CANARY' : 'ACCOUNT_B_CANARY';
const other = (id: string) => id === A ? B : A;
const sid = (id: string) => id.replace(/^./, 'a');
const token = (id: string) => `e30.${Buffer.from(JSON.stringify({ sub: id, session_id: sid(id) })).toString('base64url')}.synthetic`;
function cookie(id: string) {
  return `__Host-cashflow-session=${seal({ access_token: token(id), refresh_token: `synthetic-${id}`, expires_at: Math.floor(Date.now() / 1000) + 3600, issued_at: Date.now() })}`;
}
function account(id: string): UserRow {
  const amount = id === A ? 1 : 10;
  const job = { id: 'shared-job-id', name: `${tag(id)} JOB`, client: `${tag(id)} CLIENT`, type: 'Design',
    value: 1000 * amount, received: 970 * amount, pending: 0, status: 'done', paymentStatus: 'paid', creditTerm: 0,
    payDate: '2026-01-02', whtRate: 3, whtAmount: 30 * amount, installments: [
      { id: 'previous-year', label: 'First', amount: 485 * amount, status: 'paid', dueDate: '2025-12-01', paidAt: '2025-12-31' },
      { id: 'this-year', label: 'Final', amount: 485 * amount, status: 'paid', dueDate: '2026-01-01', paidAt: '2026-01-02' },
    ] };
  return { user_id: id, jobs: [job, { ...job, id: `only-${id}`, value: 200 * amount, received: 200 * amount,
    whtRate: 0, whtAmount: 0, installments: undefined, payDate: '2026-02-01' }],
    expenses: [{ id: 'shared-expense-id', name: `${tag(id)} EXPENSE`, category: 'Equipment', date: '2026-02-02', amount: 30 * amount, note: `${tag(id)} NOTE` }],
    goals: [], statuses: [], settings: {},
    invoices: [{ id: 'shared-document-id', documentType: 'invoice', documentNo: `${tag(id)}-001`, createdDate: '2026-01-01',
      client: { name: `${tag(id)} CLIENT` }, items: [{ id: 'item', description: `${tag(id)} ITEM`, quantity: 1, price: 200 * amount }], vatRate: 0, whtRate: 0 }],
  } as unknown as UserRow;
}

type Call = { name: string; args: Record<string, unknown> };
type Event = { path: string; owner?: string; body?: any };
const realFetch = globalThis.fetch;
let events: Event[];
let modelBodies: { owner: string; body: any }[];
let modelResults: Map<string, any[]>;
let unknownUrls: string[];
let revoked: Set<string>;
let verifiedOwner: string | undefined;
let snapshotOwner: string | undefined;
let snapshotFails: boolean;
let callsFor: (owner: string) => Call[];
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });

beforeEach(() => {
  events = []; modelBodies = []; modelResults = new Map(); unknownUrls = []; revoked = new Set();
  verifiedOwner = undefined; snapshotOwner = undefined; snapshotFails = false;
  callsFor = () => [{ name: 'financial_summary', args: { year: 2569 } }];
  globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(input instanceof Request ? input.url : String(input));
    const body = init?.body ? JSON.parse(String(init.body)) : undefined;
    if (url.host === 'generativelanguage.googleapis.com') {
      const system = String(body.systemInstruction.parts[0].text);
      const owner = owners.find(id => system.includes(tag(id)));
      assert.ok(owner, 'the model receives this request’s scoped memory');
      assert.equal(system.includes(tag(other(owner))), false);
      modelBodies.push({ owner, body });
      const responses = body.contents.flatMap((turn: any) => turn.parts.flatMap((part: any) => part.functionResponse ? [part.functionResponse] : []));
      if (!responses.length) {
        return json({ candidates: [{ content: { role: 'model', parts: callsFor(owner).map(functionCall => ({ functionCall })) } }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 1 } });
      }
      modelResults.set(owner, responses);
      const summary = responses.find((row: any) => row.name === 'financial_summary')?.response.result;
      const text = summary?.ok ? `ปี 2569 รับจริง ${summary.totals.received} บาท ก่อนหัก ${summary.totals.gross} หัก ณ ที่จ่าย ${summary.totals.wht}` : 'ตรวจเฉพาะบัญชีที่ลงชื่อเข้าใช้แล้ว';
      return json({ candidates: [{ content: { role: 'model', parts: [{ text }] } }], usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 1 } });
    }
    if (url.host !== 'assistant-isolation.supabase.co') {
      unknownUrls.push(url.origin + url.pathname); throw new Error('External network disabled in isolation tests');
    }
    if (url.pathname === '/auth/v1/user') {
      const bearer = new Headers(init?.headers).get('authorization')?.replace(/^Bearer /, '') ?? '';
      const identity = JSON.parse(Buffer.from(bearer.split('.')[1], 'base64url').toString()).sub;
      events.push({ path: url.pathname, owner: identity });
      return json({ id: verifiedOwner ?? identity, email: 'synthetic@example.test', created_at: '2026-01-01T00:00:00Z', app_metadata: {}, user_metadata: {} });
    }
    const owner = url.searchParams.get('user_id')?.replace(/^eq\./, '') ?? body?.p_user_id;
    events.push({ path: url.pathname, owner, body });
    if (url.pathname.endsWith('/rpc/cashflow_rate_limit')) return json(true);
    if (url.pathname.endsWith('/rpc/cashflow_session_active')) return json(!revoked.has(owner));
    if (url.pathname.endsWith('/rpc/cashflow_ai_reserve')) return json({ ok: true, used_tokens: 5, used_requests: 1 });
    if (url.pathname.endsWith('/rpc/cashflow_ai_settle')) return json(null);
    if (url.pathname.endsWith('/subscriptions')) return json({ status: 'active', plan: 'admin_grant' });
    if (url.pathname.endsWith('/cashflow_user_roles')) return json({ role: 'user' });
    if (url.pathname.endsWith('/cashflow_ai_usage')) return json([{ tokens: owner === A ? 11 : 22 }]);
    if (url.pathname.endsWith('/cashflow_ai_memories')) return json([{ kind: 'preferred_name', value: tag(owner!) }]);
    if (url.pathname.endsWith('/cashflow_account_snapshot')) {
      if (snapshotFails) return json({ code: 'XX000', message: `${tag(B)} private database error` }, 500);
      assert.ok(owners.includes(owner!), 'repository must include an authenticated owner filter');
      return json({ ...account(snapshotOwner ?? owner!), versions: { cashflow_jobs: {} } });
    }
    if (url.pathname.endsWith('/cashflow_vault_files')) {
      assert.ok(owners.includes(owner!), 'vault must include a personal owner filter');
      assert.equal(url.searchParams.has('group_id'), false);
      return json([{ id: 'shared-vault-id', user_id: owner, group_id: null, kind: 'other', job_id: 'shared-job-id', job_name: `${tag(owner!)} JOB`,
        client: `${tag(owner!)} CLIENT`, file_name: `${tag(owner!)}.pdf`, mime_type: 'application/pdf', size_bytes: 20,
        storage_path: 'PRIVATE_STORAGE_PATH_MUST_NOT_REACH_MODEL', created_at: '2026-01-01T00:00:00Z' }]);
    }
    unknownUrls.push(url.pathname); throw new Error(`Unmocked route ${url.pathname}`);
  }) as typeof fetch;
});
afterEach(() => { globalThis.fetch = realFetch; assert.deepEqual(unknownUrls, [], 'no unexpected I/O'); });

async function request(options: { session?: string | null; header?: string | null; method?: string; body?: unknown; headers?: Record<string, string>; query?: Record<string, string> } = {}) {
  const body = options.body ?? { action: 'message', text: 'รายได้ทั้งปี 2569 รับจริงเท่าไหร่' };
  const raw = Buffer.from(JSON.stringify(body));
  const headers: Record<string, string> = { 'content-type': 'application/json', 'content-length': String(raw.length), origin: process.env.APP_URL!, 'x-csrf-protection': '1', ...options.headers };
  if (options.session !== null) headers.cookie = cookie(options.session ?? A);
  if (options.header !== null) headers['x-account-id'] = options.header ?? A;
  const req = Object.assign(Readable.from([raw]), { method: options.method ?? 'POST', headers, query: options.query ?? {}, url: '/api/assistant', socket: { remoteAddress: '127.0.0.1' } });
  const out = { status: 200, body: undefined as any, headers: new Map<string, unknown>() };
  const res = {
    headersSent: false,
    setHeader(name: string, value: unknown) { out.headers.set(name.toLowerCase(), value); return this; },
    getHeader(name: string) { return out.headers.get(name.toLowerCase()); },
    hasHeader(name: string) { return out.headers.has(name.toLowerCase()); },
    status(status: number) { out.status = status; return this; },
    json(value: unknown) { out.body = value; this.headersSent = true; return this; },
  };
  await routeHandler('assistant')(req as any, res as any);
  assert.equal(out.headers.get('cache-control'), 'no-store');
  return out;
}
const result = (owner: string, name: string, occurrence = 0) => modelResults.get(owner)!.filter(row => row.name === name)[occurrence].response.result;

test('HTTP boundary rejects forged/missing account headers, extra owner/model arguments, group scope and foreign origins before account/model reads', async () => {
  const invalid: { options: Parameters<typeof request>[0]; status: number }[] = [
    { options: { session: null }, status: 401 },
    { options: { header: null }, status: 401 },
    { options: { header: B }, status: 401 },
    { options: { body: { action: 'message', text: 'รายได้', user_id: B } }, status: 400 },
    { options: { body: { action: 'message', text: 'รายได้', account_id: B } }, status: 400 },
    { options: { body: { action: 'message', text: 'รายได้', model: 'untrusted-model' } }, status: 400 },
    { options: { headers: { 'x-finance-group': B } }, status: 400 },
    { options: { headers: { origin: 'https://foreign.example.test' } }, status: 403 },
  ];
  for (const { options, status } of invalid) assert.equal((await request(options)).status, status, JSON.stringify(options));
  assert.equal(modelBodies.length, 0);
  assert.equal(events.some(row => /cashflow_account_snapshot|cashflow_vault_files|cashflow_ai_reserve/.test(row.path)), false);
});

test('revoked sessions and Auth identities that disagree with the sealed session fail closed', async () => {
  revoked.add(A);
  assert.equal((await request()).status, 401);
  revoked.clear(); verifiedOwner = B;
  assert.equal((await request()).status, 401);
  assert.equal(modelBodies.length, 0);
  assert.equal(events.some(row => /cashflow_account_snapshot|cashflow_ai_reserve/.test(row.path)), false);
});

test('concurrent HTTP requests isolate open account data and memories while hidden vault tools cannot load any data', async () => {
  callsFor = () => [
    { name: 'financial_summary', args: { year: 2569 } },
    { name: 'search_receipts', args: { year: 2026, limit: 1 } },
    { name: 'search_receipts', args: { year: 2026, limit: 1, offset: 1 } },
    { name: 'search_documents', args: {} },
    { name: 'account_data', args: { domain: 'documents', id: 'shared-document-id' } },
    { name: 'get_expense', args: { id: 'shared-expense-id' } },
    { name: 'search_vault', args: {} },
    { name: 'search_vault', args: { job_id: 'shared-job-id' } },
  ];
  const replies = await Promise.all(owners.map(owner => request({ session: owner, header: owner })));
  for (const [index, owner] of owners.entries()) {
    assert.equal(replies[index].status, 200);
    const multiplier = owner === A ? 1 : 10;
    const annual = result(owner, 'financial_summary');
    assert.deepEqual([annual.period.year_ce, annual.period.year_be, annual.monthly.rows.length], [2026, 2569, 12]);
    assert.deepEqual([annual.totals.gross, annual.totals.wht, annual.totals.received, annual.totals.actual_expenses], [700, 15, 685, 30].map(value => value * multiplier));
    assert.match(replies[index].body.text, new RegExp(`รับจริง ${685 * multiplier} บาท`));
    const first = result(owner, 'search_receipts'); const second = result(owner, 'search_receipts', 1);
    assert.equal(first.total, 2); assert.equal(first.rows.length, 1); assert.equal(first.next_offset, 1);
    assert.equal(second.rows.length, 1); assert.equal(second.next_offset, null);
    assert.deepEqual(first.totals, second.totals);
    assert.notEqual(first.rows[0].job_id, second.rows[0].job_id);
    for (const name of ['search_documents', 'account_data', 'get_expense']) {
      const detail = JSON.stringify(result(owner, name));
      assert.ok(detail.includes(tag(owner)), `${name} must return this owner’s matching detail`);
      assert.equal(detail.includes(tag(other(owner))), false, name);
    }
    for (const occurrence of [0, 1]) {
      const denied = result(owner, 'search_vault', occurrence);
      assert.equal(denied.ok, false, 'a model-emitted hidden tool must be denied even with an own job ID');
      assert.equal(typeof denied.error, 'string');
      assert.equal(Object.hasOwn(denied, 'rows'), false);
      const detail = JSON.stringify(denied);
      for (const accountId of owners) assert.equal(detail.includes(tag(accountId)), false, 'no account vault metadata enters a denial');
    }
    const payload = JSON.stringify(modelResults.get(owner));
    assert.ok(payload.includes(tag(owner)));
    assert.equal(payload.includes(tag(other(owner))), false);
    assert.equal(payload.includes('PRIVATE_STORAGE_PATH_MUST_NOT_REACH_MODEL'), false);
    assert.equal(events.filter(row => row.path.endsWith('/cashflow_vault_files')).length, 0, 'hidden vault tools must not invoke the repository for either owner');
    for (const path of ['cashflow_account_snapshot', 'cashflow_ai_memories', 'rpc/cashflow_ai_reserve', 'rpc/cashflow_ai_settle']) {
      assert.equal(events.filter(row => row.path.endsWith(`/${path}`) && row.owner === owner).length, 1, path);
    }
  }
  assert.equal(modelBodies.length, 4, 'two fake tool rounds for each request');
  for (const { body } of modelBodies) {
    const declarations = body.tools.flatMap((group: any) => group.functionDeclarations);
    assert.equal(declarations.some((tool: any) => tool.name === 'search_vault'), false, 'the hidden tool is not advertised to either model request');
  }
  // A subsequent request loads A's open data afresh instead of reusing B or an earlier request's snapshot.
  assert.equal((await request()).status, 200);
  assert.equal(events.filter(row => row.path.endsWith('/cashflow_vault_files')).length, 0);
  for (const path of ['cashflow_account_snapshot', 'cashflow_ai_memories', 'rpc/cashflow_ai_reserve', 'rpc/cashflow_ai_settle']) {
    assert.equal(events.filter(row => row.path.endsWith(`/${path}`) && row.owner === A).length, 2, path);
    assert.equal(events.filter(row => row.path.endsWith(`/${path}`) && row.owner === B).length, 1, path);
  }
  assert.equal(result(A, 'financial_summary').totals.received, 685);
  assert.equal(JSON.stringify(modelResults.get(A)).includes(tag(B)), false);
});

test('model owner overrides, foreign record IDs and tools outside the runtime allowlist cannot read another account', async () => {
  callsFor = () => [
    { name: 'financial_summary', args: { year: 2569, user_id: B } },
    { name: 'search_receipts', args: { year: 2569, account_id: B } },
    { name: 'account_data', args: { domain: 'documents', user_id: B } },
    { name: 'search_documents', args: { user_id: B } },
    { name: 'search_vault', args: { user_id: B } },
    { name: 'get_job', args: { job_id: `only-${B}` } },
    { name: 'get_expense', args: { id: 'only-foreign-expense' } },
    { name: 'account_data', args: { domain: 'documents', id: 'only-foreign-document' } },
    { name: 'execute_sql', args: { sql: 'SELECT * FROM cashflow_account_snapshot' } },
    { name: 'propose_delete_job', args: { job_id: 'shared-job-id' } },
  ];
  assert.equal((await request()).status, 200);
  for (const response of modelResults.get(A)!) assert.equal(response.response.result.ok, false, response.name);
  assert.equal(events.some(row => row.owner === B), false);
  assert.equal(events.some(row => row.path.endsWith('/cashflow_vault_files')), false, 'invalid model owner never invokes vault loader');
  assert.equal(JSON.stringify(modelResults.get(A)).includes(tag(B)), false);
});

test('repository ownership mismatch is rejected before model execution and releases only the authenticated reservation', async () => {
  snapshotOwner = B;
  const reply = await request();
  assert.equal(reply.status, 403); assert.equal(reply.body.code, 'ai_account_mismatch');
  assert.equal(modelBodies.length, 0);
  const settled = events.filter(row => row.path.endsWith('/rpc/cashflow_ai_settle'));
  assert.equal(settled.length, 1); assert.equal(settled[0].owner, A); assert.equal(settled[0].body.p_release, true);
  assert.equal(JSON.stringify(reply.body).includes(tag(B)), false);
});

test('status and notification reads bind to the current session, with no shared account cache or model call', async () => {
  for (const owner of [A, B, A]) {
    const status = await request({ method: 'GET', session: owner, header: owner });
    assert.equal(status.status, 200); assert.equal(status.body.tokensLeft, owner === A ? 989 : 978);
    const notices = await request({ method: 'GET', session: owner, header: owner, query: { view: 'line' } });
    assert.equal(notices.status, 200);
    assert.equal(JSON.stringify(notices.body).includes(tag(other(owner))), false);
  }
  assert.equal(modelBodies.length, 0);
  assert.deepEqual(events.filter(row => row.path.endsWith('/cashflow_account_snapshot')).map(row => row.owner), [A, B, A]);
  assert.deepEqual(events.filter(row => row.path.endsWith('/cashflow_ai_usage')).map(row => row.owner), [A, B, A]);
});

test('database failure does not fall back to another snapshot or expose a private error to the client', async () => {
  snapshotFails = true;
  const reply = await request();
  assert.equal(reply.status, 500); assert.equal(modelBodies.length, 0);
  assert.equal(JSON.stringify(reply.body).includes(tag(B)), false);
  assert.equal(events.some(row => row.owner === B), false);
  assert.equal(events.find(row => row.path.endsWith('/rpc/cashflow_ai_settle'))?.body.p_release, true);
});
