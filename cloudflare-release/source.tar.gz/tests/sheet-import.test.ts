import test from 'node:test';
import assert from 'node:assert/strict';
import * as XLSX from 'xlsx';
import {
  analyzeSheet, buildImportPlan, excelSerialDate, fullYear, mapCategory, monthFromName, parseCreditTerm, parseDateText,
  parseMoney, parseRate, parseStatus, planTotals, type SheetCell, type SheetGrid,
} from '../frontend/src/features/import/sheetImport.ts';
import type { Expense, Job } from '../shared/types.ts';
import { readWorkbook } from '../frontend/src/features/import/readWorkbook.ts';

// Import from Excel (owner, 2026-10-22): the sheets people already keep come in many layouts. Each
// test is one layout seen in practice, with example data, and checks what the import makes of it.

const cell = (value: unknown): SheetCell =>
  value === null || value === undefined ? { raw: null, text: '' }
    : typeof value === 'object' && value && 'date' in (value as object) ? value as SheetCell
      : { raw: value as string | number | boolean, text: typeof value === 'number' ? value.toLocaleString('en-US') : String(value) };
const grid = (name: string, rows: unknown[][]): SheetGrid => ({ name, rows: rows.map(row => row.map(cell)) });
const date = (iso: string): SheetCell => ({ raw: 45000, text: iso, date: iso });
const statuses = [
  { id: 'done', label: 'จ่ายเงินครบแล้ว', behavior: 'done' as const },
  { id: 'partial', label: 'มัดจำแล้ว', behavior: 'partial' as const },
  { id: 'pending', label: 'ยังไม่จ่าย', behavior: 'pending' as const },
];
const context = { statuses, jobTypes: ['Sponsored Post'], existingJobs: [] as Job[], existingExpenses: [] as Expense[] };
const options = { amountsAreNet: false, today: '2026-10-22' };
const plan = (sheets: SheetGrid[], opts = options, ctx: typeof context = context) =>
  buildImportPlan(sheets.map(g => ({ grid: g, analysis: analyzeSheet(g) })), opts, ctx);
const targets = (g: SheetGrid) => Object.fromEntries(analyzeSheet(g).columns.map(c => [c.header || `#${c.index}`, c.target]));

test('reading values: dates in Thai and English, Buddhist years, Excel day numbers', () => {
  assert.equal(parseDateText('15/10/2567'), '2024-10-15');
  assert.equal(parseDateText('15/10/67'), '2024-10-15');
  assert.equal(parseDateText('15/10/24'), '2024-10-15');
  assert.equal(parseDateText('2024-10-15'), '2024-10-15');
  assert.equal(parseDateText('15 ต.ค. 67'), '2024-10-15');
  assert.equal(parseDateText('15 ตุลาคม 2567'), '2024-10-15');
  assert.equal(parseDateText('15 Oct 2024'), '2024-10-15');
  assert.equal(parseDateText('Oct 15, 2024'), '2024-10-15');
  assert.equal(parseDateText('10/15/2024', 'mdy'), '2024-10-15');
  assert.equal(parseDateText('31/02/2024'), null);
  assert.equal(parseDateText('ยังไม่กำหนด'), null);
  assert.equal(excelSerialDate(45580), '2024-10-15');
  assert.equal(fullYear(2567), 2024);
  assert.equal(monthFromName('ต.ค. 67'), '2024-10');
  assert.equal(monthFromName('ตุลาคม 2567'), '2024-10');
  assert.equal(monthFromName('Oct 2024'), '2024-10');
  assert.equal(monthFromName('10-2024'), '2024-10');
  assert.equal(monthFromName('สรุป'), null);
});

test('reading values: amounts, rates, credit terms and status words', () => {
  for (const [text, value] of [['฿12,000', 12000], ['12,000.-', 12000], ['12,000 บาท', 12000], ['(500)', -500], ['12k', 12000], ['1.5 หมื่น', 15000], ['-300', -300]] as const) {
    assert.equal(parseMoney({ raw: text, text }), value, text);
  }
  assert.equal(parseMoney({ raw: 'รอยืนยัน', text: 'รอยืนยัน' }), null);
  assert.equal(parseRate({ raw: '3%', text: '3%' }), 3);
  assert.equal(parseRate({ raw: 0.03, text: '0.03' }), 3);
  assert.equal(parseRate({ raw: 1.5, text: '1.5' }), 1.5);
  assert.equal(parseCreditTerm({ raw: '30 วัน', text: '30 วัน' }), 30);
  assert.equal(parseCreditTerm({ raw: 'Net 45', text: 'Net 45' }), 45);
  assert.equal(parseCreditTerm({ raw: 'เงินสด', text: 'เงินสด' }), 0);
  assert.equal(parseStatus({ raw: 'จ่ายแล้ว', text: 'จ่ายแล้ว' }).payment, 'paid');
  assert.equal(parseStatus({ raw: 'โอนแล้ว', text: 'โอนแล้ว' }).payment, 'paid');
  assert.equal(parseStatus({ raw: 'ยังไม่จ่าย', text: 'ยังไม่จ่าย' }).payment, 'unpaid');
  assert.equal(parseStatus({ raw: 'รอโอน', text: 'รอโอน' }).payment, 'unpaid');
  assert.equal(parseStatus({ raw: 'มัดจำ 50%', text: 'มัดจำ 50%' }).payment, 'partial');
  assert.equal(parseStatus({ raw: '✓', text: '✓' }).payment, 'paid');
  assert.equal(parseStatus({ raw: true, text: 'TRUE' }).payment, 'paid');
  assert.equal(parseStatus({ raw: 'กำลังทำ', text: 'กำลังทำ' }).delivered, false);
  assert.equal(parseStatus({ raw: 'ส่งงานแล้ว', text: 'ส่งงานแล้ว' }).delivered, true);
  assert.equal(mapCategory('ค่าแท็กซี่', []), 'ค่าเดินทาง/น้ำมัน');
  assert.equal(mapCategory('Adobe CC', []), 'ค่าอุปกรณ์/ซอฟต์แวร์');
  assert.equal(mapCategory('ค่าจ้างช่างภาพ', []), 'จ้างงานต่อ (Outsource)');
});

test('layout 1: a Thai job sheet with a title, a blank row, Buddhist dates, WHT % and a total row', () => {
  const sheet = grid('งานปี 2567', [
    ['บัญชีงานรับจ้าง ปี 2567'],
    [],
    ['ลำดับ', 'วันที่', 'ชื่องาน', 'ลูกค้า', 'ประเภท', 'ราคา', 'หัก ณ ที่จ่าย', 'สถานะ', 'วันที่รับเงิน', 'หมายเหตุ'],
    [1, '15/10/2567', 'รีวิวครีมกันแดด', 'แบรนด์ตัวอย่าง A', 'Sponsored Post', '12,000', '3%', 'จ่ายแล้ว', '30/10/2567', 'คลิป 60 วิ'],
    [2, '20/10/2567', 'ถ่ายภาพแคมเปญ', 'บริษัท ตัวอย่าง จำกัด', 'ถ่ายภาพ', '8,000', '3%', 'ยังไม่จ่าย', '', ''],
    [3, '01/11/2567', 'ออกแบบโลโก้', 'ร้านตัวอย่าง', 'ออกแบบ', '5,000', '', 'มัดจำ', '', ''],
    ['', '', 'รวม', '', '', '25,000', '', '', '', ''],
  ]);
  const analysis = analyzeSheet(sheet);
  assert.equal(analysis.headerRow, 2);
  assert.equal(analysis.kind, 'jobs');
  assert.deepEqual(targets(sheet), { 'ลำดับ': 'keep', 'วันที่': 'date', 'ชื่องาน': 'name', 'ลูกค้า': 'client', 'ประเภท': 'type', 'ราคา': 'value', 'หัก ณ ที่จ่าย': 'whtRate', 'สถานะ': 'status', 'วันที่รับเงิน': 'paidDate', 'หมายเหตุ': 'note' });
  const result = plan([sheet]);
  const jobs = result.rows.filter(r => r.job);
  assert.equal(jobs.length, 3);
  const [paid, unpaid, deposit] = jobs.map(r => r.job!);
  assert.equal(paid.value, 12000); assert.equal(paid.whtAmount, 360); assert.equal(paid.received, 11640); assert.equal(paid.pending, 0);
  assert.equal(paid.status, 'done'); assert.equal(paid.postDate, '2024-10-15'); assert.equal(paid.payDate, '2024-10-30');
  assert.equal(paid.note, 'คลิป 60 วิ · ลำดับ: 1');
  assert.equal(jobs[0].state, 'ready');
  assert.equal(unpaid.status, 'pending'); assert.equal(unpaid.pending, 7760); assert.equal(unpaid.received, 0);
  assert.deepEqual(jobs[2].issues, ['partialNoAmount']);
  assert.equal(deposit.received, 0);
  assert.deepEqual(result.newJobTypes, ['ถ่ายภาพ', 'ออกแบบ']);
  assert.equal(result.rows.at(-1)!.issues[0], 'total');
  assert.equal(result.fileTotals.value, 25000);
  assert.equal(planTotals(result.rows, r => r.state !== 'skip').value, 25000);
});

test('layout 2: an English sheet with real date cells and TRUE/FALSE checkboxes', () => {
  const sheet = grid('Jobs', [
    ['Date', 'Client', 'Project', 'Amount', 'Paid?', 'Paid on'],
    [date('2024-10-03'), 'Example Studio', 'Product video', 18000, true, date('2024-10-20')],
    [date('2024-10-10'), 'Example Brand', 'Photo set', 9500, false, null],
  ]);
  assert.deepEqual(targets(sheet), { Date: 'date', Client: 'client', Project: 'name', Amount: 'amount', 'Paid?': 'status', 'Paid on': 'paidDate' });
  const [a, b] = plan([sheet]).rows.map(r => r.job!);
  assert.equal(a.status, 'done'); assert.equal(a.received, 18000); assert.equal(a.payDate, '2024-10-20');
  assert.equal(b.status, 'pending'); assert.equal(b.pending, 9500); assert.equal(b.postDate, '2024-10-10');
});

test('layout 3: received and outstanding columns decide partly paid jobs', () => {
  const sheet = grid('Sheet1', [
    ['ชื่องาน', 'ลูกค้า', 'มูลค่ารวม (บาท)', 'ยอดได้รับแล้ว (บาท)', 'ยอดค้างชำระ (บาท)', 'กำหนดชำระเงิน'],
    ['ตัดต่อวิดีโอ', 'ลูกค้า A', 30000, 10000, 20000, '15/11/2024'],
    ['เขียนบทความ', 'ลูกค้า B', 4000, 4000, 0, ''],
  ]);
  const [partial, paid] = plan([sheet]).rows;
  assert.equal(partial.job!.status, 'partial'); assert.equal(partial.job!.received, 10000); assert.equal(partial.job!.pending, 20000);
  assert.equal(partial.job!.payDate, '2024-11-15');
  assert.equal(paid.job!.status, 'done');
  assert.deepEqual(paid.issues, ['paidWithoutDate', 'noDate']);
});

test('layout 4: a sheet with no header row is read from its values', () => {
  const sheet = grid('Sheet1', [
    ['03/10/2024', 'รีวิวสินค้า', 15000],
    ['10/10/2024', 'ถ่ายภาพสินค้า', 6000],
    ['21/10/2024', 'ไลฟ์ขายของ', 4500],
  ]);
  const analysis = analyzeSheet(sheet);
  assert.equal(analysis.headerRow, null);
  assert.deepEqual(analysis.columns.map(c => c.target), ['date', 'name', 'amount']);
  const rows = plan([sheet]).rows;
  assert.equal(rows.length, 3);
  assert.equal(rows[2].job!.value, 4500);
  assert.equal(rows[0].job!.postDate, '2024-10-03');
});

test('layout 5: monthly tabs without dates take the month from the tab name', () => {
  const oct = grid('ต.ค. 67', [['งาน', 'ลูกค้า', 'ค่าจ้าง', 'สถานะ'], ['งาน A', 'ลูกค้า A', 5000, 'โอนแล้ว']]);
  const nov = grid('พ.ย. 67', [['งาน', 'ลูกค้า', 'ค่าจ้าง', 'สถานะ'], ['งาน B', 'ลูกค้า B', 7000, 'รอโอน']]);
  const rows = plan([oct, nov]).rows;
  assert.equal(rows[0].job!.postDate, '2024-10-01');
  assert.ok(rows[0].issues.includes('dateFromSheet'));
  assert.equal(rows[1].job!.postDate, '2024-11-01');
  assert.equal(rows[1].job!.status, 'pending');
});

test('layout 6: a ledger with income and expense columns splits into paid jobs and expenses', () => {
  const sheet = grid('บัญชีรายรับรายจ่าย', [
    ['วันที่', 'รายการ', 'รายรับ', 'รายจ่าย', 'หมายเหตุ'],
    ['01/10/2024', 'ค่าจ้างรีวิว แบรนด์ A', 12000, '', ''],
    ['02/10/2024', 'ค่าแท็กซี่ไปกองถ่าย', '', 250, ''],
    ['05/10/2024', 'ค่า Adobe', '', 790, 'รายเดือน'],
  ]);
  assert.equal(analyzeSheet(sheet).kind, 'mixed');
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].kind, 'job');
  assert.equal(rows[0].job!.status, 'done'); assert.equal(rows[0].job!.received, 12000); assert.equal(rows[0].job!.payDate, '2024-10-01');
  assert.equal(rows[1].expense!.category, 'ค่าเดินทาง/น้ำมัน'); assert.equal(rows[1].expense!.amount, 250); assert.equal(rows[1].expense!.date, '2024-10-02');
  assert.equal(rows[2].expense!.category, 'ค่าอุปกรณ์/ซอฟต์แวร์'); assert.equal(rows[2].expense!.note, 'รายเดือน');
});

test('layout 7: a ledger with a type column (income / expense)', () => {
  const sheet = grid('2024', [
    ['Date', 'Type', 'Description', 'Amount'],
    ['2024-10-01', 'Income', 'Logo design for Example Co.', 8000],
    ['2024-10-03', 'Expense', 'Stock photos', 450],
  ]);
  const analysis = analyzeSheet(sheet);
  assert.equal(analysis.kind, 'mixed');
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].job!.value, 8000);
  assert.equal(rows[1].expense!.amount, 450);
});

test('layout 8: a ledger with signed amounts treats negatives as expenses', () => {
  const sheet = grid('เงินเข้าออก', [
    ['วันที่', 'รายการ', 'จำนวนเงิน', 'ประเภทรายการ'],
    ['01/10/2024', 'ค่าจ้างงาน A', 10000, 'รายรับ'],
    ['03/10/2024', 'ค่าน้ำมัน', -800, 'รายจ่าย'],
  ]);
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].kind, 'job');
  assert.equal(rows[1].kind, 'expense');
  assert.equal(rows[1].expense!.amount, 800);
});

test('layout 9: a sheet named รายจ่าย becomes expenses with mapped categories', () => {
  const sheet = grid('รายจ่าย', [
    ['วันที่', 'รายการ', 'หมวด', 'จำนวน'],
    ['01/10/2567', 'ค่าอินเทอร์เน็ต', 'ค่าเน็ต', 599],
    ['', 'ค่าอาหารประชุมลูกค้า', 'อาหาร', 180],
  ]);
  const analysis = analyzeSheet(sheet);
  assert.equal(analysis.kind, 'expenses');
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].expense!.category, 'ค่าบริการ/สาธารณูปโภค');
  assert.equal(rows[0].expense!.date, '2024-10-01');
  assert.equal(rows[1].expense!.category, 'อาหาร/รับรองลูกค้า');
  assert.deepEqual(rows[1].issues, ['noDate']);
  assert.equal(rows[1].state, 'check');
});

test('layout 10: a withholding amount column gives the rate', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ราคา', 'ภาษีหัก ณ ที่จ่าย', 'วันที่'], ['งาน A', 10000, 300, '01/10/2024']]);
  const job = plan([sheet]).rows[0].job!;
  assert.equal(job.whtRate, 3);
  assert.equal(job.whtAmount, 300);
});

test('layout 11: amounts written after withholding are turned back into the job value', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ยอดเงิน', 'หัก ณ ที่จ่าย', 'วันที่'], ['งาน A', 9700, '3%', '01/10/2024']]);
  const job = plan([sheet], { ...options, amountsAreNet: true }).rows[0].job!;
  assert.equal(job.value, 10000);
  assert.equal(job.whtAmount, 300);
  assert.equal(job.pending, 9700);
});

test('layout 12: jobs already in the account are left out unless the person ticks them', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ลูกค้า', 'ราคา', 'วันที่'], ['งาน A', 'ลูกค้า A', 5000, '01/10/2024'], ['งาน A', 'ลูกค้า A', 5000, '01/10/2024']]);
  const existing = { ...plan([sheet]).rows[0].job!, id: 'x' };
  const rows = plan([sheet], options, { ...context, existingJobs: [existing] }).rows;
  assert.equal(rows[0].state, 'skip');
  assert.deepEqual(rows[0].issues, ['duplicate']);
  const fresh = plan([sheet]).rows;
  assert.equal(fresh[1].state, 'check');
  assert.deepEqual(fresh[1].issues, ['duplicateInFile']);
});

test('layout 13: a column of month-first dates is read month first', () => {
  const sheet = grid('Sheet1', [['Date', 'Project', 'Amount'], ['10/15/2024', 'A', 100], ['11/03/2024', 'B', 200]]);
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].job!.postDate, '2024-10-15');
  assert.equal(rows[1].job!.postDate, '2024-11-03');
});

test('layout 14: credit terms give the due date', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ราคา', 'วันส่งงาน', 'เครดิต'], ['งาน A', 5000, '01/10/2024', '30 วัน'], ['งาน B', 5000, '01/10/2024', 'Net 45']]);
  const [a, b] = plan([sheet]).rows.map(r => r.job!);
  assert.equal(a.creditTerm, 30); assert.equal(a.payDate, '2024-10-31');
  assert.equal(b.creditTerm, 45); assert.equal(b.payDate, '2024-11-15');
});

test('layout 15: a summary with months across the top is recognised and not imported', () => {
  const sheet = grid('สรุป', [['รายการ', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.'], ['รายรับ', 10000, 12000, 9000, 15000, 8000]]);
  assert.equal(analyzeSheet(sheet).monthsAcross, true);
  assert.equal(plan([sheet]).rows.length, 0);
});

test('layout 16: columns that are not ours are kept in the note with their header', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ช่องทาง', 'ราคา', 'วันที่'], ['รีวิว', 'TikTok', 5000, '01/10/2024']]);
  assert.equal(plan([sheet]).rows[0].job!.note, 'ช่องทาง: TikTok');
});

test('layout 17: a job named "รวม…" with a date is a job, not a total', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ราคา', 'วันที่'], ['รวมคลิปไฮไลต์', 7000, '01/10/2024'], ['รวม', 7000, '']]);
  const rows = plan([sheet]).rows;
  assert.equal(rows[0].kind, 'job');
  assert.deepEqual(rows[1].issues, ['total']);
});

test('layout 18: status words mark delivery as well as payment', () => {
  const sheet = grid('Sheet1', [['ชื่องาน', 'ราคา', 'วันที่', 'สถานะ'], ['งาน A', 5000, '01/12/2026', 'กำลังทำ'], ['งาน B', 5000, '01/10/2026', 'ส่งงานแล้ว รอโอน']]);
  const [a, b] = plan([sheet]).rows.map(r => r.job!);
  assert.equal(a.isPosted, false);
  assert.equal(b.isPosted, true); assert.equal(b.status, 'pending');
});

test('layout 19: a real .xlsx with date cells, a title row and Thai text reads the same', () => {
  const sheet = XLSX.utils.aoa_to_sheet([
    ['สรุปงานเดือนตุลาคม'],
    ['วันที่', 'ชื่องาน', 'ลูกค้า', 'ค่าจ้าง', 'จ่ายแล้ว'],
    [new Date(Date.UTC(2024, 9, 15)), 'รีวิวสินค้า', 'แบรนด์ A', 12000, 12000],
    [new Date(Date.UTC(2024, 9, 18)), 'ถ่ายภาพ', 'แบรนด์ B', 8000, 0],
  ], { cellDates: true });
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, 'ต.ค.');
  const file = XLSX.write(book, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer;
  const [read] = readWorkbook(XLSX, file, 'งาน.xlsx');
  assert.equal(read.rows[2][0].date, '2024-10-15');
  const rows = plan([read]).rows;
  assert.equal(rows.length, 2);
  assert.equal(rows[0].job!.postDate, '2024-10-15');
  assert.equal(rows[0].job!.status, 'done');
  assert.equal(rows[1].job!.status, 'pending');
});

test('layout 20: a CSV saved by Thai Excel (Windows-874) is decoded', () => {
  const thai = 'ชื่องาน,ราคา,วันที่\nรีวิว,5000,15/10/2567\n';
  // Encode as TIS-620/Windows-874: Thai letters are U+0E01..U+0E5B -> 0xA1..0xFB.
  const bytes = Uint8Array.from([...thai].map(ch => { const code = ch.charCodeAt(0); return code >= 0x0E01 && code <= 0x0E5B ? code - 0x0E01 + 0xA1 : code; }));
  const [read] = readWorkbook(XLSX, bytes.buffer, 'jobs.csv');
  const rows = plan([read]).rows;
  assert.equal(rows[0].job!.name, 'รีวิว');
  assert.equal(rows[0].job!.postDate, '2024-10-15');
  assert.equal(rows[0].job!.value, 5000);
});

test('imported jobs pass the same checks as jobs saved from the form', async () => {
  const { validateChanges } = await import('../shared/validation.ts');
  const sheet = grid('Sheet1', [['ชื่องาน', 'ลูกค้า', 'ราคา', 'หัก ณ ที่จ่าย', 'วันที่', 'สถานะ'], ['งาน A', 'ลูกค้า A', 12345.67, '3%', '01/10/2024', 'มัดจำ'], ['งาน B', '', 5000, '', '', 'จ่ายแล้ว']]);
  const changes = plan([sheet]).rows.filter(r => r.job).map((r, i) => ({ table: 'cashflow_jobs', id: `j${i}`, op: 'set', version: null, data: { ...r.job, id: `j${i}` } }));
  assert.doesNotThrow(() => validateChanges(changes));
});

test('our template imports without any column matching, in Thai and in English', async () => {
  const { templateRows } = await import('../frontend/src/features/import/importTemplate.ts');
  const { setCurrentLanguage } = await import('../frontend/src/i18n/currentLanguage.ts');
  for (const language of ['th', 'en'] as const) {
    setCurrentLanguage(language);
    const { jobs, expenses } = templateRows();
    const jobSheet = grid(language === 'en' ? 'Jobs' : 'งาน', jobs);
    const expenseSheet = grid(language === 'en' ? 'Expenses' : 'รายจ่าย', expenses);
    assert.ok(analyzeSheet(jobSheet).columns.every(c => c.target !== 'keep'), `${language}: every template column is recognised`);
    assert.equal(analyzeSheet(expenseSheet).kind, 'expenses', language);
    const rows = plan([jobSheet, expenseSheet]).rows;
    const made = rows.filter(r => r.job).map(r => r.job!);
    assert.deepEqual(made.map(j => j.paymentStatus), ['paid', 'partial', 'unpaid'], language);
    assert.equal(made[0].whtAmount, 150, language);
    assert.equal(made[1].received, 3000, language);
    assert.equal(made[2].payDate, '2024-12-01', language);
    assert.equal(rows.filter(r => r.expense).length, 2, language);
  }
  setCurrentLanguage('th');
});
