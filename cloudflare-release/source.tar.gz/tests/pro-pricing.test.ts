import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PRO_CHECKOUT_OPEN, PRO_PRICING, PRO_REGULAR_MONTHLY, formatBaht, proPriceDetails } from '../shared/proPricing.js';
import { PRO_MONTHLY_AMOUNT } from '../backend/src/services/stripeSubscriptions.js';

// The owner's prices of 2026-10-20: ฿159 a month, ฿849 for 6 months, ฿1,490 for a year, each a
// promotion against the regular ฿249 a month.
test('Pro prices, regular prices, averages and savings match the owner', () => {
  assert.equal(PRO_REGULAR_MONTHLY, 249);
  assert.deepEqual(Object.fromEntries(Object.entries(PRO_PRICING).map(([key, value]) => [key, value.total])), { month: 159, halfYear: 849, year: 1490 });
  const month = proPriceDetails('month');
  assert.deepEqual([month.regular, month.saving, month.savingPct, month.bestValue], [249, 90, 36, false]);
  const half = proPriceDetails('halfYear');
  assert.deepEqual([half.regular, half.saving, half.savingPct, half.bestValue], [1494, 645, 43, false]);
  assert.equal(formatBaht(half.average, 2), '฿141.50');
  const year = proPriceDetails('year');
  assert.deepEqual([year.regular, year.saving, year.savingPct, year.bestValue], [2988, 1498, 50, true]);
  assert.equal(formatBaht(year.average, 2), '฿124.17');
  assert.equal(formatBaht(year.total), '฿1,490');
});

test('a period opens for payment only when checkout charges the price shown', () => {
  // The billing API charges PRO_MONTHLY_AMOUNT (satang) for a month; it must equal the page's price first.
  if (PRO_CHECKOUT_OPEN.month) assert.equal(PRO_MONTHLY_AMOUNT, PRO_PRICING.month.total * 100);
  else assert.notEqual(PRO_MONTHLY_AMOUNT, PRO_PRICING.month.total * 100, 'checkout now charges ฿159: open the month in shared/proPricing.ts');
  // There is no 6-month or 1-year checkout in the billing API yet.
  assert.equal(PRO_CHECKOUT_OPEN.halfYear, false);
  assert.equal(PRO_CHECKOUT_OPEN.year, false);
});
