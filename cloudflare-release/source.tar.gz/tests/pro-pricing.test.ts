import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PRO_CHECKOUT_OPEN, PRO_PRICING, formatBaht, proPriceDetails } from '../shared/proPricing.js';
import { PRO_MONTHLY_AMOUNT } from '../backend/src/services/stripeSubscriptions.js';

// The owner's table of 2026-10-20: ฿159 a month, ฿849 for 6 months, ฿1,490 for a year.
test('Pro prices, averages and savings match the owner\'s table', () => {
  assert.deepEqual(Object.fromEntries(Object.entries(PRO_PRICING).map(([key, value]) => [key, value.total])), { month: 159, halfYear: 849, year: 1490 });
  const month = proPriceDetails('month');
  assert.equal(month.saving, 0);
  assert.equal(month.savingPct, 0);
  assert.equal(month.bestValue, false);
  const half = proPriceDetails('halfYear');
  assert.equal(half.regular, 954);
  assert.equal(half.saving, 105);
  assert.equal(half.savingPct, 11);
  assert.equal(formatBaht(half.average, 2), '฿141.50');
  assert.equal(half.bestValue, false);
  const year = proPriceDetails('year');
  assert.equal(year.regular, 1908);
  assert.equal(year.saving, 418);
  assert.equal(year.savingPct, 22);
  assert.equal(formatBaht(year.average, 2), '฿124.17');
  assert.equal(year.bestValue, true);
  assert.equal(formatBaht(year.total), '฿1,490');
});

test('a period opens for payment only when checkout charges the price shown', () => {
  // The billing API charges PRO_MONTHLY_AMOUNT (satang) for a month; it must equal the page's price first.
  if (PRO_CHECKOUT_OPEN.month) assert.equal(PRO_MONTHLY_AMOUNT, PRO_PRICING.month.total * 100);
  else assert.notEqual(PRO_MONTHLY_AMOUNT, PRO_PRICING.month.total * 100, 'checkout now charges ฿159: open the month in shared/proPricing.ts');
  // There is no 6-month or 1-year checkout in the billing API yet.
  assert.equal(PRO_CHECKOUT_OPEN.halfYear, false);
  assert.equal(PRO_CHECKOUT_OPEN.year, false);
});
