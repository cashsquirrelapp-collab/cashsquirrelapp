import { expect, test, type Page } from '@playwright/test';

// Phone checks from the owner's rounds of 2026-10-20:
// - the overview card with large amounts keeps its layout and every figure stays whole, only smaller,
//   from hundreds of thousands to hundreds of millions, on a 390px and a 320px phone;
// - the Pro package page can be reached from the phone menu, as from the desktop sidebar.

test.use({ serviceWorkers: 'block' });

const user = { id: '11111111-1111-4111-8111-111111111111', email: 'large-amounts@example.com', role: 'user', created_at: '2026-01-01T00:00:00Z', user_metadata: {} };
const today = new Date();
const day = (offset: number) => { const d = new Date(today); d.setDate(d.getDate() + offset); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

function snapshot(scale: number) {
  const job = (id: string, name: string, value: number, received: number) => ({
    id, name, client: 'ลูกค้าตัวอย่าง', type: 'Sponsored Post', creditTerm: 0, note: '', value: value * scale, received: received * scale, pending: (value - received) * scale,
    status: received >= value ? 'done' : received ? 'partial' : 'pending', paymentStatus: received >= value ? 'paid' : received ? 'partial' : 'unpaid',
    isPosted: true, postDate: day(0), payDate: day(0),
  });
  return {
    jobs: [job('a', 'รีวิวสินค้า', 18_000, 18_000), job('b', 'ถ่ายภาพแคมเปญ', 12_000, 5_000), job('c', 'ออกแบบโลโก้', 9_500, 0)],
    expenses: [{ id: 'e1', name: 'ค่าอุปกรณ์', category: 'Other', amount: 1_899 * scale, date: day(0) }],
    goals: [], invoices: [],
    settings: { monthlyExpense: 0, monthlyRevenueGoal: 20_000, savingsPercentage: 40, profileSetupCompleted: true, userPersona: 'freelance' },
    statuses: [{ id: 'done', label: 'จ่ายเงินครบแล้ว', behavior: 'done' }, { id: 'partial', label: 'มัดจำแล้ว', behavior: 'partial' }, { id: 'pending', label: 'ยังไม่จ่าย', behavior: 'pending' }],
    job_types: ['Sponsored Post'], notif_settings: { enabled: false, pendingQueue: [] }, avatar_data_url: null, issuer_profile: null,
  };
}

async function open(page: Page, scale: number, subscription: Record<string, unknown> = { status: 'active', plan: 'pro_monthly', current_period_end: '2099-01-01T00:00:00Z' }) {
  await page.addInitScript(() => localStorage.setItem('cashflow_language', 'th'));
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.route('**/*', route => (['127.0.0.1', 'localhost'].includes(new URL(route.request().url()).hostname) ? route.continue() : route.abort()));
  await page.route('**/api/**', route => route.fulfill({ status: 501, json: { error: 'Unmocked test endpoint' } }));
  await page.route('**/api/auth', route => route.fulfill({ json: { session: { user } } }));
  await page.route('**/api/profile', route => route.fulfill({ json: { userId: user.id, publicId: 'SQ-1111111111', displayName: 'ผู้ใช้ตัวอย่าง' } }));
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: 'user', groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/account', route => route.fulfill({ json: { backupEmail: null } }));
  await page.route('**/api/usage-analytics', route => route.fulfill({ json: { ok: true } }));
  await page.route('**/api/data*', route => route.fulfill({ json: route.request().method() === 'POST' ? { ok: true } : {
    snapshot: snapshot(scale),
    versions: { cashflow_jobs: { a: 1, b: 1, c: 1 }, cashflow_expenses: { e1: 1 }, cashflow_goals: {}, cashflow_invoices: {}, cashflow_documents: { settings: 1, statuses: 1, job_types: 1, notif_settings: 1 } },
    subscription,
  } }));
  await page.goto('/dashboard/large-amounts');
  await expect(page.locator('[data-metric="work"]')).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
}

/** Every figure on the card whose text does not fit its box (shown with "…"). */
const cutFigures = (page: Page) => page.locator('.ksm-hero [data-metric]').evaluateAll(nodes =>
  nodes.filter(node => node.scrollWidth > node.clientWidth + 1).map(node => node.textContent));

for (const width of [390, 320]) {
  test(`${width}px phone: same card layout, every digit shown, from hundreds of thousands to hundreds of millions`, async ({ page }) => {
    await page.setViewportSize({ width, height: 844 });
    const sizes: number[] = [];
    for (const scale of [10, 1_000, 10_000]) {
      await open(page, scale);
      // the work value is 39,500 × scale, every digit
      await expect(page.locator('[data-metric="work"]')).toHaveText(`฿${(39_500 * scale).toLocaleString('en-US')}`);
      await expect.poll(() => cutFigures(page)).toEqual([]);
      // the layout never changes: the pill beside the figure, the three figures in one row
      const figure = (await page.locator('.ksm-net').boundingBox())!;
      const pill = (await page.locator('.ksm-trend').boundingBox())!;
      expect(pill.x).toBeGreaterThan(figure.x + figure.width - 1);
      expect(Math.abs((pill.y + pill.height / 2) - (figure.y + figure.height / 2))).toBeLessThan(figure.height / 2);
      const tops = await page.locator('.ksm-hero-metrics > button').evaluateAll(buttons => buttons.map(button => Math.round(button.getBoundingClientRect().top)));
      expect(new Set(tops).size).toBe(1);
      // the three share one size
      const metricSizes = await page.locator('.ksm-hero-metrics b').evaluateAll(nodes => nodes.map(node => getComputedStyle(node).fontSize));
      expect(new Set(metricSizes).size).toBe(1);
      sizes.push(parseFloat(metricSizes[0]));
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
      // the bar it closes into shows the figure whole as well
      await page.evaluate(() => document.getElementById('main-content')!.scrollTo({ top: 400 }));
      await expect.poll(() => cutFigures(page)).toEqual([]);
      await expect.poll(async () => { const box = await page.locator('.ksm-net').boundingBox(); return box ? Math.round(box.x + box.width) : 9999; }).toBeLessThanOrEqual(width);
    }
    // only longer amounts get smaller
    expect(sizes[0]).toBeGreaterThanOrEqual(sizes[1]);
    expect(sizes[1]).toBeGreaterThan(sizes[2]);
  });
}

test('390px phone: the menu\'s LINE AI Pro section leads to the Pro package page', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  // a Free account past its trial
  await open(page, 1, { status: 'inactive', plan: null, current_period_end: null });
  await page.getByRole('navigation', { name: 'เมนูหลัก' }).getByRole('button', { name: 'เมนู', exact: true }).click();
  const menu = page.getByRole('region', { name: 'เครื่องมือทั้งหมด' });
  // sections with several rows open in place
  await menu.getByText('LINE AI Pro', { exact: true }).click();
  const plans = menu.getByRole('button', { name: /แพ็กเกจ Pro/ });
  await expect(plans).toContainText('FREE');
  await expect(plans).toContainText('ดูราคาและอัปเกรดเป็น Pro');
  await expect(menu.getByRole('button', { name: /เชื่อมต่อ LINE/ })).toBeVisible();
  // the package page is no longer listed twice: section 05 has no package row of its own
  const account = menu.getByRole('group').filter({ hasText: 'บัญชีและการตั้งค่า' });
  await expect(account.locator('button', { hasText: 'แพ็กเกจ' })).toHaveCount(0);
  await expect(account.locator('button', { hasText: 'ตั้งค่าทั้งหมด' })).toHaveCount(1);
  await plans.click();
  await expect(page).toHaveURL(/\/plans\//);
  await expect(page.getByRole('heading', { name: 'อัปเกรด', exact: true })).toBeVisible();
});
