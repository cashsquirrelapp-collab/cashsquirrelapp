import { expect, test, type Page, type Request } from '@playwright/test';
import { PRO_CHECKOUT_OPEN } from '../../shared/proPricing';

const user = {
  id: '11111111-1111-4111-8111-111111111111',
  email: 'billing@example.com',
  role: 'user',
  created_at: '2026-01-01T00:00:00Z',
  user_metadata: {},
};

const snapshot = {
  jobs: [],
  expenses: [],
  goals: [],
  invoices: [],
  settings: {
    monthlyExpense: 0,
    monthlyRevenueGoal: 20_000,
    savingsPercentage: 40,
    profileSetupCompleted: true,
    userPersona: 'freelance',
  },
  statuses: [
    { id: 'done', label: 'จ่ายเงินครบแล้ว', behavior: 'done' },
    { id: 'partial', label: 'มัดจำแล้ว', behavior: 'partial' },
    { id: 'pending', label: 'ยังไม่จ่าย', behavior: 'pending' },
  ],
  job_types: ['Sponsored Post'],
  notif_settings: {
    enabled: true,
    alertEmail: user.email,
    serviceType: 'mailto',
    emailjsServiceId: '',
    emailjsTemplateId: '',
    emailjsPublicKey: '',
    pendingQueue: [],
    lineUserId: null,
  },
  avatar_data_url: null,
  issuer_profile: null,
};

const versions = {
  cashflow_jobs: {},
  cashflow_expenses: {},
  cashflow_goals: {},
  cashflow_invoices: {},
  cashflow_documents: {
    settings: 1,
    statuses: 1,
    job_types: 1,
    notif_settings: 1,
  },
};

type SubscriptionFixture = {
  status: string;
  plan: string | null;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
  stripe_status: string | null;
  has_subscription: boolean;
  intro_eligible: boolean;
  managed: boolean;
};

async function openPlans(
  page: Page,
  subscription: SubscriptionFixture,
  stripeUrl: string,
  billingResponse: Record<string, unknown> = {},
  packageEnabled = false,
): Promise<Request[]> {
  const billingRequests: Request[] = [];

  await page.route('**/api/auth', route => route.fulfill({ json: { session: { user } } }));
  await page.route('**/api/profile', route => route.fulfill({
    json: { userId: user.id, publicId: 'SQ-1111111111', displayName: 'Billing test user' },
  }));
  await page.route('**/api/groups?*', route => route.fulfill({
    json: { systemRole: 'user', groups: [], invitations: [], total: 0, page: 0 },
  }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/usage-analytics', route => route.fulfill({ json: { ok: true } }));
  await page.route('**/api/account', route => route.fulfill({ json: { backupEmail: null } }));
  await page.route('**/api/data*', route => route.fulfill({
    json: { snapshot, versions, subscription, package_features: {free_documents: packageEnabled} },
  }));
  await page.route('**/api/billing', async route => {
    billingRequests.push(route.request());
    await route.fulfill({ json: { url: stripeUrl, ...billingResponse } });
  });
  await page.route('https://checkout.stripe.com/**', route => route.fulfill({
    contentType: 'text/html',
    body: '<title>Stripe Checkout test destination</title>',
  }));
  await page.route('https://billing.stripe.com/**', route => route.fulfill({
    contentType: 'text/html',
    body: '<title>Stripe Billing Portal test destination</title>',
  }));

  await page.goto('/plans');
  await expect(page.getByRole('heading', { name: 'อัปเกรด', exact: true })).toBeVisible();
  // A fresh non-Pro account may get the daily Pro promo after data loads; close it when it comes.
  const promoClose = page.getByRole('button', { name: 'ปิด', exact: true });
  if (await promoClose.waitFor({ state: 'visible', timeout: 2_500 }).then(() => true, () => false)) {
    await promoClose.click();
    await expect(promoClose).toHaveCount(0);
  }
  return billingRequests;
}

test('a free account chooses Stripe Checkout for the monthly price', async ({ page }) => {
  // Checkout still charges the earlier offer (฿199 / ฿249), so the page keeps it closed for now.
  test.fixme(!PRO_CHECKOUT_OPEN.month, 'monthly checkout opens once Stripe and the billing API charge ฿159 (shared/proPricing.ts)');
  const stripeUrl = 'https://checkout.stripe.com/c/pay/cs_test_intro';
  const requests = await openPlans(page, {
    status: 'free',
    plan: null,
    current_period_end: null,
    cancel_at_period_end: false,
    stripe_status: null,
    has_subscription: false,
    intro_eligible: true,
    managed: false,
  }, stripeUrl);

  const plans = page.locator('#main-content');
  await plans.getByRole('button', { name: 'สมัคร Pro รายเดือน ฿159', exact: true }).click();

  await expect.poll(() => requests.length).toBe(1);
  expect(requests[0].method()).toBe('POST');
  expect(requests[0].headers()['x-csrf-protection']).toBe('1');
  expect(requests[0].postDataJSON()).toEqual({ action: 'checkout' });
  await expect(page).toHaveURL(stripeUrl);
});

test('the Pro card and its prices stay readable on mobile', async ({ page }) => {
  await page.setViewportSize({ width: 375, height: 812 });
  await openPlans(page, {
    status: 'free',
    plan: null,
    current_period_end: null,
    cancel_at_period_end: false,
    stripe_status: null,
    has_subscription: false,
    intro_eligible: true,
    managed: false,
  }, 'https://checkout.stripe.com/c/pay/cs_test_mobile');

  const plans = page.locator('#main-content');
  await expect(plans.getByRole('heading', { name: 'Pro', exact: true })).toBeVisible();
  await expect(plans.getByText('เลขาการเงินส่วนตัวของคุณ', { exact: true })).toBeVisible();
  const monthly = page.getByTestId('pro-price').getByText('฿159', { exact: true });
  await expect(monthly).toBeVisible();
  const monthLine = Math.round((await monthly.boundingBox())!.y);
  // phone sizes: the squirrel about 144px, the price 52-64px
  const mascot = (await page.getByRole('button', { name: 'ทักทายน้องกระรอก Pro' }).locator('svg').first().boundingBox())!;
  expect(mascot.width).toBeGreaterThanOrEqual(135);
  expect(mascot.width).toBeLessThanOrEqual(150);
  const size = await monthly.evaluate(el => parseFloat(getComputedStyle(el).fontSize));
  expect(size).toBeGreaterThanOrEqual(52);
  expect(size).toBeLessThanOrEqual(64);
  await page.getByRole('radio', { name: '1 ปี' }).click();
  const yearly = page.getByTestId('pro-price').getByText('฿1,490', { exact: true });
  await expect(yearly).toBeVisible();
  // "คุ้มที่สุด" is in the card's top-right corner, so the price line does not move between periods
  await expect.poll(async () => Math.round((await yearly.boundingBox())!.y)).toBe(monthLine);
  const card = (await page.getByTestId('pro-card').boundingBox())!;
  const badge = (await page.getByTestId('pro-card').getByText('คุ้มที่สุด', { exact: true }).boundingBox())!;
  expect(card.x + card.width - (badge.x + badge.width)).toBeLessThan(40);
  expect(badge.y - card.y).toBeLessThan(40);
  await expect(page.getByTestId('pro-price').getByText('ประหยัด ฿1,498 (50%)')).toBeVisible();
  await expect(plans.getByRole('heading', { name: 'บัตรเครดิต / เดบิต', exact: true })).toBeVisible();
  await expect(plans.getByRole('heading', { name: 'พร้อมเพย์ QR', exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)).toBe(true);
});

test('PromptPay opens a server-expiring QR flow with countdown and manual-renewal guidance', async ({ page }) => {
  test.fixme(!PRO_CHECKOUT_OPEN.month, 'PromptPay opens once the billing API charges ฿159 (shared/proPricing.ts)');
  const stripeUrl = 'https://checkout.stripe.com/c/pay/cs_test_promptpay';
  const requests = await openPlans(page, {
    status: 'free',
    plan: null,
    current_period_end: null,
    cancel_at_period_end: false,
    stripe_status: null,
    has_subscription: false,
    intro_eligible: true,
    managed: false,
  }, stripeUrl, {
    destination: 'promptpay',
    expiresAt: new Date(Date.now() + 30 * 60_000).toISOString(),
    amount: 15_900,
  });

  const plans = page.locator('#main-content');
  await plans.getByRole('button', { name: 'จ่ายด้วย QR ฿159', exact: true }).click();
  // Status GETs may already have polled by the time the click resolves on a busy host.
  const checkoutRequests = () => requests.filter(request => request.method() === 'POST');
  await expect.poll(() => checkoutRequests().length).toBe(1);
  expect(checkoutRequests()[0].postDataJSON()).toEqual({ action: 'promptpay_checkout' });
  const dialog = page.getByRole('dialog', { name: 'ชำระด้วย QR พร้อมเพย์' });
  await expect(dialog).toBeVisible();
  await expect(dialog.getByText('QR พร้อมเพย์ ฿159', { exact: true })).toBeVisible();
  await expect(dialog.getByText(/ไม่ตัดเงินอัตโนมัติ/)).toBeVisible();
  await expect(dialog.getByText(/บันทึกภาพ QR/)).toBeVisible();
  await expect(dialog.getByRole('link', { name: /เปิด QR ใน Stripe/ })).toHaveAttribute('href', stripeUrl);
  await expect(page).toHaveURL(/\/plans/);
});

test('a managed nonterminal subscription chooses the Stripe Billing Portal', async ({ page }) => {
  const stripeUrl = 'https://billing.stripe.com/p/session/cs_test_managed';
  const requests = await openPlans(page, {
    status: 'past_due',
    plan: 'pro_monthly',
    current_period_end: null,
    cancel_at_period_end: false,
    stripe_status: 'past_due',
    has_subscription: true,
    intro_eligible: false,
    managed: true,
  }, stripeUrl);

  await page.locator('#main-content').getByRole('button', { name: 'จัดการการสมัครสมาชิก', exact: true }).click();

  await expect.poll(() => requests.length).toBe(1);
  expect(requests[0].method()).toBe('POST');
  expect(requests[0].headers()['x-csrf-protection']).toBe('1');
  expect(requests[0].postDataJSON()).toEqual({ action: 'portal' });
  await expect(page).toHaveURL(stripeUrl);
});

test('the official mascot on the Pro card returns from tap to idle and is petted, respecting reduced motion',async({page})=>{
  await openPlans(page,{status:'free',plan:null,current_period_end:null,cancel_at_period_end:false,stripe_status:null,has_subscription:false,intro_eligible:true,managed:false},'https://checkout.stripe.com/c/pay/mock');
  await expect(page.getByRole('radio',{name:'รายเดือน'})).toHaveAttribute('aria-checked','true'); // monthly by default
  const mascot=page.getByRole('button',{name:'ทักทายน้องกระรอก Pro'});
  await expect(mascot.locator('[data-motion]')).toHaveAttribute('data-motion','idle');
  await mascot.click();
  await expect(mascot.locator('[data-motion]')).toHaveAttribute('data-motion','tap');
  await expect(mascot.locator('[data-motion]')).toHaveAttribute('data-motion','idle',{timeout:3000});
  const palette=await mascot.locator('[data-motion] svg').evaluate(svg=>Array.from(svg.querySelectorAll('[fill]')).map(node=>node.getAttribute('fill')));
  expect(palette).toContain('#C27A3F');
  // rubbing it (the cursor moving across) is petting: it leans in, then settles when left alone
  const box=(await mascot.boundingBox())!;
  for(let i=0;i<=6;i++)await page.mouse.move(box.x+box.width*(0.3+i*0.07),box.y+box.height*0.45);
  await expect(mascot).toHaveAttribute('data-reaction','pet');
  // the hearts stay small next to the squirrel
  const heart=mascot.locator('span[aria-hidden] svg').first();
  await expect(heart).toBeAttached();
  expect(Number(await heart.getAttribute('width'))).toBeLessThanOrEqual(10);
  expect((await heart.boundingBox())!.width).toBeLessThanOrEqual(12);
  // the squirrel's own box is the size it is drawn at, so it stays centred
  const figureBox=(await mascot.locator('[data-motion] > div').first().boundingBox())!;
  const drawn=(await mascot.locator('svg').first().boundingBox())!;
  expect(Math.abs(figureBox.width-drawn.width)).toBeLessThan(2);
  await page.mouse.move(box.x-120,box.y-120);
  await expect(mascot).toHaveAttribute('data-reaction','idle');
  const pettedPalette=await mascot.locator('[data-motion] svg').evaluate(svg=>Array.from(svg.querySelectorAll('[fill]')).map(node=>node.getAttribute('fill')));
  expect(pettedPalette).toContain('#C27A3F'); // the same character and colours
  await page.emulateMedia({reducedMotion:'reduce'}); await page.reload();
  await expect(page.getByRole('button',{name:'ทักทายน้องกระรอก Pro'}).locator('[data-motion]')).toHaveAttribute('data-motion','reduced');
});

test('plans page: Pro only at the owner\'s prices; squirrel and price lead; nothing can be paid at another amount',async({page})=>{
  const requests=await openPlans(page,{status:'free',plan:null,current_period_end:null,cancel_at_period_end:false,stripe_status:null,has_subscription:false,intro_eligible:true,managed:false},'https://checkout.stripe.com/c/pay/mock');
  const card=page.getByTestId('pro-card');
  const price=page.getByTestId('pro-price');
  // the Free card and the Free-versus-Pro lines are gone from this page
  await expect(page.getByTestId('free-card')).toHaveCount(0);
  await expect(page.getByText('฿0',{exact:true})).toHaveCount(0);
  await expect(page.getByText('ทุกอย่างใน Free',{exact:true})).toHaveCount(0);
  await expect(page.getByRole('heading',{name:'Free',exact:true})).toHaveCount(0);
  // no earlier offer anywhere on the page; ฿249 appears only as the struck regular price
  await expect(page.locator('#main-content').getByText(/฿(199|149)\b/)).toHaveCount(0);
  // a Free account with nothing running has no status line
  await expect(page.getByTestId('plan-status')).toHaveCount(0);
  // on a computer the whole card fits on the first screen (owner, 2026-10-20): the squirrel and the
  // price lead the left side, the benefits sit beside them
  await page.setViewportSize({ width: 1280, height: 720 });
  const cardBox=(await card.boundingBox())!;
  expect(cardBox.y+cardBox.height).toBeLessThanOrEqual(720);
  const hero=(await card.locator('.plan-hero').boundingBox())!;
  const benefitsBox=(await card.getByRole('list',{name:'ทุกรอบชำระได้ Pro ครบเท่ากัน'}).boundingBox())!;
  expect(benefitsBox.x).toBeGreaterThan(hero.x+hero.width-1);
  const mascot=(await card.getByRole('button',{name:'ทักทายน้องกระรอก Pro'}).locator('svg').first().boundingBox())!;
  expect(mascot.width).toBeGreaterThanOrEqual(80);
  expect(mascot.width).toBeLessThanOrEqual(100);
  expect(Math.abs(mascot.x+mascot.width/2-(hero.x+hero.width/2))).toBeLessThan(4);
  const figure=price.getByText('฿159',{exact:true});
  const figureSize=await figure.evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  expect(figureSize).toBeGreaterThanOrEqual(52);
  expect(figureSize).toBeLessThanOrEqual(64);
  expect(await figure.evaluate(el=>Number(getComputedStyle(el).fontWeight))).toBeGreaterThanOrEqual(700);
  const perSize=await price.getByText('/ เดือน',{exact:true}).evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  expect(perSize).toBeLessThan(figureSize/3);
  const priceRow=(await price.locator('p').first().boundingBox())!;
  expect(Math.abs(priceRow.x+priceRow.width/2-(hero.x+hero.width/2))).toBeLessThan(4);
  const ctaBox=(await page.getByTestId('pro-actions').boundingBox())!;
  expect(ctaBox.y+ctaBox.height).toBeLessThanOrEqual(720);
  const closed=async()=>{
    await expect(card.getByRole('button',{name:'เปิดรับชำระเร็ว ๆ นี้',exact:true})).toBeDisabled();
    await expect(page.getByTestId('pro-actions').getByTestId('checkout-not-open')).toBeVisible();
    await expect(card.getByRole('button',{name:/สมัคร Pro|จ่ายด้วย QR/})).toHaveCount(0);
  };
  // monthly: the regular ฿249 struck, ฿159 as the promotion
  await expect(card).toHaveAttribute('data-period','month');
  await expect(price.locator('s')).toContainText('฿249');
  await expect(price.getByText('ราคาโปรโมชัน',{exact:true})).toBeVisible();
  await expect(price.getByText('ประหยัด ฿90 ทุกเดือน (36%)')).toBeVisible();
  await expect(price.getByText(/คุ้มที่สุด|เฉลี่ย/)).toHaveCount(0);
  await closed();
  // 6 months: the total leads beside the struck regular price, then the average and the saving
  await page.getByRole('radio',{name:'6 เดือน'}).click();
  await expect(card).toHaveAttribute('data-period','halfYear');
  await expect(price.getByText('฿849',{exact:true})).toBeVisible();
  await expect(price.getByText('/ 6 เดือน',{exact:true})).toBeVisible();
  await expect(price.getByText('เฉลี่ย ฿141.50/เดือน',{exact:true})).toBeVisible();
  await expect(price.locator('s',{hasText:'฿1,494'})).toBeVisible();
  await expect(price.getByText('ประหยัด ฿645 (43%)')).toBeVisible();
  await expect(price.getByText('คุ้มที่สุด',{exact:true})).toHaveCount(0);
  const total=await price.getByText('฿849',{exact:true}).evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  const average=await price.getByText('เฉลี่ย ฿141.50/เดือน',{exact:true}).evaluate(el=>parseFloat(getComputedStyle(el).fontSize));
  expect(total).toBeGreaterThan(average*3);
  await closed();
  // 1 year, reached with the arrow key as in any radio group; the one place that says best value
  await page.getByRole('radio',{name:'6 เดือน'}).press('ArrowRight');
  await expect(page.getByRole('radio',{name:'1 ปี'})).toHaveAttribute('aria-checked','true');
  await expect(card).toHaveAttribute('data-period','year');
  await expect(price.getByText('฿1,490',{exact:true})).toBeVisible();
  await expect(price.getByText('/ ปี',{exact:true})).toBeVisible();
  await expect(price.getByText('เฉลี่ย ฿124.17/เดือน',{exact:true})).toBeVisible();
  await expect(price.locator('s',{hasText:'฿2,988'})).toBeVisible();
  await expect(price.getByText('ประหยัด ฿1,498 (50%)')).toBeVisible();
  await expect(page.locator('#main-content').getByText('คุ้มที่สุด',{exact:true})).toHaveCount(1);
  await closed();
  const yearCard=(await card.boundingBox())!;
  expect(yearCard.y+yearCard.height).toBeLessThanOrEqual(720);
  // back to monthly: the other periods' figures fade out and are gone
  await page.getByRole('radio',{name:'รายเดือน'}).click();
  await expect(price.getByText('฿159',{exact:true})).toBeVisible();
  await expect(price.getByText(/เฉลี่ย|คุ้มที่สุด|฿849|฿1,490/)).toHaveCount(0);
  // nothing was sent to checkout
  expect(requests.filter(request=>request.method()==='POST')).toEqual([]);
  // the same four Pro groups whichever period; the AI chat is marked as not live
  const features=card.getByRole('list',{name:'ทุกรอบชำระได้ Pro ครบเท่ากัน'}).getByRole('listitem');
  await expect(features).toHaveCount(4);
  await expect(features.nth(0)).toContainText('LINE AI เลขาการเงินส่วนตัว');
  await expect(features.nth(0)).toContainText('เร็ว ๆ นี้');
  await expect(features.nth(1)).toContainText('แจ้งเตือนอัตโนมัติ');
  await expect(features.nth(2)).toContainText('ออกเอกสารไม่จำกัด');
  await expect(features.nth(2)).not.toContainText('เร็ว ๆ นี้');
  await expect(features.nth(3)).toContainText('สรุปการเงินผ่าน LINE');
});

test('plans page: every account sees the same monthly price, with or without the earlier intro offer',async({page})=>{
  await openPlans(page,{status:'free',plan:null,current_period_end:null,cancel_at_period_end:false,stripe_status:null,has_subscription:false,intro_eligible:false,managed:false},'https://checkout.stripe.com/c/pay/mock');
  const price=page.getByTestId('pro-price');
  await expect(price.getByText('฿159',{exact:true})).toBeVisible();
  await expect(price.locator('s')).toContainText('฿249');
  await expect(page.getByRole('radio')).toHaveCount(3);
});

test('plans page: an active Pro member sees the status in the card and manages the subscription',async({page})=>{
  const stripeUrl='https://billing.stripe.com/p/session/cs_test_active';
  const requests=await openPlans(page,{status:'active',plan:'pro_monthly',current_period_end:'2099-01-01T00:00:00Z',cancel_at_period_end:false,stripe_status:'active',has_subscription:true,intro_eligible:false,managed:true},stripeUrl);
  const status=page.getByTestId('pro-card').getByTestId('plan-status');
  await expect(status).toContainText('Pro');
  await expect(status).toContainText('ต่ออายุอัตโนมัติ');
  await expect(page.getByTestId('pro-card').getByRole('button',{name:/จ่ายด้วย QR/})).toHaveCount(0);
  await page.getByTestId('pro-card').getByRole('button',{name:'จัดการการสมัครสมาชิก',exact:true}).click();
  await expect.poll(()=>requests.filter(request=>request.method()==='POST').length).toBe(1);
  expect(requests.find(request=>request.method()==='POST')!.postDataJSON()).toEqual({action:'portal'});
  await expect(page).toHaveURL(stripeUrl);
});

test('checkout success keeps polling and keeps its marker until a delayed webhook becomes active', async ({ page }) => {
  test.setTimeout(20_000);
  const free: SubscriptionFixture = {
    status: 'free', plan: null, current_period_end: null, cancel_at_period_end: false,
    stripe_status: null, has_subscription: false, intro_eligible: true, managed: true,
  };
  const active: SubscriptionFixture = {
    status: 'active', plan: 'pro_monthly', current_period_end: '2099-01-01T00:00:00Z', cancel_at_period_end: false,
    stripe_status: 'active', has_subscription: true, intro_eligible: false, managed: true,
  };
  let billingReads = 0;
  let releaseActive!: () => void;
  const activeGate = new Promise<void>(resolve => { releaseActive = resolve; });

  await page.route('**/api/auth', route => route.fulfill({ json: { session: { user } } }));
  await page.route('**/api/profile', route => route.fulfill({ json: { userId: user.id, publicId: 'SQ-1111111111', displayName: 'Billing test user' } }));
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: 'user', groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/usage-analytics', route => route.fulfill({ json: { ok: true } }));
  await page.route('**/api/data*', route => route.fulfill({ json: { snapshot, versions, subscription: free } }));
  await page.route('**/api/billing', async route => {
    billingReads += 1;
    if (billingReads >= 8) await activeGate;
    await route.fulfill({ json: { subscription: billingReads >= 8 ? active : free } });
  });

  await page.goto('/app?checkout=success&session_id=cs_test_delayed&keep=1');
  await expect.poll(() => billingReads, { timeout: 10_000 }).toBeGreaterThanOrEqual(6);
  expect(new URL(page.url()).searchParams.get('checkout')).toBe('success');
  expect(await page.evaluate(() => sessionStorage.getItem('cashflow_checkout_pending_owner'))).toBe(user.id);

  releaseActive();
  await expect.poll(() => billingReads, { timeout: 10_000 }).toBeGreaterThanOrEqual(8);
  await expect(page.getByRole('heading', { name: 'สมัครสมาชิกสำเร็จ!' })).toBeVisible();
  await expect.poll(() => new URL(page.url()).searchParams.get('checkout')).toBeNull();
  expect(new URL(page.url()).searchParams.get('keep')).toBe('1');
  expect(new URL(page.url()).searchParams.get('session_id')).toBeNull();
  expect(await page.evaluate(() => sessionStorage.getItem('cashflow_checkout_pending_owner'))).toBeNull();
});

test('a direct account switch clears plan state and rejects the old checkout poll response', async ({ page }) => {
  const accountA = { ...user, email: 'account-a@example.com' };
  const accountB = { ...user, id: '22222222-2222-4222-8222-222222222222', email: 'account-b@example.com' };
  const active: SubscriptionFixture = {
    status: 'active', plan: 'pro_monthly', current_period_end: '2099-01-01T00:00:00Z', cancel_at_period_end: false,
    stripe_status: 'active', has_subscription: true, intro_eligible: false, managed: true,
  };
  const free: SubscriptionFixture = {
    status: 'free', plan: null, current_period_end: null, cancel_at_period_end: false,
    stripe_status: null, has_subscription: false, intro_eligible: true, managed: false,
  };
  let currentUser = accountA;
  let releaseOldBilling!: () => void;
  let releaseAccountB!: () => void;
  const oldBillingGate = new Promise<void>(resolve => { releaseOldBilling = resolve; });
  const accountBGate = new Promise<void>(resolve => { releaseAccountB = resolve; });
  const billingAccounts: string[] = [];

  await page.route('**/api/auth', route => route.fulfill({ json: { session: { user: currentUser } } }));
  await page.route('**/api/profile', route => {
    const accountId = route.request().headers()['x-account-id'];
    return route.fulfill({ json: { userId: accountId, publicId: accountId === accountB.id ? 'SQ-B' : 'SQ-A', displayName: accountId === accountB.id ? 'Account B' : 'Account A' } });
  });
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: 'user', groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/usage-analytics', route => route.fulfill({ json: { ok: true } }));
  await page.route('**/api/data*', async route => {
    const accountId = route.request().headers()['x-account-id'];
    if (accountId === accountB.id) await accountBGate;
    await route.fulfill({ json: { snapshot, versions, subscription: accountId === accountB.id ? free : active } });
  });
  await page.route('**/api/billing', async route => {
    billingAccounts.push(route.request().headers()['x-account-id']);
    await oldBillingGate;
    try { await route.fulfill({ json: { subscription: active } }); } catch { /* The fixed client aborts this A request. */ }
  });

  await page.goto('/plans?checkout=success&session_id=cs_test_account_a');
  await expect(page.getByText('Account A', { exact: true }).first()).toBeVisible();
  await expect.poll(() => billingAccounts.length).toBe(1);

  currentUser = accountB;
  await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  await expect(page.getByText('Account B', { exact: true }).first()).toBeVisible();
  await page.getByRole('button', { name: 'เปิดเมนูโปรไฟล์' }).click();
  await expect(page.getByText('FREE', { exact: true })).toBeVisible();

  releaseOldBilling();
  await page.waitForTimeout(250);
  await expect(page.getByText('FREE', { exact: true })).toBeVisible();
  expect(billingAccounts).toEqual([accountA.id]);

  releaseAccountB();
  await expect(page.getByText('FREE', { exact: true })).toBeVisible();
});
