import { expect, test, type Page, type TestInfo } from '@playwright/test';
import type { FeedbackAction, FeedbackMessage, FeedbackThread } from '../../shared/feedback';

test.use({ serviceWorkers: 'block' });

const ownerId = '11111111-1111-4111-8111-111111111111';
const adminId = '22222222-2222-4222-8222-222222222222';
const threadId = '33333333-3333-4333-8333-333333333333';
const closedId = '44444444-4444-4444-8444-444444444444';
const quoteId = '55555555-5555-4555-8555-555555555555';
const createdAt = '2026-10-18T08:00:00Z';

function makeThread(id: string, preview: string, status: FeedbackThread['status'] = 'open'): FeedbackThread {
  return { id, ownerId, ownerName: 'Feedback user', ownerPublicId: 'SQ-1111111111', category: 'bug', status, preview, createdAt, updatedAt: createdAt, lastMessageAt: createdAt, lastSenderRole: 'user', messageCount: 1 };
}

async function setup(page: Page, options: { admin?: boolean; guest?: boolean; seeded?: boolean; pauseCreate?: Promise<void> } = {}) {
  const accountId = options.admin ? adminId : ownerId;
  const user = { id: accountId, email: options.admin ? 'feedback-admin@example.test' : 'feedback-user@example.test', role: options.admin ? 'admin' : 'user', canViewAdminAnalytics: !!options.admin, created_at: '2026-01-01T00:00:00Z', user_metadata: {} };
  const threads: FeedbackThread[] = options.seeded ? [makeThread(threadId, 'ปัญหาหน้าจอเล็ก'), makeThread(closedId, 'เรื่องที่ปิดแล้ว', 'resolved')] : [];
  const messages = new Map<string, FeedbackMessage[]>(threads.map(thread => [thread.id, [{ id: `${thread.id}-first`, threadId: thread.id, senderId: ownerId, senderRole: 'user', body: thread.preview, createdAt }]]));
  const mutations: FeedbackAction[] = [];
  const requestHeaders: Array<Record<string, string>> = [];
  const reads: URL[] = [];
  const unhandledApi: string[] = [];
  let failNextReply = false;
  const snapshot = {
    jobs: [], expenses: [], goals: [],
    invoices: [{ id: quoteId, documentType: 'quotation', documentNo: 'QT-HIDDEN-KEEP', date: '2026-10-18', client: { name: 'Hidden quote customer' }, items: [], vatRate: 0, whtRate: 0 }],
    settings: { monthlyExpense: 0, monthlyRevenueGoal: 20_000, savingsPercentage: 40, profileSetupCompleted: true, userPersona: 'freelance' },
    statuses: [], job_types: [], notif_settings: { enabled: false, pendingQueue: [] }, avatar_data_url: null, issuer_profile: null,
  };
  await page.addInitScript(({ guest }) => {
    localStorage.setItem('cashflow_language', 'th');
    if (guest) localStorage.setItem('cashflow_guest_session', JSON.stringify({ user: { id: 'guest-feedback-test', email: 'guest@example.test' }, isGuest: true }));
  }, { guest: !!options.guest });
  await page.emulateMedia({ reducedMotion: 'reduce' });
  // Never use live accounts, services, fonts, or third-party network requests.
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    return ['127.0.0.1', 'localhost'].includes(url.hostname) ? route.continue() : route.abort();
  });
  await page.route('**/api/**', route => {
    unhandledApi.push(new URL(route.request().url()).pathname);
    return route.fulfill({ status: 501, json: { error: 'Unmocked test endpoint' } });
  });
  await page.route('**/api/auth', route => route.fulfill({ json: { session: options.guest ? null : { user } } }));
  await page.route('**/api/profile', route => route.fulfill({ json: { userId: accountId, publicId: options.admin ? 'SQ-2222222222' : 'SQ-1111111111', displayName: options.admin ? 'Feedback admin' : 'Feedback user' } }));
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: user.role, groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/data*', route => route.fulfill({ json: route.request().method() === 'POST' ? { ok: true } : { snapshot, versions: { cashflow_jobs: {}, cashflow_expenses: {}, cashflow_goals: {}, cashflow_invoices: { [quoteId]: 1 }, cashflow_documents: { settings: 1 } }, subscription: { status: 'active', plan: 'admin_grant', current_period_end: null } } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/account', route => route.fulfill({ json: { backupEmail: null } }));
  await page.route('**/api/usage-analytics', route => route.fulfill({ json: { ok: true } }));
  await page.route('**/api/admin-analytics?*', route => route.fulfill({ status: 503, json: { error: 'Analytics is temporarily unavailable' } }));
  await page.route('**/api/feedback*', async route => {
    requestHeaders.push(route.request().headers());
    const url = new URL(route.request().url());
    if (route.request().method() === 'GET') {
      reads.push(url);
      const id = url.searchParams.get('threadId');
      const pageNumber = Number(url.searchParams.get('page') || 0);
      if (id) {
        const thread = threads.find(item => item.id === id);
        if (!thread) return route.fulfill({ status: 404, json: { error: 'ไม่พบข้อความนี้' } });
        const allMessages = messages.get(id) || [];
        return route.fulfill({ json: { thread, messages: allMessages.slice(pageNumber * 50, (pageNumber + 1) * 50), hasMore: (pageNumber + 1) * 50 < allMessages.length, page: pageNumber, pageSize: 50 } });
      }
      const status = url.searchParams.get('status');
      const matching = threads.filter(thread => (!status || thread.status === status) && (url.searchParams.get('scope') === 'admin' || thread.ownerId === accountId));
      return route.fulfill({ json: { threads: matching.slice(pageNumber * 20, (pageNumber + 1) * 20), hasMore: (pageNumber + 1) * 20 < matching.length, page: pageNumber, pageSize: 20 } });
    }
    const action = route.request().postDataJSON() as FeedbackAction;
    mutations.push(action);
    if (action.action === 'create') {
      await options.pauseCreate;
      const thread = { ...makeThread(threadId, action.body), category: action.category || null };
      threads.unshift(thread);
      messages.set(thread.id, [{ id: `${thread.id}-first`, threadId: thread.id, senderId: accountId, senderRole: 'user', body: action.body, createdAt }]);
      return route.fulfill({ json: { threadId: thread.id } });
    }
    const thread = threads.find(item => item.id === action.threadId)!;
    if (action.action === 'status') thread.status = action.status;
    else {
      if (failNextReply) { failNextReply = false; return route.fulfill({ status: 503, json: { error: 'Temporary test outage' } }); }
      const senderRole = options.admin ? 'admin' : 'user';
      const history = messages.get(thread.id)!;
      history.push({ id: `${thread.id}-${history.length + 1}`, threadId: thread.id, senderId: accountId, senderRole, body: action.body, createdAt });
      thread.messageCount = history.length;
      thread.lastSenderRole = senderRole;
      thread.status = options.admin ? 'in_progress' : thread.status === 'resolved' ? 'open' : thread.status;
    }
    return route.fulfill({ json: { threadId: thread.id } });
  });
  return { threads, messages, mutations, reads, requestHeaders, unhandledApi, failNextReply: () => { failNextReply = true; } };
}

async function screenshot(page: Page, testInfo: TestInfo, name: string) {
  await page.evaluate(() => document.fonts.ready);
  const path = testInfo.outputPath(name);
  await page.screenshot({ path, fullPage: true, animations: 'disabled' });
  await testInfo.attach(name, { path, contentType: 'image/png' });
}

test('normal account creates once, reads team replies, preserves a failed reply and retries safely', async ({ page }, testInfo) => {
  let releaseCreate!: () => void;
  const pauseCreate = new Promise<void>(resolve => { releaseCreate = resolve; });
  const mock = await setup(page, { pauseCreate });
  await page.goto('/feedback/feedback-user');
  await expect(page.getByRole('heading', { name: 'ข้อเสนอแนะ', exact: true })).toBeVisible();
  await expect(page.getByText('ยังไม่มีข้อความที่ส่ง', { exact: true })).toBeVisible();
  const body = 'อยากเพิ่มตัวกรอง <img src=x onerror=alert(1)>';
  await page.getByLabel('ประเภท (ไม่จำเป็น)').selectOption('idea');
  const editor = page.getByLabel('ข้อความ', { exact: true });
  await expect(editor).toHaveAttribute('maxlength', '4000');
  await editor.fill(body);
  await editor.evaluate(element => { (element as HTMLTextAreaElement).form!.requestSubmit(); (element as HTMLTextAreaElement).form!.requestSubmit(); });
  await expect(page.getByRole('button', { name: 'กำลังส่ง…', exact: true })).toBeDisabled();
  await expect.poll(() => mock.mutations.length).toBe(1);
  releaseCreate();
  await expect(page.getByRole('status').filter({ hasText: 'ส่งข้อความแล้ว' })).toBeVisible();
  expect(mock.mutations[0]).toEqual({ action: 'create', body, category: 'idea' });
  await expect(editor).toHaveValue('');

  const thread = mock.threads[0];
  mock.messages.get(threadId)!.push({ id: 'team-reply', threadId, senderId: adminId, senderRole: 'admin', body: 'ขอบคุณสำหรับไอเดีย ทีมงานรับเรื่องแล้ว', createdAt });
  Object.assign(thread, { messageCount: 2, status: 'in_progress', lastSenderRole: 'admin' });
  await page.getByRole('button', { name: 'อัปเดต', exact: true }).click();
  await expect(page.getByText('ทีมงานตอบแล้ว', { exact: true })).toBeVisible();
  await screenshot(page, testInfo, 'feedback-desktop.png');
  await page.getByRole('button', { name: `เปิดบทสนทนา: ${body}`, exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByText('ขอบคุณสำหรับไอเดีย ทีมงานรับเรื่องแล้ว', { exact: true })).toBeVisible();
  await expect(dialog.getByText(body, { exact: true })).toBeVisible();
  await expect(dialog.locator('img[src="x"]')).toHaveCount(0);
  await expect(dialog.getByLabel('สถานะเรื่องนี้')).toHaveCount(0);
  mock.failNextReply();
  await dialog.getByLabel('ตอบกลับ', { exact: true }).fill('ขอเพิ่มรายละเอียดอีกนิด');
  await dialog.getByRole('button', { name: 'ส่งข้อความ', exact: true }).click();
  await expect(dialog.getByRole('alert')).toBeVisible();
  await expect(dialog.getByLabel('ตอบกลับ', { exact: true })).toHaveValue('ขอเพิ่มรายละเอียดอีกนิด');
  await dialog.getByRole('button', { name: 'ส่งข้อความ', exact: true }).click();
  await expect(dialog.getByRole('status').filter({ hasText: 'ส่งข้อความตอบกลับแล้ว' })).toBeVisible();
  await expect(dialog.getByText('ขอเพิ่มรายละเอียดอีกนิด', { exact: true })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog).toHaveCount(0);
  expect(mock.requestHeaders.every(headers => headers['x-account-id'] === ownerId && headers['x-csrf-protection'] === '1')).toBe(true);
  expect(mock.unhandledApi).toEqual([]);
});

test('390px admin inbox filters, replies and resolves while analytics is unavailable', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const mock = await setup(page, { admin: true, seeded: true });
  await page.goto('/adminDashboard/feedback-admin');
  await expect(page.getByRole('alert').filter({ hasText: 'Analytics is temporarily unavailable' })).toBeVisible();
  await page.getByRole('button', { name: 'ข้อความจากผู้ใช้', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'กล่องข้อความจากผู้ใช้' })).toBeVisible();
  await expect(page.getByText('Analytics is temporarily unavailable')).toHaveCount(0);
  await page.getByLabel('กรองตามสถานะ').selectOption('open');
  await expect(page.getByRole('button', { name: 'เปิดบทสนทนา: ปัญหาหน้าจอเล็ก', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'เปิดบทสนทนา: เรื่องที่ปิดแล้ว', exact: true })).toHaveCount(0);
  await expect(page.getByText('รอทีมงานตอบ', { exact: true })).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await screenshot(page, testInfo, 'feedback-admin-mobile.png');
  await page.getByRole('button', { name: 'เปิดบทสนทนา: ปัญหาหน้าจอเล็ก', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toContainText('Feedback user');
  await dialog.getByLabel('ตอบกลับ', { exact: true }).fill('ทีมงานกำลังตรวจสอบให้นะคะ');
  await dialog.getByRole('button', { name: 'ส่งข้อความ', exact: true }).click();
  await expect(dialog.getByLabel('สถานะเรื่องนี้')).toHaveValue('in_progress');
  await dialog.getByLabel('สถานะเรื่องนี้').selectOption('resolved');
  await dialog.getByRole('button', { name: 'บันทึกสถานะ', exact: true }).click();
  await expect(dialog.getByRole('status').filter({ hasText: 'บันทึกสถานะแล้ว' })).toBeVisible();
  await expect(dialog.getByLabel('สถานะเรื่องนี้')).toHaveValue('resolved');
  await screenshot(page, testInfo, 'feedback-conversation-mobile.png');
  await dialog.getByRole('button', { name: 'ปิด', exact: true }).click();
  await page.getByLabel('กรองตามสถานะ').selectOption('resolved');
  await expect(page.getByRole('button', { name: 'เปิดบทสนทนา: ปัญหาหน้าจอเล็ก', exact: true })).toBeVisible();
  expect(mock.reads.some(url => url.searchParams.get('scope') === 'admin' && url.searchParams.get('status') === 'open')).toBe(true);
  expect(mock.mutations).toContainEqual({ action: 'status', threadId, status: 'resolved' });
  expect(mock.unhandledApi).toEqual([]);
});

test('phase one hides advanced navigation and quotation deep links for normal accounts', async ({ page }) => {
  const mock = await setup(page);
  await page.goto('/feedback/feedback-user');
  const sidebar = page.locator('aside').first();
  await expect(sidebar.getByRole('button', { name: 'แจ้งปัญหาและเสนอแนะ', exact: true })).toBeVisible();
  for (const name of ['ภาษี', 'รายงาน', 'วิเคราะห์รายได้', 'คลังเอกสาร', 'ทีม']) await expect(sidebar.getByRole('button', { name, exact: true })).toHaveCount(0);
  await page.goto('/tax/feedback-user');
  await expect(page).toHaveURL(/\/dashboard\/feedback-user$/);
  await expect(page.getByRole('heading', { name: 'ภาษี', exact: true })).toHaveCount(0);
  await page.goto(`/invoice/feedback-user?type=quotation&document=${quoteId}`);
  await expect(page.getByRole('heading', { name: 'ไม่พบเอกสารนี้ในบัญชีที่เข้าสู่ระบบ', exact: true })).toBeVisible();
  await expect(page.getByText('QT-HIDDEN-KEEP', { exact: true })).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'ดาวน์โหลด PDF', exact: true })).toHaveCount(0);
  await expect(page.getByRole('tablist', { name: 'ประเภทเอกสาร' })).toHaveCount(0);
  await page.getByRole('button', { name: 'ดูเอกสารในบัญชีนี้', exact: true }).click();
  const tabs = page.getByRole('tablist', { name: 'ประเภทเอกสาร' });
  await expect(tabs.getByRole('tab')).toHaveCount(3);
  await expect(tabs.getByRole('tab', { name: /^ใบแจ้งหนี้/ })).toBeVisible();
  await expect(tabs.getByRole('tab', { name: /^ใบเสร็จ/ })).toBeVisible();
  await expect(tabs.getByRole('tab', { name: /^ใบกำกับภาษี/ })).toBeVisible();
  await expect(tabs.getByRole('tab', { name: /^ใบเสนอราคา/ })).toHaveCount(0);
  await expect(page.getByText('จัดการใบแจ้งหนี้ ใบเสร็จ และใบกำกับภาษี', { exact: true })).toBeVisible();
  await expect(page.getByText('จัดการใบเสนอราคา ใบแจ้งหนี้ ใบเสร็จ และใบกำกับภาษี', { exact: true })).toHaveCount(0);
  await expect(page.getByText('QT-HIDDEN-KEEP', { exact: true })).toHaveCount(0);
  expect(mock.unhandledApi).toEqual([]);
});

test('guest feedback asks for an account and never calls the feedback API', async ({ page }) => {
  const mock = await setup(page, { guest: true });
  await page.goto('/feedback/demo');
  await expect(page.getByRole('heading', { name: 'เข้าสู่ระบบเพื่อคุยกับทีมงาน' })).toBeVisible();
  await expect(page.getByLabel('ข้อความ', { exact: true })).toHaveCount(0);
  await page.getByRole('button', { name: 'เข้าสู่ระบบ / สมัครสมาชิก', exact: true }).click();
  await expect(page).toHaveURL(/\/login$/);
  expect(await page.evaluate(() => localStorage.getItem('cashflow_guest_session'))).toBeNull();
  expect(mock.reads).toEqual([]);
  expect(mock.mutations).toEqual([]);
});
