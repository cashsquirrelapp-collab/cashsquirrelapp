import { expect, test, type Page } from '@playwright/test';
import { textOverlapIssues } from './textOverlap';

// เลขากระรอก switched on (/api/assistant says enabled): the same chat screen talks to the backend, shows the
// account's real answers without sample labels, saves a confirmation card only on ยืนยัน and reloads the data.
// The backend is mocked here; no AI is called.

test.use({ serviceWorkers: 'block' });

const user = { id: '11111111-1111-4111-8111-111111111111', email: 'assistant@example.com', role: 'admin', created_at: '2026-01-01T00:00:00Z', user_metadata: {} };
const snapshot = { jobs: [], expenses: [], goals: [], invoices: [], settings: { monthlyExpense: 0, monthlyRevenueGoal: 20000, savingsPercentage: 40, profileSetupCompleted: true, userPersona: 'freelance' }, statuses: [], job_types: [], notif_settings: { enabled: false, pendingQueue: [] }, avatar_data_url: null, issuer_profile: null };
const versions = { cashflow_jobs: {}, cashflow_expenses: {}, cashflow_goals: {}, cashflow_invoices: {}, cashflow_documents: { settings: 1 } };
const PROPOSAL = 'p_0b9d3c1e-4f5a-4b6c-8d7e-9f0a1b2c3d4e';

type Mock = { status?: Record<string, unknown>; reply?: (body: any) => { status: number; json: unknown }; width?: number; height?: number };
async function open(page: Page, mock: Mock = {}) {
  const posts: any[] = [];
  let dataReads = 0;
  await page.addInitScript(() => {
    localStorage.setItem('cashflow_language', 'th'); localStorage.setItem('cashflow_dark_mode', 'false');
    localStorage.setItem('cashflow_theme_auto_period', String(Math.floor((Date.now() + 7 * 3600e3 - 6 * 3600e3) / (12 * 3600e3))));
  });
  await page.route('**/*', route => (['127.0.0.1', 'localhost'].includes(new URL(route.request().url()).hostname) ? route.continue() : route.abort()));
  await page.route('**/api/**', route => route.fulfill({ json: {} }));
  await page.route('**/api/auth*', route => route.fulfill({ json: { session: { user } } }));
  await page.route('**/api/profile', route => route.fulfill({ json: { userId: user.id, publicId: 'SQ-1111111111', displayName: 'ผู้ใช้ตัวอย่าง' } }));
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: 'admin', groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/data*', route => {
    if (route.request().method() === 'GET') dataReads += 1;
    return route.fulfill({ json: route.request().method() === 'POST' ? { ok: true, versions } : { snapshot, versions, subscription: { status: 'active', plan: 'pro_monthly', current_period_end: '2099-01-01T00:00:00Z' } } });
  });
  await page.route('**/api/assistant', route => {
    const request = route.request();
    if (request.method() === 'GET') {
      return route.fulfill({ json: { enabled: true, plan: 'pro', tokensLeft: 994, trialLeft: null, resetsAt: '2026-11-15T17:00:00.000Z', tokenLimit: 1000, requestLimit: null, ...mock.status } });
    }
    const body = request.postDataJSON();
    posts.push({ body, headers: request.headers() });
    if (mock.reply) { const reply = mock.reply(body); return route.fulfill({ status: reply.status, json: reply.json }); }
    if (body.action === 'message') {
      return route.fulfill({ json: {
        text: 'เตรียมเพิ่มงาน **แปลเอกสาร** ไว้แล้วครับ กดยืนยันบนการ์ดเพื่อบันทึก', route: 'action', tokens: 4, tokensLeft: 990, trialLeft: null,
        cards: [{ kind: 'confirm', id: PROPOSAL, title: 'เพิ่มงานใหม่ 1 งาน', changes: [{ label: 'งาน', value: 'แปลเอกสาร' }, { label: 'มูลค่า', value: '฿4,000' }] }],
      } });
    }
    if (body.action === 'confirm') return route.fulfill({ json: { status: 'applied', kind: 'add_job', jobId: 'job-new' } });
    return route.fulfill({ json: { cancelled: true } });
  });
  await page.setViewportSize({ width: mock.width ?? 1440, height: mock.height ?? 900 });
  await page.goto('/assistant');
  await expect(page.locator('#asx-message')).toBeVisible();
  return { posts, dataReads: () => dataReads };
}

const ask = async (page: Page, text: string) => {
  await page.locator('#asx-message').fill(text);
  await page.locator('.asx-send').click();
};

test('live: real answer and card without sample labels, real token count, saved only on ยืนยัน, data reloads', async ({ page }) => {
  const mock = await open(page);
  // The live screen says what it is: no "sample" wording in the hint or the token indicator.
  await expect(page.locator('.asx-hint')).toHaveText('เลขากระรอกตอบผิดได้ ตรวจสอบก่อนกดยืนยันทุกครั้ง');
  await expect(page.locator('.asx-token')).toContainText('994');
  await expect(page.locator('.asx-token')).toHaveAttribute('aria-label', 'Krarok Tokens คงเหลือ 994 จาก 1000');

  await ask(page, 'เพิ่มงานแปลเอกสาร 4000');
  const card = page.locator('.asx-rcard.is-confirm');
  await expect(card).toContainText('เพิ่มงานใหม่ 1 งาน');
  await expect(card).toContainText('฿4,000');
  await expect(card.locator('.asx-card-tag')).toHaveCount(0);
  await expect(page.locator('.asx-meta', { hasText: 'คำตอบตัวอย่าง' })).toHaveCount(0);
  await expect(page.locator('.asx-token')).toContainText('990');

  const message = mock.posts.find(post => post.body.action === 'message');
  expect(message.body).toEqual({ action: 'message', text: 'เพิ่มงานแปลเอกสาร 4000', history: [] });
  expect(message.headers['x-account-id']).toBe(user.id);
  expect(message.headers['x-csrf-protection']).toBe('1');
  expect(mock.posts.some(post => post.body.action === 'confirm')).toBe(false);

  const readsBefore = mock.dataReads();
  await card.getByRole('button', { name: 'ยืนยัน' }).click();
  await expect(card).toContainText('บันทึกแล้ว');
  expect(mock.posts.filter(post => post.body.action === 'confirm').map(post => post.body)).toEqual([{ action: 'confirm', proposalId: PROPOSAL }]);
  await expect.poll(() => mock.dataReads()).toBeGreaterThan(readsBefore);
  await page.screenshot({ path: test.info().outputPath('live-confirmed.png') });
});

test('live: ยกเลิก tells the server, and a follow-up sends the earlier turns as history', async ({ page }) => {
  const mock = await open(page);
  await ask(page, 'เพิ่มงานแปลเอกสาร 4000');
  const card = page.locator('.asx-rcard.is-confirm');
  await card.getByRole('button', { name: 'ยกเลิก' }).click();
  await expect(card).toContainText('ยกเลิกรายการนี้แล้ว');
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'cancel').length).toBe(1);
  await ask(page, 'ขอบคุณ');
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'message').length).toBe(2);
  const second = mock.posts.filter(post => post.body.action === 'message')[1].body;
  expect(second.history.map((turn: any) => turn.role)).toEqual(['user', 'assistant']);
  expect(second.history[0].text).toBe('เพิ่มงานแปลเอกสาร 4000');
});

test('live: tokens used up shows the server message and stops the composer', async ({ page }) => {
  await open(page, { reply: () => ({ status: 402, json: { error: 'โทเคนของรอบนี้หมดแล้ว จะได้รับใหม่วันที่ 15 พ.ย. 2569', code: 'ai_tokens_used' } }) });
  await ask(page, 'สวัสดี');
  await expect(page.getByText('โทเคนของรอบนี้หมดแล้ว จะได้รับใหม่วันที่ 15 พ.ย. 2569')).toBeVisible();
  await expect(page.locator('.asx-token')).toContainText('0');
  await expect(page.locator('#asx-message')).toBeDisabled();
});

test('live: a connection failure keeps the retry state', async ({ page }) => {
  await open(page, { reply: () => ({ status: 503, json: { error: 'เลขากระรอกตอบไม่ทันในตอนนี้ กรุณาลองใหม่อีกครั้ง', code: 'ai_provider' } }) });
  await ask(page, 'สวัสดี');
  await expect(page.locator('.asx-error')).toContainText('ลองอีกครั้ง');
});

test('switched off: the chat keeps its labelled sample answers', async ({ page }) => {
  await open(page, { status: { enabled: false } });
  await expect(page.locator('.asx-hint')).toHaveText('ตัวอย่างหน้าจอ · คำตอบเป็นข้อมูลตัวอย่าง ยังไม่ได้เชื่อมต่อ AI');
});

// A real 2×2 PNG (made with valid checksums), so the browser can decode and redraw it.
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAEElEQVR4nGN4Fq8NRAwQCgArOgXBUA7+6wAAAABJRU5ErkJggg==', 'base64');

test('attach: a picture is redrawn as JPEG, shown in a chip, sent with the message, and the chip can be removed', async ({ page }) => {
  const mock = await open(page);
  const input = page.locator('.asx-composer input[type=file]');
  await input.setInputFiles({ name: 'สลิปโอน.png', mimeType: 'image/png', buffer: PNG });
  const chip = page.locator('.asx-file-chip:not(.is-sent)');
  await expect(chip).toContainText('สลิปโอน.jpg');
  await chip.getByRole('button', { name: 'เอาไฟล์ออก' }).click();
  await expect(chip).toHaveCount(0);

  await input.setInputFiles({ name: 'สลิปโอน.png', mimeType: 'image/png', buffer: PNG });
  await expect(chip).toBeVisible();
  // A file alone can be sent: เลขา gets a plain request to look at it.
  await page.locator('.asx-send').click();
  await expect(page.locator('.asx-file-chip.is-sent')).toContainText('สลิปโอน.jpg');
  await expect(chip).toHaveCount(0);
  const body = mock.posts.find(post => post.body.action === 'message').body;
  expect(body.text).toBe('ช่วยดูไฟล์นี้หน่อย');
  expect(body.attachment.name).toBe('สลิปโอน.jpg');
  expect(body.attachment.mimeType).toBe('image/jpeg');
  expect(body.attachment.data.startsWith('/9j/')).toBe(true);
});

test('attach: a PDF goes as it is; other files are refused on screen before anything is sent', async ({ page }) => {
  const mock = await open(page);
  const input = page.locator('.asx-composer input[type=file]');
  await input.setInputFiles({ name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('hello') });
  await expect(page.locator('.asx-notice')).toContainText('แนบได้เฉพาะรูป (JPG, PNG, WEBP) หรือไฟล์ PDF');
  const pdf = Buffer.from('%PDF-1.4\n% ใบเสนอราคา ตัวอย่าง\n');
  await input.setInputFiles({ name: 'ใบเสนอราคา.pdf', mimeType: 'application/pdf', buffer: pdf });
  await expect(page.locator('.asx-notice')).toHaveCount(0);
  await page.locator('#asx-message').fill('ช่วยเพิ่มงานจากใบนี้');
  await page.locator('.asx-send').click();
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'message').length).toBe(1);
  const body = mock.posts.find(post => post.body.action === 'message').body;
  expect([body.text, body.attachment.name, body.attachment.mimeType, body.attachment.data]).toEqual(['ช่วยเพิ่มงานจากใบนี้', 'ใบเสนอราคา.pdf', 'application/pdf', pdf.toString('base64')]);
});

test('mic: speech becomes text in the message box; an answer can be read aloud without Markdown marks', async ({ page }) => {
  await page.addInitScript(() => {
    // Stand-ins for the browser's speech tools (the test browser has no microphone or voices).
    class FakeRecognition {
      lang = ''; continuous = false; interimResults = false;
      onresult: any = null; onerror: any = null; onend: any = null;
      start() {
        (window as any).__heardLang = this.lang;
        setTimeout(() => { this.onresult?.({ resultIndex: 0, results: [Object.assign([{ transcript: 'เดือนนี้ได้เงิน' }], { isFinal: false })] }); }, 50);
        setTimeout(() => { this.onresult?.({ resultIndex: 0, results: [Object.assign([{ transcript: 'เดือนนี้ได้เงินเท่าไหร่' }], { isFinal: true })] }); this.onend?.(); }, 150);
      }
      stop() { this.onend?.(); }
      abort() {}
    }
    (window as any).SpeechRecognition = FakeRecognition;
    (window as any).webkitSpeechRecognition = FakeRecognition;
    (window as any).__spoken = [];
    window.speechSynthesis.speak = (utterance: SpeechSynthesisUtterance) => { (window as any).__spoken.push({ text: utterance.text, lang: utterance.lang }); };
  });
  await open(page);
  await page.getByRole('button', { name: 'พูดแทนการพิมพ์' }).click();
  await expect(page.locator('#asx-message')).toHaveValue('เดือนนี้ได้เงินเท่าไหร่');
  expect(await page.evaluate(() => (window as any).__heardLang)).toBe('th-TH');
  await expect(page.getByRole('button', { name: 'พูดแทนการพิมพ์' })).toHaveAttribute('aria-pressed', 'false');

  await page.locator('.asx-send').click();
  await page.getByRole('button', { name: 'ฟังคำตอบ' }).last().click();
  const spoken = await page.evaluate(() => (window as any).__spoken);
  expect(spoken).toEqual([{ text: 'เตรียมเพิ่มงาน แปลเอกสาร ไว้แล้วครับ กดยืนยันบนการ์ดเพื่อบันทึก', lang: 'th-TH' }]);
});

test('switched off: attaching stays "coming soon" (sample answers cannot read files)', async ({ page }) => {
  await open(page, { status: { enabled: false } });
  await expect(page.getByRole('button', { name: 'แนบไฟล์ · เร็ว ๆ นี้' })).toHaveAttribute('aria-disabled', 'true');
  await expect(page.locator('.asx-composer input[type=file]')).toHaveCount(0);
});

for (const [label, width, height] of [['computer', 1440, 900], ['phone', 390, 844]] as const) {
  test(`${label}: the file chip, the sent file and the listen button fit without overlapping text`, async ({ page }) => {
    await open(page, { width, height });
    await page.locator('.asx-composer input[type=file]').setInputFiles({ name: 'สลิปโอนเงินค่าออกแบบโลโก้เดือนตุลาคม.png', mimeType: 'image/png', buffer: PNG });
    await expect(page.locator('.asx-file-chip:not(.is-sent)')).toBeVisible();
    await page.screenshot({ path: test.info().outputPath(`${label}-chip.png`) });
    await page.locator('#asx-message').fill('ช่วยดูสลิปนี้ว่าตรงกับงานไหน');
    await page.locator('.asx-send').click();
    await expect(page.locator('.asx-rcard.is-confirm')).toBeVisible();
    await expect(page.getByRole('button', { name: 'ฟังคำตอบ' }).last()).toBeVisible();
    await page.waitForTimeout(400);
    await page.screenshot({ path: test.info().outputPath(`${label}-sent.png`) });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    expect(await textOverlapIssues(page)).toEqual([]);
  });
}
