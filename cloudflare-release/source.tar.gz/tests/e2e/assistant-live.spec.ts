import { expect, test, type Page } from '@playwright/test';
import { textOverlapIssues } from './textOverlap';

// เลขากระรอก switched on (/api/assistant says enabled): the same chat screen talks to the backend, shows the
// account's real answers without sample labels, saves a confirmation card only on ยืนยัน and reloads the data.
// The backend is mocked here; no AI is called.

test.use({ serviceWorkers: 'block' });

const user = { id: '11111111-1111-4111-8111-111111111111', email: 'assistant@example.com', role: 'admin', created_at: '2026-01-01T00:00:00Z', user_metadata: {} };
const snapshot = { jobs: [], expenses: [], goals: [], invoices: [], settings: { monthlyExpense: 0, monthlyRevenueGoal: 20000, savingsPercentage: 40, profileSetupCompleted: true, userPersona: 'freelance' }, statuses: [], job_types: [], notif_settings: { enabled: false, pendingQueue: [] }, avatar_data_url: null, issuer_profile: null };
const versions = { cashflow_jobs: {}, cashflow_expenses: {}, cashflow_goals: {}, cashflow_invoices: {}, cashflow_documents: { settings: 1 } };
const PROPOSAL = 'p_0b9d3c1e-4f5a-4b6c-8d7e-9f0a1b2c3d4e';

type Mock = {
  status?: Record<string, unknown>;
  reply?: (body: any) => { status: number; json: unknown };
  transcribe?: () => Promise<{ text: string; tokens: number; tokensLeft: number; trialLeft: null }>;
  width?: number;
  height?: number;
  inbox?: unknown;
};
async function open(page: Page, mock: Mock = {}) {
  const posts: any[] = [];
  let dataReads = 0;
  await page.addInitScript(() => {
    localStorage.setItem('cashflow_language', 'th'); localStorage.setItem('cashflow_dark_mode', 'false');
    localStorage.setItem('cashflow_theme_auto_period', String(Math.floor((Date.now() + 7 * 3600e3 - 6 * 3600e3) / (12 * 3600e3))));
  });
  await page.route('**/*', route => (['127.0.0.1', 'localhost'].includes(new URL(route.request().url()).hostname) ? route.continue() : route.abort()));
  await page.route('**/api/**', route => route.fulfill({ json: {} }));
  await page.route('**/api/auth*', route => route.fulfill({ json: { session: { user } } }));
  await page.route('**/api/profile', route => route.fulfill({ json: { userId: user.id, publicId: 'SQ-1111111111', displayName: 'ผู้ใช้ตัวอย่าง' } }));
  await page.route('**/api/groups?*', route => route.fulfill({ json: { systemRole: 'admin', groups: [], invitations: [], total: 0, page: 0 } }));
  await page.route('**/api/vault', route => route.fulfill({ json: { files: [] } }));
  await page.route('**/api/data*', route => {
    if (route.request().method() === 'GET') dataReads += 1;
    return route.fulfill({ json: route.request().method() === 'POST' ? { ok: true, versions } : { snapshot, versions, subscription: { status: 'active', plan: 'pro_monthly', current_period_end: '2099-01-01T00:00:00Z' } } });
  });
  if (mock.inbox) await page.route('**/api/assistant?view=line', route => route.fulfill({ json: mock.inbox }));
  await page.route('**/api/assistant', async route => {
    const request = route.request();
    if (request.method() === 'GET') {
      return route.fulfill({ json: { enabled: true, plan: 'pro', tokensLeft: 994, trialLeft: null, resetsAt: '2026-11-15T17:00:00.000Z', tokenLimit: 1000, requestLimit: null, ...mock.status } });
    }
    const body = request.postDataJSON();
    posts.push({ body, headers: request.headers() });
    if (body.action === 'transcribe') {
      return route.fulfill({ json: mock.transcribe ? await mock.transcribe() : {
        text: 'เดือนนี้ได้เงินเท่าไหร่', tokens: 1, tokensLeft: 993, trialLeft: null,
      } });
    }
    if (mock.reply) { const reply = mock.reply(body); return route.fulfill({ status: reply.status, json: reply.json }); }
    if (body.action === 'message') {
      return route.fulfill({ json: {
        text: 'เตรียมเพิ่มงาน **แปลเอกสาร** ไว้แล้วครับ กดยืนยันบนการ์ดเพื่อบันทึก', route: 'action', tokens: 4, tokensLeft: 990, trialLeft: null,
        cards: [{ kind: 'confirm', id: PROPOSAL, title: 'เพิ่มงานใหม่ 1 งาน', changes: [{ label: 'งาน', value: 'แปลเอกสาร' }, { label: 'มูลค่า', value: '฿4,000' }] }],
      } });
    }
    if (body.action === 'confirm') return route.fulfill({ json: { status: 'applied', kind: 'add_job', jobId: 'job-new' } });
    if (body.action === 'line-due') return route.fulfill({ json: { card: { category: 'received', title: 'บันทึกรับเงินแล้ว', subtitle: 'จากปุ่มในแจ้งเตือน', metric: { label: 'ออกแบบโลโก้จริง', value: '฿ 12,000' }, blocks: [{ kind: 'rows', rows: [{ label: 'ยังค้างรับ', value: 'ไม่มี รับครบแล้ว', tone: 'positive', strong: true }] }], footer: { label: 'ดูงานในแอป', path: '/jobs' }, alt: 'บันทึกรับเงินแล้ว ฿ 12,000 · ออกแบบโลโก้จริง' } } });
    if (body.action === 'line-partial') return route.fulfill({ json: { text: `บันทึกยอดจาก ${body.text}` } });
    return route.fulfill({ json: { cancelled: true } });
  });
  await page.setViewportSize({ width: mock.width ?? 1440, height: mock.height ?? 900 });
  const response = await page.goto('/assistant');
  // The page itself must allow the microphone, or the browser refuses the mic button (fakes below cannot catch that).
  expect(response?.headers()['permissions-policy']).toContain('microphone=(self)');
  await expect(page.locator('#asx-message')).toBeVisible();
  return { posts, dataReads: () => dataReads };
}

const ask = async (page: Page, text: string) => {
  await page.locator('#asx-message').fill(text);
  await page.locator('.asx-send').click();
};

async function syntheticMicrophone(page: Page) {
  await page.addInitScript(() => {
    const state = window as unknown as { __microphoneStreams: MediaStream[]; __microphoneRequests: MediaStreamConstraints[] };
    state.__microphoneStreams = [];
    state.__microphoneRequests = [];
    // Only replace capture: MediaRecorder, the analyser and audio decoding remain the browser's real implementations.
    // The oscillator goes to a stream destination, never to the computer's speakers or a physical microphone.
    Object.defineProperty(navigator.mediaDevices, 'getUserMedia', { configurable: true, value: async (constraints: MediaStreamConstraints) => {
      state.__microphoneRequests.push(constraints);
      const context = new AudioContext();
      await context.resume();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const destination = context.createMediaStreamDestination();
      oscillator.frequency.value = 440;
      gain.gain.value = 0.2;
      oscillator.connect(gain);
      gain.connect(destination);
      oscillator.start();
      state.__microphoneStreams.push(destination.stream);
      const track = destination.stream.getAudioTracks()[0];
      const stop = track.stop.bind(track);
      track.stop = () => {
        stop();
        oscillator.stop();
        oscillator.disconnect();
        gain.disconnect();
        void context.close();
      };
      return destination.stream;
    } });
  });
}

const microphoneStopped = (page: Page) => page.evaluate(() => {
  const streams = (window as unknown as { __microphoneStreams: MediaStream[] }).__microphoneStreams;
  return streams.length === 1 && streams.every(stream => stream.getTracks().every(track => track.readyState === 'ended'));
});

test('live: real answer and card without sample labels, real token count, saved only on ยืนยัน, data reloads', async ({ page }) => {
  const mock = await open(page);
  // The live screen says what it is: no "sample" wording in the hint or the token indicator.
  await expect(page.locator('.asx-hint')).toHaveText('เลขากระรอกตอบผิดได้ ตรวจสอบก่อนกดยืนยันทุกครั้ง');
  await expect(page.locator('.asx-hint.is-admin')).toHaveCount(0);
  await expect(page.locator('.asx-token')).toContainText('994');
  await expect(page.locator('.asx-token')).toHaveAttribute('aria-label', 'Krarok Tokens คงเหลือ 994 จาก 1000');

  await ask(page, 'เพิ่มงานแปลเอกสาร 4000');
  const card = page.locator('.asx-rcard.is-confirm');
  await expect(card).toContainText('เพิ่มงานใหม่ 1 งาน');
  await expect(card).toContainText('฿4,000');
  await expect(card.locator('.asx-card-tag')).toHaveCount(0);
  await expect(page.locator('.asx-meta', { hasText: 'คำตอบตัวอย่าง' })).toHaveCount(0);
  await expect(page.locator('.asx-token')).toContainText('990');

  const message = mock.posts.find(post => post.body.action === 'message');
  expect(message.body).toEqual({ action: 'message', text: 'เพิ่มงานแปลเอกสาร 4000', history: [] });
  expect(message.headers['x-account-id']).toBe(user.id);
  expect(message.headers['x-csrf-protection']).toBe('1');
  expect(mock.posts.some(post => post.body.action === 'confirm')).toBe(false);

  const readsBefore = mock.dataReads();
  await card.getByRole('button', { name: 'ยืนยัน' }).click();
  await expect(card).toContainText('บันทึกแล้ว');
  expect(mock.posts.filter(post => post.body.action === 'confirm').map(post => post.body)).toEqual([{ action: 'confirm', proposalId: PROPOSAL }]);
  await expect.poll(() => mock.dataReads()).toBeGreaterThan(readsBefore);
  await page.screenshot({ path: test.info().outputPath('live-confirmed.png') });
});

test('live: ยกเลิก tells the server, and a follow-up sends the earlier turns as history', async ({ page }) => {
  const mock = await open(page);
  await ask(page, 'เพิ่มงานแปลเอกสาร 4000');
  const card = page.locator('.asx-rcard.is-confirm');
  await card.getByRole('button', { name: 'ยกเลิก' }).click();
  await expect(card).toContainText('ยกเลิกรายการนี้แล้ว');
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'cancel').length).toBe(1);
  await ask(page, 'ขอบคุณ');
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'message').length).toBe(2);
  const second = mock.posts.filter(post => post.body.action === 'message')[1].body;
  expect(second.history.map((turn: any) => turn.role)).toEqual(['user', 'assistant']);
  expect(second.history[0].text).toBe('เพิ่มงานแปลเอกสาร 4000');
});

test('live: tokens used up shows the server message and stops the composer', async ({ page }) => {
  await open(page, { reply: () => ({ status: 402, json: { error: 'โทเคนของรอบนี้หมดแล้ว จะได้รับใหม่วันที่ 15 พ.ย. 2569', code: 'ai_tokens_used' } }) });
  await ask(page, 'สวัสดี');
  await expect(page.getByText('โทเคนของรอบนี้หมดแล้ว จะได้รับใหม่วันที่ 15 พ.ย. 2569')).toBeVisible();
  await expect(page.locator('.asx-token')).toContainText('0');
  await expect(page.locator('#asx-message')).toBeDisabled();
});

test('live: a connection failure keeps the retry state', async ({ page }) => {
  await open(page, { reply: () => ({ status: 503, json: { error: 'เลขากระรอกตอบไม่ทันในตอนนี้ กรุณาลองใหม่อีกครั้ง', code: 'ai_provider' } }) });
  await ask(page, 'สวัสดี');
  await expect(page.locator('.asx-error')).toContainText('ลองอีกครั้ง');
});

test('switched off: the chat keeps its labelled sample answers', async ({ page }) => {
  await open(page, { status: { enabled: false } });
  await expect(page.locator('.asx-hint:not(.is-admin)')).toHaveText('ตัวอย่างหน้าจอ · คำตอบเป็นข้อมูลตัวอย่าง ยังไม่ได้เชื่อมต่อ AI');
  // This test account is a system admin, so it also sees why: AI is on for admins only (the mock says pro).
  await expect(page.locator('.asx-hint.is-admin')).toContainText('ตอนนี้เปิด AI ให้แอดมินระบบเท่านั้น');
});

// A real 2×2 PNG (made with valid checksums), so the browser can decode and redraw it.
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAEElEQVR4nGN4Fq8NRAwQCgArOgXBUA7+6wAAAABJRU5ErkJggg==', 'base64');

test('attach: a picture is redrawn as JPEG, shown in a chip, sent with the message, and the chip can be removed', async ({ page }) => {
  const mock = await open(page);
  const input = page.locator('.asx-composer input[type=file]');
  await input.setInputFiles({ name: 'สลิปโอน.png', mimeType: 'image/png', buffer: PNG });
  const chip = page.locator('.asx-file-chip:not(.is-sent)');
  await expect(chip).toContainText('สลิปโอน.jpg');
  await chip.getByRole('button', { name: 'เอาไฟล์ออก' }).click();
  await expect(chip).toHaveCount(0);

  await input.setInputFiles({ name: 'สลิปโอน.png', mimeType: 'image/png', buffer: PNG });
  await expect(chip).toBeVisible();
  // A file alone can be sent: เลขา gets a plain request to look at it.
  await page.locator('.asx-send').click();
  await expect(page.locator('.asx-file-chip.is-sent')).toContainText('สลิปโอน.jpg');
  await expect(chip).toHaveCount(0);
  const body = mock.posts.find(post => post.body.action === 'message').body;
  expect(body.text).toBe('ช่วยดูไฟล์นี้หน่อย');
  expect(body.attachment.name).toBe('สลิปโอน.jpg');
  expect(body.attachment.mimeType).toBe('image/jpeg');
  expect(body.attachment.data.startsWith('/9j/')).toBe(true);
});

test('attach: a PDF goes as it is; other files are refused on screen before anything is sent', async ({ page }) => {
  const mock = await open(page);
  const input = page.locator('.asx-composer input[type=file]');
  await input.setInputFiles({ name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('hello') });
  await expect(page.locator('.asx-notice')).toContainText('แนบได้เฉพาะรูป (JPG, PNG, WEBP) หรือไฟล์ PDF');
  const pdf = Buffer.from('%PDF-1.4\n% ใบเสนอราคา ตัวอย่าง\n');
  await input.setInputFiles({ name: 'ใบเสนอราคา.pdf', mimeType: 'application/pdf', buffer: pdf });
  await expect(page.locator('.asx-notice')).toHaveCount(0);
  await page.locator('#asx-message').fill('ช่วยเพิ่มงานจากใบนี้');
  await page.locator('.asx-send').click();
  await expect.poll(() => mock.posts.filter(post => post.body.action === 'message').length).toBe(1);
  const body = mock.posts.find(post => post.body.action === 'message').body;
  expect([body.text, body.attachment.name, body.attachment.mimeType, body.attachment.data]).toEqual(['ช่วยเพิ่มงานจากใบนี้', 'ใบเสนอราคา.pdf', 'application/pdf', pdf.toString('base64')]);
});

test('mic: recording stays local until Stop, transcribes once, and leaves an editable draft for explicit Send', async ({ page }) => {
  await syntheticMicrophone(page);
  let releaseTranscription!: () => void;
  const pendingTranscription = new Promise<void>(resolve => { releaseTranscription = resolve; });
  const mock = await open(page, { transcribe: async () => {
    await pendingTranscription;
    return { text: 'เดือนนี้ได้เงินเท่าไหร่', tokens: 1, tokensLeft: 993, trialLeft: null };
  } });
  try {
    await page.getByRole('button', { name: 'พูดแทนการพิมพ์', exact: true }).click();
    await expect(page.getByText('กำลังฟังอยู่', { exact: true })).toBeVisible();
    const waveform = page.locator('canvas.asx-voice-wave');
    await expect(waveform).toBeVisible();
    // Wait for captured audio (not a timer fake), and verify the meter is drawing above its flat baseline.
    await expect(page.locator('.asx-voice-time')).toHaveText(/^0:0[1-9] \/ 1:00$/);
    await expect.poll(() => waveform.evaluate((canvas: HTMLCanvasElement) => {
      const pixels = canvas.getContext('2d')!.getImageData(0, Math.floor(canvas.height / 4), canvas.width, 1).data;
      return pixels.some((value, index) => index % 4 === 3 && value > 0);
    })).toBe(true);
    await expect(page.getByRole('button', { name: 'ส่งข้อความ', exact: true })).toHaveCount(0);
    expect(mock.posts).toHaveLength(0);

    await page.getByRole('button', { name: 'หยุดและถอดข้อความ' }).click();
    await expect(page.getByText('กำลังถอดเสียงเป็นข้อความ…', { exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: 'หยุดและถอดข้อความ' })).toBeDisabled();
    await expect.poll(() => mock.posts.filter(post => post.body.action === 'transcribe').length).toBe(1);
    expect(mock.posts.filter(post => post.body.action === 'message')).toHaveLength(0);
    expect(await microphoneStopped(page)).toBe(true);

    const transcription = mock.posts[0];
    expect(Object.keys(transcription.body).sort()).toEqual(['action', 'audio', 'language']);
    expect(transcription.body.language).toBe('th-TH');
    expect(transcription.body.audio.mimeType).toBe('audio/wav');
    expect(transcription.headers['x-account-id']).toBe(user.id);
    expect(transcription.headers['x-csrf-protection']).toBe('1');
    // This validates the real MediaRecorder -> decode -> PCM16 WAV path, not just the declared MIME type.
    const wav = Buffer.from(transcription.body.audio.data, 'base64');
    expect(wav.toString('ascii', 0, 4)).toBe('RIFF');
    expect(wav.toString('ascii', 8, 12)).toBe('WAVE');
    expect(wav.readUInt32LE(4)).toBe(wav.length - 8);
    expect(wav.readUInt16LE(20)).toBe(1);
    expect(wav.readUInt16LE(22)).toBe(1);
    expect(wav.readUInt32LE(24)).toBe(16_000);
    expect(wav.readUInt16LE(34)).toBe(16);
    expect(wav.readUInt32LE(40)).toBe(wav.length - 44);
    expect(wav.length).toBeGreaterThan(8_044);
    expect(wav.subarray(44).some(value => value !== 0)).toBe(true);

    releaseTranscription();
    const draft = page.locator('#asx-message');
    await expect(draft).toHaveValue('เดือนนี้ได้เงินเท่าไหร่');
    await expect(draft).toBeEditable();
    await expect(page.getByText('ถอดเสียงแล้ว ตรวจแก้ก่อนกดส่ง', { exact: true })).toBeVisible();
    await expect(page.locator('.asx-token')).toContainText('993');
    await expect(page.locator('.asx-msg.is-me')).toHaveCount(0);
    expect(mock.posts).toHaveLength(1);
    await draft.fill('เดือนนี้ได้เงินรวมเท่าไหร่');
    await expect(draft).toHaveValue('เดือนนี้ได้เงินรวมเท่าไหร่');
    expect(mock.posts.filter(post => post.body.action === 'message')).toHaveLength(0);

    await page.getByRole('button', { name: 'ส่งข้อความ', exact: true }).click();
    await expect.poll(() => mock.posts.filter(post => post.body.action === 'message').length).toBe(1);
    expect(mock.posts.find(post => post.body.action === 'message').body.text).toBe('เดือนนี้ได้เงินรวมเท่าไหร่');
    expect(mock.posts.filter(post => post.body.action === 'transcribe')).toHaveLength(1);
  } finally {
    releaseTranscription();
  }
});

test('mic: Cancel releases the microphone, keeps the existing draft, and never transcribes or sends', async ({ page }) => {
  await syntheticMicrophone(page);
  const mock = await open(page);
  const original = 'ร่างข้อความเดิม\nที่ยังไม่ส่ง';
  await page.locator('#asx-message').fill(original);
  await page.getByRole('button', { name: 'พูดแทนการพิมพ์', exact: true }).click();
  await expect(page.getByText('กำลังฟังอยู่', { exact: true })).toBeVisible();
  await expect(page.locator('.asx-voice-time')).toHaveText(/^0:0[1-9] \/ 1:00$/);
  expect(mock.posts).toHaveLength(0);
  await page.getByRole('button', { name: 'ยกเลิกเสียงนี้' }).click();
  await expect(page.locator('#asx-message')).toHaveValue(original);
  await expect(page.locator('#asx-message')).toBeFocused();
  await expect(page.locator('.asx-voice-composer')).toHaveCount(0);
  expect(await microphoneStopped(page)).toBe(true);
  // Let the recorder's final chunk/stop callbacks finish; cancelling must not turn them into a request.
  await page.waitForTimeout(350);
  expect(mock.posts).toHaveLength(0);
  await expect(page.locator('.asx-msg.is-me')).toHaveCount(0);
});

test('read aloud: an answer is spoken without Markdown marks', async ({ page }) => {
  await page.addInitScript(() => {
    (window as any).__spoken = [];
    window.speechSynthesis.speak = (utterance: SpeechSynthesisUtterance) => { (window as any).__spoken.push({ text: utterance.text, lang: utterance.lang }); };
  });
  await open(page);
  await ask(page, 'เดือนนี้ได้เงินเท่าไหร่');
  await page.getByRole('button', { name: 'ฟังคำตอบ' }).last().click();
  const spoken = await page.evaluate(() => (window as any).__spoken);
  expect(spoken).toEqual([{ text: 'เตรียมเพิ่มงาน แปลเอกสาร ไว้แล้วครับ กดยืนยันบนการ์ดเพื่อบันทึก', lang: 'th-TH' }]);
});

test('switched off: attaching stays "coming soon" (sample answers cannot read files)', async ({ page }) => {
  await open(page, { status: { enabled: false } });
  await expect(page.getByRole('button', { name: 'แนบไฟล์ · เร็ว ๆ นี้' })).toHaveAttribute('aria-disabled', 'true');
  await expect(page.getByRole('button', { name: 'ใช้เสียงได้เมื่อเชื่อมต่อเลขา AI' })).toHaveAttribute('aria-disabled', 'true');
  await expect(page.locator('.asx-composer input[type=file]')).toHaveCount(0);
});

for (const [label, width, height] of [['computer', 1440, 900], ['phone', 390, 844]] as const) {
  test(`${label}: the file chip, the sent file and the listen button fit without overlapping text`, async ({ page }) => {
    await open(page, { width, height });
    await page.locator('.asx-composer input[type=file]').setInputFiles({ name: 'สลิปโอนเงินค่าออกแบบโลโก้เดือนตุลาคม.png', mimeType: 'image/png', buffer: PNG });
    await expect(page.locator('.asx-file-chip:not(.is-sent)')).toBeVisible();
    await page.screenshot({ path: test.info().outputPath(`${label}-chip.png`) });
    await page.locator('#asx-message').fill('ช่วยดูสลิปนี้ว่าตรงกับงานไหน');
    await page.locator('.asx-send').click();
    await expect(page.locator('.asx-rcard.is-confirm')).toBeVisible();
    await expect(page.getByRole('button', { name: 'ฟังคำตอบ' }).last()).toBeVisible();
    await page.waitForTimeout(400);
    await page.screenshot({ path: test.info().outputPath(`${label}-sent.png`) });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    expect(await textOverlapIssues(page)).toEqual([]);
  });
}

test('admins see why the real assistant is not on for the account (members never do)', async ({ page }) => {
  await open(page, { status: { enabled: false, plan: 'admin' } });
  await expect(page.locator('.asx-hint.is-admin')).toHaveText('สำหรับแอดมิน: เลขา AI ยังไม่เปิดในบัญชีนี้ · เซิร์ฟเวอร์ยังปิด AI อยู่ (AI_ENABLED)');
});

const REAL_INBOX = {
  notices: [
    { id: 'month-2026-09', at: Date.parse('2026-10-01T02:00:00Z'), card: { category: 'report', title: 'สรุปการเงินประจำเดือน', subtitle: 'กันยายน 2569', metric: { label: 'กำไรสุทธิ', value: '฿ 9,999' }, blocks: [], alt: 'สรุปการเงินประจำเดือน (กันยายน 2569) · กำไรสุทธิ ฿ 9,999' } },
    { id: 'reminder-today', at: Date.now() - 60_000, card: { category: 'urgent', title: 'เตือนรับเงิน', subtitle: 'เครดิตเทอม · วันนี้', metric: { label: 'ยอดรอรับที่ต้องติดตาม', value: '฿ 12,000', note: '1 รายการ' },
      blocks: [{ kind: 'section', title: 'เลยกำหนด · 1 รายการ', tone: 'negative', items: [{ id: 'job-late', name: 'ออกแบบโลโก้จริง', client: 'ร้านกาแฟของจริง', amount: '฿ 12,000', meta: 'เลย 4 วัน', metaTone: 'negative', due: true, prompt: 'รับเงินบางส่วน #ABC123 ยอด ' }] }],
      footer: { label: 'ดูรายการรอรับเงิน', path: '/receivables' }, alt: 'เตือนรับเงิน: เลยกำหนด 1 · วันนี้ 0 · ใกล้ครบกำหนด 0 รายการ' } },
  ],
  quick: {
    unpaid: { category: 'reminder', title: 'รอรับเงิน', metric: { label: 'ยอดรอรับทั้งหมด', value: '฿ 34,600', note: '3 งาน' }, blocks: [{ kind: 'items', items: [{ id: 'u-0', name: 'งานค้างจริง', client: 'ลูกค้าจริง', amount: '฿ 34,600' }] }], alt: 'รอรับเงิน 3 งาน' },
    month: { category: 'report', title: 'สรุปเดือนนี้', blocks: [], alt: 'สรุปเดือนนี้' },
    wip: { category: 'working', title: 'กำลังดำเนินงาน', blocks: [], alt: 'กำลังดำเนินงาน' },
  },
  lineLinked: true, reminderOn: true,
};

test('notifications thread: this account\'s own reminder, real ได้รับแล้ว, quick replies and the typed partial amount', async ({ page }) => {
  const mock = await open(page, { inbox: REAL_INBOX });
  const row = page.locator('.asx-side').getByText('แจ้งเตือนอัตโนมัติ').first();
  await row.click();
  const card = page.locator('.asx-thread').getByText('ออกแบบโลโก้จริง').first();
  await expect(card).toBeVisible();
  await expect(page.locator('.asx-sample-banner')).toHaveCount(0);
  await expect(page.locator('.asx-thread').getByText('ตัวอย่าง', { exact: true })).toHaveCount(0);
  const readsBefore = mock.dataReads();
  await page.getByRole('button', { name: 'ได้รับแล้ว' }).click();
  await expect(page.locator('.asx-thread').getByText('บันทึกรับเงินแล้ว')).toBeVisible();
  expect(mock.posts.filter(post => post.body.action === 'line-due').map(post => post.body)).toEqual([{ action: 'line-due', kind: 'paid', id: 'job-late' }]);
  await expect.poll(() => mock.dataReads()).toBeGreaterThan(readsBefore);
  // Quick replies answer from this account's data, without asking the AI.
  await page.locator('.asx-quick').getByRole('button', { name: 'รอรับเงิน' }).click();
  await expect(page.locator('.asx-thread').getByText('งานค้างจริง')).toBeVisible();
  expect(mock.posts.some(post => post.body.action === 'message')).toBe(false);
  // ได้ไม่ครบ: the code goes in the box, the amount is typed after it.
  await page.getByRole('button', { name: 'ได้ไม่ครบ' }).click();
  await expect(page.locator('#asx-message')).toHaveValue('รับเงินบางส่วน #ABC123 ยอด ');
  await page.locator('#asx-message').pressSequentially('2000');
  await page.locator('.asx-send').click();
  await expect(page.locator('.asx-thread').getByText('บันทึกยอดจาก รับเงินบางส่วน #ABC123 ยอด 2000')).toBeVisible();
  await page.screenshot({ path: test.info().outputPath('line-thread-real.png') });
});
