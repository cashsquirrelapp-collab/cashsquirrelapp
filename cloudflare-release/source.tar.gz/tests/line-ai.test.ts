import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { lineAssistantReply, markdownToLineText, decodeAssistantAction, parseAssistantCommand, assistantCommand } from '../backend/src/ai/lineFormat';
import { lineEventCommand } from '../backend/src/handlers/line-webhook';
import { handleAssistantMessage, type LineAssistantDependencies, type UserRow } from '../backend/src/services/lineAssistant';

// LINE talks to เลขากระรอก, the same Gemini assistant as the app (owner, 2026-10-24). Quick entries stay
// deterministic; everything else goes to the assistant; its cards become LINE cards with ยืนยัน / ยกเลิก.

const previousAppUrl = process.env.APP_URL;
process.env.APP_URL = 'https://preview.example.test';
after(() => { if (previousAppUrl === undefined) delete process.env.APP_URL; else process.env.APP_URL = previousAppUrl; });

const PROPOSAL = 'p_0b9d3c1e-4f5a-4b6c-8d7e-9f0a1b2c3d4e';
const userId = '11111111-1111-4111-8111-111111111111';
const linkedUser = (): UserRow => ({ user_id: userId, jobs: [], goals: [], settings: {}, expenses: [], statuses: [], notif_settings: { userName: 'ตัวอย่าง', nameAskedAt: '2026-10-01T00:00:00Z' } as any });

function deps(calls: string[], over: Partial<LineAssistantDependencies> = {}): LineAssistantDependencies {
  return {
    async findUserByLineId() { return linkedUser(); },
    async checkLinkedAccountWriteAccess() { return { allowed: true as const }; },
    async isProUser() { return true; },
    async saveJobDraft(user, draft) { calls.push(`draft:${draft.name}`); user.notif_settings = { ...(user.notif_settings || {}), pendingJobDraft: { draft, createdAt: new Date().toISOString(), operationKey: 'k' } } as any; },
    async assistantAnswer(_user, text, history) { calls.push(`ai:${text}:${history.length}`); return { messages: [{ type: 'text', text: `ตอบ: ${text}` }], text: `ตอบ: ${text}` }; },
    async assistantCommand(_user, command) { calls.push(`cmd:${command.action}:${command.proposalId}`); return [{ type: 'text', text: 'บันทึกแล้ว' }]; },
    ...over,
  };
}
const texts = (messages: Awaited<ReturnType<typeof handleAssistantMessage>>) => (messages || []).map(message => (message as { text?: string }).text ?? (message as { altText?: string }).altText);

test('LINE: any message the bot does not know goes to เลขา, with or without "ถาม AI"', async () => {
  const calls: string[] = [];
  assert.deepEqual(texts(await handleAssistantMessage('Uline', 'ใครค้างจ่ายบ้าง', 'op-1', deps(calls))), ['ตอบ: ใครค้างจ่ายบ้าง']);
  assert.deepEqual(texts(await handleAssistantMessage('Uline', 'ถาม AI เดือนนี้ได้เงินเท่าไหร่', 'op-2', deps(calls))), ['ตอบ: เดือนนี้ได้เงินเท่าไหร่']);
  assert.deepEqual(calls, ['ai:ใครค้างจ่ายบ้าง:0', 'ai:เดือนนี้ได้เงินเท่าไหร่:0']);
});

test('LINE: quick entries stay on the free deterministic path (no AI call)', async () => {
  const calls: string[] = [];
  await handleAssistantMessage('Uline', 'เพิ่มงาน ออกแบบโลโก้ 5000', 'op-3', deps(calls));
  assert.ok(calls.some(call => call.startsWith('draft:')));
  assert.ok(!calls.some(call => call.startsWith('ai:')));
});

test('LINE: when the real เลขา is not on for the account, unknown messages still get no reply, as before', async () => {
  const calls: string[] = [];
  const reply = await handleAssistantMessage('Uline', 'ใครค้างจ่ายบ้าง', 'op-4', deps(calls, { async assistantAnswer() { return null; } }));
  assert.deepEqual(reply, []);
});

test('LINE: a failed AI answer says to try again instead of staying silent', async () => {
  const reply = await handleAssistantMessage('Uline', 'สรุปให้หน่อย', 'op-5', deps([], { async assistantAnswer() { throw new Error('timeout'); } }));
  assert.match(texts(reply)[0] ?? '', /ลองพิมพ์ใหม่/);
});

test('LINE: ยืนยัน / ยกเลิก buttons on a เลขา card come back as postbacks and reach the confirm step', async () => {
  const command = lineEventCommand({ type: 'postback', source: { type: 'user', userId: 'U1' }, postback: { data: `ai:confirm:${PROPOSAL}` } } as any);
  assert.equal(command, `ยืนยันรายการเลขา ${PROPOSAL}`);
  assert.equal(lineEventCommand({ type: 'postback', source: { type: 'user', userId: 'U1' }, postback: { data: `ai:cancel:${PROPOSAL}` } } as any), `ยกเลิกรายการเลขา ${PROPOSAL}`);
  assert.equal(lineEventCommand({ type: 'postback', source: { type: 'user', userId: 'U1' }, postback: { data: 'ai:confirm:not-an-id' } } as any), null);
  const calls: string[] = [];
  await handleAssistantMessage('Uline', command!, 'op-6', deps(calls));
  assert.deepEqual(calls, [`cmd:confirm:${PROPOSAL}`]);
  assert.deepEqual(parseAssistantCommand(assistantCommand('cancel', PROPOSAL)), { action: 'cancel', proposalId: PROPOSAL });
  assert.deepEqual(decodeAssistantAction(`ai:confirm:${PROPOSAL}`), { action: 'confirm', proposalId: PROPOSAL });
});

test('LINE text: tables become one line per row, Markdown marks are removed', () => {
  const text = markdownToLineText([
    'มีค้างรับ **5 งาน** รวม **฿47,100** ครับ', '',
    '| งาน | ลูกค้า | ยอดค้าง | ครบกำหนด |', '|---|---|---|---|',
    '| ออกแบบโลโก้ | ร้านกาแฟตัวอย่าง | ฿12,000 | เลยกำหนด 15 วัน |',
    '| แบนเนอร์ | ร้านกาแฟตัวอย่าง | ฿3,500 | วันนี้ |', '',
    'ดูทั้งหมดได้ที่ [หน้างาน](/jobs)',
  ].join('\n'));
  assert.equal(text, 'มีค้างรับ 5 งาน รวม ฿47,100 ครับ\n\n• ออกแบบโลโก้ · ร้านกาแฟตัวอย่าง · ฿12,000 · เลยกำหนด 15 วัน\n• แบนเนอร์ · ร้านกาแฟตัวอย่าง · ฿3,500 · วันนี้\n\nดูทั้งหมดได้ที่ หน้างาน');
});

test('LINE cards: confirmation has ยืนยัน / ยกเลิก postbacks; documents and summaries become formal cards; at most five messages', () => {
  const reply = lineAssistantReply('เตรียมไว้แล้วครับ', [
    { kind: 'confirm', id: PROPOSAL, title: 'เพิ่มงานใหม่ 1 งาน', changes: [{ label: 'งาน', value: 'แปลเอกสาร' }, { label: 'มูลค่า', value: '฿4,000' }] },
    { kind: 'document', docType: 'ใบเสนอราคา', number: 'QT-2569-008', client: 'บริษัท ตัวอย่าง จำกัด', amount: '฿12,000', path: '/invoice?type=quotation&document=doc-2' },
    { kind: 'summary', period: 'ต.ค. 2569', income: '฿18,000', expense: '฿2,430', balance: '฿15,570' },
  ]);
  assert.equal(reply.length, 4);
  assert.equal(reply[0].type, 'text');
  const json = JSON.stringify(reply);
  assert.ok(json.includes(`"data":"ai:confirm:${PROPOSAL}"`) && json.includes(`"data":"ai:cancel:${PROPOSAL}"`));
  assert.ok(json.includes('QT-2569-008') && json.includes('document%3Ddoc-2') === false && json.includes('from=line'));
  assert.ok(json.includes('฿15,570'));
  const many = lineAssistantReply('ก\n\nข\n\nค\n\nง', Array.from({ length: 5 }, () => ({ kind: 'summary', period: 'ต.ค. 2569', income: '฿1', expense: '฿1', balance: '฿0' }) as const));
  assert.ok(many.length <= 5);
  assert.equal(many.filter(message => message.type === 'text').length, 2);
});
