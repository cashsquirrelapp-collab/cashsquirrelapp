import { before, after, test } from 'node:test';
import assert from 'node:assert/strict';
import type { Server } from 'node:http';
import Stripe from 'stripe';
import { createApp } from '../backend/src/http/app.js';
import { stripe } from '../backend/src/config/stripe.js';
import { seal } from '../backend/src/security/cookies.js';
import { PREPAID_OFFER, prepaidLookup, prepaidMetadata } from '../backend/src/services/prepaidPlans.js';
import { PRO_PERIODS, PRO_PRICING } from '../shared/proPricing.js';

Object.assign(process.env, {
  APP_URL:'http://127.0.0.1:3000', SUPABASE_URL:'https://prepaid.supabase.co',
  SUPABASE_PUBLISHABLE_KEY:'test-key', SUPABASE_SERVICE_ROLE_KEY:'test-admin',
  SESSION_SECRET:'test-only-secret-'.repeat(4), STRIPE_SECRET_KEY:'sk_test_only',
  STRIPE_MODE:'test', STRIPE_WEBHOOK_SECRET:'whsec_test', KRAROK_PREPAID_ENABLED:'true',
});
const user={id:'11111111-1111-4111-8111-111111111111',email:'billing@example.test'};
const token=`e30.${Buffer.from(JSON.stringify({sub:user.id,session_id:'33333333-3333-4333-8333-333333333333'})).toString('base64url')}.test`;
const cookie=`cashflow-session=${seal({access_token:token,refresh_token:'test-refresh',expires_at:Math.floor(Date.now()/1000)+3600,issued_at:Date.now()})}`;
const realFetch=globalThis.fetch;
let server:Server, origin:string, order:any, session:any, creates=0, fulfilled:any[]=[], finished:any[]=[], expires=0, expirationFails=false;
let banned=false;
const rateKeys: Array<{p_key:string;p_limit:number}>=[];
before(async()=>{
  globalThis.fetch=async(input,init)=>{
    const url=String(input);
    if(!url.startsWith('https://prepaid.supabase.co/')) return realFetch(input,init);
    const json=(body:any)=>new Response(JSON.stringify(body),{headers:{'content-type':'application/json'}});
    if(url.includes('/auth/v1/user')) return json(user);
    if(url.includes('/cashflow_rate_limit')) {rateKeys.push(JSON.parse(String(init?.body)));return json(true);}
    if(url.includes('/cashflow_session_active')) return json(true);
    if(url.includes('/cashflow_user_roles')) return json({role:'user'});
    if(url.includes('/subscriptions')) return json(banned?{plan:'admin_revoked',status:'canceled'}:null);
    if(url.includes('/rest/v1/cashflow_prepaid_orders')) return json(url.includes('select=session_id')?[]:order);
    const args=JSON.parse(String(init?.body||'{}'));
    if(url.includes('/cashflow_reserve_prepaid_checkout')) {
      if(!order) order={id:args.p_order_id,user_id:user.id,period:args.p_period,
        months:PRO_PRICING[args.p_period as keyof typeof PRO_PRICING].months,
        amount:PRO_PRICING[args.p_period as keyof typeof PRO_PRICING].total*100,
        method:args.p_method,price_id:args.p_price_id,livemode:false,customer_id:'cus_prepaid',
        session_id:null,request:null,checkout_url:null,status:'reserved',expires_at:new Date(Date.now()+45*60_000).toISOString()};
      return json({result:'reserved',order_id:order.id});
    }
    if(url.includes('/cashflow_bind_stripe_customer')) return json(true);
    if(url.includes('/cashflow_prepare_prepaid_checkout')) {
      order.request=args.p_request;return json(args.p_request);
    }
    if(url.includes('/cashflow_attach_prepaid_checkout')) {
      order.session_id=args.p_session_id;order.checkout_url=args.p_url;return json(null);
    }
    if(url.includes('/cashflow_fulfill_prepaid')) {fulfilled.push(args);return json('paid');}
    if(url.includes('/cashflow_finish_prepaid_checkout')) {finished.push(args);return json(null);}
    throw new Error(`Unexpected mock endpoint ${new URL(url).pathname}`);
  };
  stripe.prices.list=(async(params:any)=>{
    const period=PRO_PERIODS.find(p=>prepaidLookup(p)===params.lookup_keys[0])!;
    return {data:[{id:`price_${period}`,active:true,livemode:false,type:'one_time',recurring:null,
      billing_scheme:'per_unit',currency:'thb',unit_amount:PRO_PRICING[period].total*100,
      lookup_key:prepaidLookup(period),metadata:{offer_version:PREPAID_OFFER,period,months:String(PRO_PRICING[period].months)}}]};
  }) as any;
  stripe.paymentMethodConfigurations.list=(async()=>({data:[{id:'pmc_prepaid',active:true,is_default:true,livemode:false,
    card:{available:true,display_preference:{value:'on'}},promptpay:{available:true,display_preference:{value:'on'}}}]})) as any;
  stripe.customers.retrieve=(async()=>({id:'cus_prepaid',livemode:false,metadata:{app_user_id:user.id,workspace_type:'personal',workspace_id:user.id}})) as any;
  stripe.subscriptions.list=(()=>({autoPagingToArray:async()=>[]})) as any;
  stripe.checkout.sessions.create=(async(request:any,options:any)=>{
    creates++;assert.equal(options.idempotencyKey,`krarok-prepaid:${order.id}`);
    assert.deepEqual(request.line_items,[{price:order.price_id,quantity:1}]);
    const metadata=prepaidMetadata(order);
    session={id:'cs_prepaid',mode:'payment',status:'open',payment_status:'unpaid',livemode:false,
      customer:order.customer_id,client_reference_id:user.id,metadata,currency:'thb',
      amount_total:order.amount,amount_subtotal:order.amount,expires_at:request.expires_at,
      url:'https://checkout.stripe.com/c/pay/cs_prepaid'};
    return session;
  }) as any;
  stripe.checkout.sessions.retrieve=(async()=>session) as any;
  stripe.checkout.sessions.expire=(async()=>{
    expires++;
    if(expirationFails) throw new Error('Network timeout');
    session={...session,status:'expired'};
    return session;
  }) as any;
  server=await new Promise<Server>(resolve=>{const s=createApp().listen(0,'127.0.0.1',()=>resolve(s));});
  origin=`http://127.0.0.1:${(server.address() as any).port}`;
});
after(async()=>{
  globalThis.fetch=realFetch;
  await new Promise<void>((resolve,reject)=>server.close(e=>e?reject(e):resolve()));
});
const headers={cookie,'x-account-id':user.id,'content-type':'application/json',
  'x-csrf-protection':'1',origin:process.env.APP_URL!};
const checkout=(body:unknown)=>realFetch(origin+'/api/billing',{method:'POST',headers,body:JSON.stringify(body)});
const webhook=async(tamper=false)=>{
  const raw=JSON.stringify({id:'evt_prepaid',type:'checkout.session.completed',livemode:false,data:{object:{id:session.id}}});
  const signature=Stripe.webhooks.generateTestHeaderString({payload:raw,secret:'whsec_test'});
  return realFetch(origin+'/api/stripe-webhook',{method:'POST',headers:{'stripe-signature':signature,'content-type':'application/json'},body:raw+(tamper?' ':'')});
};
test('checkout requires authentication, CSRF and an allowed period; injected amount or identity cannot reach Stripe',async()=>{
  const before=creates;
  await realFetch(origin+'/api/billing',{headers});
  const readKey=[...rateKeys].reverse().find(key=>key.p_limit===60)?.p_key;
  await checkout({action:'checkout',period:'invalid'});
  const writeKey=[...rateKeys].reverse().find(key=>key.p_limit===12)?.p_key;
  assert.ok(readKey && writeKey);
  assert.notEqual(readKey,writeKey,'status polling cannot exhaust the mutation budget');
  assert.equal((await realFetch(origin+'/api/billing',{method:'POST',headers:{'content-type':'application/json','x-csrf-protection':'1',origin:process.env.APP_URL!},body:'{}'})).status,401);
  assert.equal((await realFetch(origin+'/api/billing',{method:'POST',headers:{...headers,origin:'https://evil.test'},body:'{}'})).status,403);
  for(const body of [{action:'checkout',period:'year',amount:15900},{action:'checkout',period:'year',months:1},
    {action:'checkout',period:'year',user_id:'other'},{action:'checkout',period:'invalid'}]) {
    assert.equal((await checkout(body)).status,400);
  }
  assert.equal(creates,before);
});
for(const period of PRO_PERIODS) for(const method of ['card','promptpay']) {
  test(`HTTP ${period}/${method}: checkout, retry and signed webhook retain exact ownership/amount/months`,async()=>{
    order=null;session=null;fulfilled=[];
    const before=creates;
    const body={action:method==='card'?'checkout':'promptpay_checkout',period};
    const response=await checkout(body);
    assert.equal(response.status,200,await response.clone().text());
    const result:any=await response.json();
    assert.equal(result.amount,PRO_PRICING[period].total*100);assert.equal(result.months,PRO_PRICING[period].months);
    assert.equal((await checkout(body)).status,200);assert.equal(creates,before+1);
    assert.equal((await webhook(true)).status,400);assert.equal(fulfilled.length,0);
    // A signed event alone cannot grant access while canonical Stripe state is unpaid.
    assert.equal((await webhook()).status,200);assert.equal(fulfilled.length,0);
    session={...session,status:'complete',payment_status:'paid',
      line_items:{has_more:false,data:[{quantity:1,currency:'thb',amount_total:order.amount,amount_subtotal:order.amount,
        price:{id:order.price_id,unit_amount:order.amount,currency:'thb',type:'one_time',recurring:null}}]},
      payment_intent:{id:'pi_prepaid',status:'succeeded',livemode:false,customer:order.customer_id,
        amount:order.amount,amount_received:order.amount,amount_capturable:0,currency:'thb',
        metadata:prepaidMetadata(order),payment_method:{type:method},
        latest_charge:{id:'ch_prepaid',payment_intent:'pi_prepaid',customer:order.customer_id,status:'succeeded',
          paid:true,livemode:false,amount:order.amount,currency:'thb',created:Math.floor(Date.now()/1000),
          payment_method_details:{type:method},amount_refunded:0,refunded:false,disputed:false}}};
    assert.equal((await webhook()).status,200);
    assert.equal(fulfilled.length,1);assert.equal(fulfilled[0].p_user_id,user.id);
    assert.equal(fulfilled[0].p_amount,PRO_PRICING[period].total*100);
    assert.equal(fulfilled[0].p_months,PRO_PRICING[period].months);
  });
}
test('cancel only the exact owned unpaid checkout; unknown expiration and racing payments never release it',async()=>{
  order=null;session=null;finished=[];fulfilled=[];expirationFails=false;
  assert.equal((await checkout({action:'checkout',period:'month'})).status,200);
  const body={action:'cancel_checkout',order_id:order.id};
  const before=expires;
  order.user_id='22222222-2222-4222-8222-222222222222';
  assert.equal((await checkout(body)).status,404);
  assert.equal(expires,before);
  order.user_id=user.id;
  expirationFails=true;
  assert.equal((await checkout(body)).status,409);
  assert.equal(finished.length,0);
  // A completed asynchronous payment is not safe to cancel even before it is paid.
  session.status='complete';
  assert.equal((await checkout(body)).status,409);
  assert.equal(finished.length,0);
  session.status='open';expirationFails=false;
  assert.equal((await checkout(body)).status,200);
  assert.equal(finished.length,1);
  assert.equal(finished[0].p_order_id,order.id);
  assert.equal(finished[0].p_user_id,user.id);
  assert.equal(finished[0].p_state,'expired');
  const expiredCalls=expires;
  assert.equal((await checkout(body)).status,200);
  assert.equal(expires,expiredCalls);
  assert.equal(fulfilled.length,0);
});

test('banned Pro cannot create either payment method and readiness is closed',async()=>{
  banned=true;const before=creates;
  try {
    const status=await realFetch(origin+'/api/billing',{headers});
    assert.equal((await status.json() as any).checkout_ready,false);
    for(const action of ['checkout','promptpay_checkout'])assert.equal((await checkout({action,period:'month'})).status,403);
    assert.equal(creates,before);
  }finally{banned=false;}
});
