// Moves the Stripe catalog to the prices in shared/proPricing.ts (owner, 2026-10-25: the customer pays the card fee,
// so ฿159 → ฿177, ฿849 → ฿895, ฿1,490 → ฿1,562). Checkout only sells a price that matches the screen to the satang
// (validPrepaidPrice / validRecurringPrice), so until this runs, checkout stays closed instead of charging another amount.
//
// The owner runs it, with the owner's own key in the environment (never shown to anyone, never saved):
//   STRIPE_SECRET_KEY=sk_test_… node --import tsx scripts/stripe-reprice.ts            (shows what it would do)
//   STRIPE_SECRET_KEY=sk_test_… node --import tsx scripts/stripe-reprice.ts --apply    (creates the new prices)
// Test mode first (sk_test_…), then live (sk_live_…). For each lookup key that exists, it creates the new price on the
// same product with the same metadata and moves the lookup key to it; existing subscriptions keep their old price.
import Stripe from 'stripe';
import { pathToFileURL } from 'node:url';
import { PRO_PERIODS, PRO_PRICING, type ProPeriod } from '../shared/proPricing';
import { PREPAID_OFFER, prepaidLookup, validPrepaidPrice } from '../backend/src/services/prepaidPlans';
import { recurringLookup, recurringProductId, validRecurringPrice } from '../backend/src/services/cardPlans';

type Kind = 'one_time' | 'recurring';
export interface PlannedPrice { kind: Kind; period: ProPeriod; lookupKey: string; currentAmount: number | null; newAmount: number; action: 'create' | 'ok' | 'missing'; params?: Stripe.PriceCreateParams }

type PriceReader = { prices: { list(params: Stripe.PriceListParams): Promise<{ data: Stripe.Price[] }> } };

/** What to create so every existing lookup key sells the price on screen. Changes nothing by itself. */
export async function planReprice(stripe: PriceReader, livemode: boolean): Promise<PlannedPrice[]> {
  const plan: PlannedPrice[] = [];
  for (const period of PRO_PERIODS) {
    const { months, total } = PRO_PRICING[period];
    for (const kind of ['one_time', 'recurring'] as const) {
      const lookupKey = kind === 'one_time' ? prepaidLookup(period) : recurringLookup(period);
      const found = (await stripe.prices.list({ lookup_keys: [lookupKey], active: true, limit: 2 })).data;
      const current = found[0];
      const row: PlannedPrice = { kind, period, lookupKey, currentAmount: current ? (current.unit_amount ?? 0) / 100 : null, newAmount: total, action: 'missing' };
      if (!current) { plan.push(row); continue; }
      const valid = kind === 'one_time' ? validPrepaidPrice(current, period, livemode) : validRecurringPrice(current, period, livemode);
      if (valid && found.length === 1) { plan.push({ ...row, action: 'ok' }); continue; }
      const product = typeof current.product === 'string' ? current.product : current.product.id;
      plan.push({ ...row, action: 'create', params: {
        product: kind === 'recurring' ? recurringProductId() : product,
        currency: 'thb', unit_amount: total * 100, lookup_key: lookupKey, transfer_lookup_key: true,
        nickname: `Krarok Pro ${period} ฿${total.toLocaleString('en-US')} (card fee included, 2026-10-25)`,
        metadata: kind === 'one_time' ? { ...current.metadata, offer_version: PREPAID_OFFER, period, months: String(months) } : { ...current.metadata },
        ...(current.tax_behavior && current.tax_behavior !== 'unspecified' ? { tax_behavior: current.tax_behavior } : {}),
        ...(kind === 'recurring' ? { recurring: months === 12 ? { interval: 'year', interval_count: 1, usage_type: 'licensed' } : { interval: 'month', interval_count: months, usage_type: 'licensed' } } : {}),
      } });
    }
  }
  return plan;
}

async function main() {
  const key = process.env.STRIPE_SECRET_KEY?.trim();
  if (!key || !/^sk_(test|live)_/.test(key)) {
    console.log('Set STRIPE_SECRET_KEY to your sk_test_… or sk_live_… key in this terminal first (it is not printed or saved).');
    process.exitCode = 1;
    return;
  }
  const livemode = key.startsWith('sk_live_');
  const apply = process.argv.includes('--apply');
  const stripe = new Stripe(key);
  console.log(`Stripe ${livemode ? 'LIVE' : 'test'} mode. ${apply ? 'Creating the new prices.' : 'Dry run: nothing is changed (add --apply to create).'}`);
  const plan = await planReprice(stripe, livemode);
  for (const row of plan) {
    const now = row.currentAmount === null ? 'none' : `฿${row.currentAmount}`;
    console.log(`  ${row.lookupKey.padEnd(40)} ${row.kind.padEnd(9)} now ${now.padEnd(8)} → ฿${row.newAmount}  ${row.action === 'ok' ? 'already right' : row.action === 'missing' ? 'not in this account (left alone)' : apply ? 'creating' : 'would create'}`);
  }
  if (!apply) return;
  for (const row of plan) if (row.action === 'create' && row.params) await stripe.prices.create(row.params);
  // Read back what checkout will read, with the same checks.
  const after = await planReprice(stripe, livemode);
  const wrong = after.filter(row => row.action === 'create');
  console.log(wrong.length ? `Not right yet: ${wrong.map(row => row.lookupKey).join(', ')}` : 'Done: every existing lookup key now sells the price on screen.');
  if (wrong.length) process.exitCode = 1;
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) main().catch(error => {
  console.error('Stopped:', (error as Error).message);
  process.exitCode = 1;
});
