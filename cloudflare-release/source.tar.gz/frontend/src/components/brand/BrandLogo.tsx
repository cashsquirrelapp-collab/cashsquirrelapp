import React from 'react';
import './brand.css';

/** Official tail symbol; the squirrel character remains a separate mascot. */
export function BrandLogo({ size = 32, className = '', inverse = false }: { size?: number; className?: string; inverse?: boolean }) {
  return <span aria-hidden="true" className={`krarok-brand-symbol inline-flex shrink-0 ${className}`}>
    <img src={`/brand/logo01-v1/symbol-${inverse ? 'white' : 'ci'}.svg`} width={size} height={size} alt="" style={{ width: size, height: size, objectFit: 'contain' }} />
  </span>;
}

/** Keep the established Thai name and typography; only the symbol changes. */
export function BrandLockup({ size = 32, className = '', inverse = false }: { size?: number; className?: string; latin?: boolean; inverse?: boolean }) {
  return <span className={`krarok-brand-lockup inline-flex items-center${inverse ? ' krarok-brand-inverse' : ''} ${className}`} style={{ gap: Math.round(size * 0.3) }}>
    <BrandLogo size={size} inverse={inverse} />
    <span className="krarok-brand-name whitespace-nowrap leading-none text-brand-text" style={{ fontFamily: "'Prompt', 'IBM Plex Sans Thai', sans-serif", fontWeight: 600, fontSize: Math.round(size * 0.56) }}>
      กระรอก<span className="text-[#E65F2B] dark:text-[#FF7A45]">ตุนเงิน</span>
    </span>
  </span>;
}
