import { uiInput, uiPrimaryButton, uiSecondaryButton } from './uiStyles';
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { CustomDialogState } from '../../../../shared/types';
import { AlertCircle, HelpCircle, CheckCircle } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface CustomDialogProps {
  dialog: CustomDialogState;
  onClose: () => void;
}

export default function CustomDialog({ dialog, onClose }: CustomDialogProps) {
  const { t } = useLanguage();
  const [inputValue, setInputValue] = useState(dialog.defaultValue || '');

  useEffect(() => {
    setInputValue(dialog.defaultValue || '');
  }, [dialog.defaultValue, dialog.isOpen]);

  if (!dialog.isOpen) return null;

  const handleConfirm = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    dialog.onConfirm(inputValue);
    onClose();
  };

  const handleCancel = () => {
    if (dialog.onCancel) dialog.onCancel();
    onClose();
  };

  // Titles like "ดาวน์โหลดสำเร็จ" / "Saved!" are good news, not a caution — show a checkmark
  // instead of the exclamation-mark icon so success actually reads as success. Bilingual since
  // dialog.title comes from t() and can be Thai or English depending on the app's language;
  // "ไม่สำเร็จ" / "Unsuccessful" (failed) stay on the regular alert icon.
  const isSuccessAlert = /สำเร็จ|success|saved|allocated|updated|confirmed|deposited|created|uploaded|ready/i.test(dialog.title)
    && !/ไม่สำเร็จ|unsuccessful|failed|error/i.test(dialog.title);

  const getIcon = () => {
    switch (dialog.type) {
      case 'alert':
        return isSuccessAlert
          ? <CheckCircle className="w-8 h-8 text-emerald-500 shrink-0" />
          : <AlertCircle className="w-8 h-8 text-amber-500 shrink-0" />;
      case 'prompt':
        return <HelpCircle className="w-8 h-8 text-indigo-500 shrink-0" />;
      default:
        return <AlertCircle className="w-8 h-8 text-rose-500 shrink-0" />;
    }
  };

  // Portaled straight to <body>, not rendered inline in the app tree -- DashboardTab/JobsTab/
  // JobDetailModal's own modals already portal there too, and any of them can trigger this dialog
  // (e.g. the Dashboard quick-pay list's "ได้เงินครบแล้ว" confirm). An inline z-[999] here still
  // loses to a later document.body portal once *any* ancestor between this component and <body>
  // picks up a transform/filter/backdrop-filter (each opens its own stacking context, which traps
  // "fixed" positioning and makes the z-index only compare within that ancestor) -- the dialog was
  // still in the DOM and technically clickable at its coordinates, just painted underneath instead
  // of on top, so confirming from inside another modal silently did nothing the user could see.
  return createPortal(
    <AnimatePresence>
      <div className="ksm-modal fixed inset-0 z-[999] flex items-center justify-center p-4 overflow-y-auto" role="presentation">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleCancel}
          className="fixed inset-0 bg-[#302018]/25 backdrop-blur-[2px] cursor-pointer"
        />

        {/* Dialog Box */}
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 15 }}
          transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
          role="dialog"
          aria-modal="true"
          aria-label={dialog.title}
          className="relative bg-brand-white dark:bg-neutral-900 border border-brand-border dark:border-neutral-800 rounded-[22px] p-6 shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto space-y-4"
        >
          <div className="flex items-start gap-4">
            <div className="p-3 bg-brand-faint dark:bg-neutral-800 rounded-2xl">
              {getIcon()}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-bold text-brand-text dark:text-white tracking-tight">
                {dialog.title}
              </h3>
              <p className="text-xs text-brand-muted dark:text-neutral-400 mt-1.5 leading-relaxed whitespace-pre-line">
                {dialog.message}
              </p>
            </div>
          </div>

          <form onSubmit={handleConfirm} className="space-y-4">
            {dialog.type === 'prompt' && (
              <input
                autoFocus
                type={dialog.inputType || 'text'}
                placeholder={dialog.placeholder}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className={uiInput}
              />
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2">
              {dialog.type !== 'alert' && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className={uiSecondaryButton}
                >
                  {t('common.cancel')}
                </button>
              )}
              <button
                type="submit"
                className={uiPrimaryButton}
              >
                {t(dialog.type === 'alert' ? 'common.ok' : 'common.confirm')}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>,
    document.body
  );
}
