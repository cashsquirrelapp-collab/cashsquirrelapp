// Reads an Excel, OpenDocument or CSV file into the cell grids sheetImport.ts works on. The SheetJS
// module is passed in, so the app loads it only when someone imports and tests can pass their own.

import type * as XLSXModule from 'xlsx';
import { MAX_IMPORT_ROWS, type SheetCell, type SheetGrid } from './sheetImport';

type XLSX = typeof XLSXModule;
const MAX_COLUMNS = 60;
const pad = (n: number) => String(n).padStart(2, '0');

export function sheetToGrid(xlsx: XLSX, sheet: XLSXModule.WorkSheet, name: string): SheetGrid {
  const ref = sheet['!ref'];
  if (!ref) return { name, rows: [] };
  const range = xlsx.utils.decode_range(ref);
  const lastRow = Math.min(range.e.r, range.s.r + MAX_IMPORT_ROWS + 100);
  const lastCol = Math.min(range.e.c, range.s.c + MAX_COLUMNS - 1);
  const rows: SheetCell[][] = [];
  for (let r = 0; r <= lastRow; r++) {
    const row: SheetCell[] = [];
    for (let c = 0; c <= lastCol; c++) {
      const cell = sheet[xlsx.utils.encode_cell({ r, c })] as XLSXModule.CellObject | undefined;
      if (!cell || cell.v === undefined || cell.v === null) { row.push({ raw: null, text: '' }); continue; }
      const raw = cell.v instanceof Date ? cell.v.toISOString() : (cell.v as string | number | boolean);
      const text = (cell.w ?? String(cell.v)).trim();
      let date: string | undefined;
      // A date-formatted number is a day count; read its parts with SheetJS so no time zone shifts it.
      if (cell.t === 'n' && typeof cell.v === 'number' && cell.z && xlsx.SSF.is_date(String(cell.z))) {
        const parts = xlsx.SSF.parse_date_code(cell.v);
        if (parts && parts.y >= 1990 && parts.y <= 2100) date = `${parts.y}-${pad(parts.m)}-${pad(parts.d)}`;
      } else if (cell.t === 'd' && cell.v instanceof Date) {
        date = `${cell.v.getFullYear()}-${pad(cell.v.getMonth() + 1)}-${pad(cell.v.getDate())}`;
      }
      row.push(date ? { raw, text, date } : { raw, text });
    }
    rows.push(row);
  }
  return { name, rows };
}

/** Text of a CSV file: UTF-8, or the Thai Windows encoding older Excel versions save. */
export function decodeCsv(data: ArrayBuffer): string {
  const utf8 = new TextDecoder('utf-8').decode(data);
  if (!utf8.includes('�')) return utf8.replace(/^﻿/, '');
  try { return new TextDecoder('windows-874').decode(data); } catch { return utf8; }
}

export function readWorkbook(xlsx: XLSX, data: ArrayBuffer, fileName: string): SheetGrid[] {
  const isCsv = /\.(csv|txt|tsv)$/i.test(fileName);
  // CSV values stay text, so Thai dates such as 15/10/2567 are read by sheetImport, not guessed here.
  const book = isCsv
    ? xlsx.read(decodeCsv(data), { type: 'string', raw: true, cellText: true })
    : xlsx.read(data, { type: 'array', cellDates: false, cellNF: true, cellText: true });
  return book.SheetNames.map(name => sheetToGrid(xlsx, book.Sheets[name], isCsv ? fileName.replace(/\.[^.]+$/, '') : name));
}
