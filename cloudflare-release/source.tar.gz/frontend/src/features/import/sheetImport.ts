// Import from Excel / CSV (owner, 2026-10-22: free for every account): people who already keep a
// sheet of their jobs bring months of work in without typing it again. This file has no React and no
// file reading: it takes a sheet as a grid of cells, finds the header row, guesses what each column
// is, reads Thai and English dates, amounts and statuses, and builds jobs and expenses the same way
// the job and expense forms do. Every row comes back with what the person should check.

import type { Expense, Job, StatusOption } from '../../../../shared/types';
import { calculatePayDate } from '../../../../shared/calendar';
import { roundMoney, whtAmountFor } from '../../../../shared/wht';

// ---------------------------------------------------------------------------------------------
// Input

export interface SheetCell {
  /** The cell value as the file stores it. */
  raw: string | number | boolean | null;
  /** What the person sees in the cell. */
  text: string;
  /** YYYY-MM-DD when the cell is a real date in the file (date-formatted). */
  date?: string;
}

export interface SheetGrid {
  name: string;
  rows: SheetCell[][];
}

// One import saves at most this many rows, so the save stays within the server's request size.
export const MAX_IMPORT_ROWS = 2000;

// ---------------------------------------------------------------------------------------------
// Fields

export type Field =
  | 'name' | 'client' | 'type' | 'category'
  | 'value' | 'amount' | 'received' | 'pending' | 'income' | 'expense'
  | 'whtRate' | 'whtAmount' | 'status' | 'kind'
  | 'date' | 'postDate' | 'dueDate' | 'paidDate' | 'creditTerm' | 'note';

/** keep: not one of our fields; its text goes into the note with its header so nothing is lost. */
export type ColumnTarget = Field | 'keep' | 'ignore';
export type DataKind = 'jobs' | 'expenses' | 'mixed';

const MONEY_FIELDS: Field[] = ['value', 'amount', 'received', 'pending', 'income', 'expense', 'whtAmount'];
const DATE_FIELDS: Field[] = ['date', 'postDate', 'dueDate', 'paidDate'];
const TEXT_FIELDS: Field[] = ['name', 'client', 'type', 'category', 'note'];

/** Header words for each field, Thai and English, written as they are compared (see normalize). */
const HEADER_WORDS: Record<Field, string[]> = {
  name: ['ชื่องาน', 'งาน', 'ชื่อโปรเจกต์', 'โปรเจกต์', 'โปรเจค', 'ชื่อโปรเจค', 'โครงการ', 'ชื่อโครงการ', 'รายการ', 'ชื่อรายการ', 'รายละเอียด', 'รายละเอียดงาน', 'ดีล', 'ชื่อดีล', 'งานที่ทำ', 'job', 'jobname', 'project', 'projectname', 'task', 'item', 'description', 'details', 'deal', 'title', 'work'],
  client: ['ลูกค้า', 'ชื่อลูกค้า', 'แบรนด์', 'บริษัท', 'ผู้ว่าจ้าง', 'ผู้จ้าง', 'เอเจนซี่', 'เอเจนซี', 'ผู้จ่าย', 'ผู้จ่ายเงิน', 'ลูกค้าผู้จ่าย', 'client', 'clientname', 'customer', 'brand', 'company', 'agency', 'payer', 'buyer'],
  type: ['ประเภทงาน', 'ประเภท', 'ชนิดงาน', 'หมวดงาน', 'แพลตฟอร์ม', 'type', 'jobtype', 'worktype', 'platform', 'service'],
  category: ['หมวดหมู่', 'หมวด', 'ประเภทรายจ่าย', 'หมวดค่าใช้จ่าย', 'หมวดรายจ่าย', 'category', 'expensecategory', 'expensetype'],
  value: ['มูลค่างาน', 'มูลค่า', 'มูลค่ารวม', 'ราคา', 'ราคางาน', 'ค่าจ้าง', 'ค่างาน', 'ค่าตัว', 'เรท', 'ยอดก่อนหัก', 'ยอดก่อนภาษี', 'รายได้', 'value', 'price', 'fee', 'rate', 'gross', 'budget', 'revenue', 'contractvalue', 'jobvalue'],
  amount: ['จำนวนเงิน', 'ยอดเงิน', 'ยอด', 'ยอดรวม', 'เงิน', 'amount', 'total', 'sum'],
  received: ['รับแล้ว', 'ได้รับแล้ว', 'จ่ายแล้ว', 'ชำระแล้ว', 'ยอดที่จ่าย', 'ยอดชำระ', 'ยอดที่ได้รับ', 'ยอดได้รับแล้ว', 'ยอดรับ', 'รับจริง', 'เงินที่ได้รับ', 'ได้รับ', 'ยอดที่รับ', 'มัดจำ', 'received', 'amountreceived', 'paidamount', 'amountpaid', 'deposit', 'collected'],
  pending: ['ค้างรับ', 'คงค้าง', 'ค้างจ่าย', 'ค้างชำระ', 'ยอดค้าง', 'ยอดค้างชำระ', 'ยอดค้างรับ', 'ยังไม่ได้รับ', 'รอรับ', 'คงเหลือ', 'ยอดคงเหลือ', 'outstanding', 'balance', 'pending', 'remaining', 'unpaid', 'balancedue'],
  income: ['รายรับ', 'เงินเข้า', 'รับเงิน', 'income', 'moneyin', 'inflow'],
  expense: ['รายจ่าย', 'เงินออก', 'ค่าใช้จ่าย', 'จ่ายเงิน', 'expense', 'expenses', 'moneyout', 'debit', 'outflow', 'spent', 'cost'],
  whtRate: ['หักณที่จ่าย%', '%หักณที่จ่าย', 'อัตราหักณที่จ่าย', 'อัตราหัก', 'หัก%', '%หัก', 'ภาษี%', 'wht%', 'whtrate', 'withholding%', 'withholdingrate', 'taxrate'],
  whtAmount: ['ยอดหักณที่จ่าย', 'จำนวนภาษีหักณที่จ่าย', 'ภาษีหักณที่จ่าย', 'หักณที่จ่าย', 'ภาษีที่ถูกหัก', 'หักภาษี', 'wht', 'whtamount', 'withholding', 'withholdingtax', 'withholdingamount', 'taxwithheld'],
  status: ['สถานะ', 'สถานะการจ่าย', 'สถานะการชำระ', 'สถานะการรับเงิน', 'สถานะเงิน', 'สถานะงาน', 'การชำระ', 'การจ่าย', 'จ่ายแล้ว', 'จ่ายยัง', 'ได้เงินยัง', 'ชำระแล้ว', 'โอนแล้ว', 'status', 'paymentstatus', 'paid', 'state'],
  kind: ['ประเภทรายการ', 'รับจ่าย', 'รายรับรายจ่าย', 'เข้าออก', 'inout', 'direction', 'kind', 'transactiontype'],
  date: ['วันที่', 'วัน', 'วันที่ทำรายการ', 'วันเดือนปี', 'date', 'day', 'transactiondate'],
  postDate: ['วันส่งงาน', 'วันที่ส่งงาน', 'ส่งงาน', 'วันลงงาน', 'วันที่ลงงาน', 'วันโพสต์', 'วันเผยแพร่', 'วันดีล', 'วันจบงาน', 'วันที่ให้บริการ', 'วันให้บริการ', 'deliverydate', 'delivered', 'postdate', 'publishdate', 'livedate', 'completeddate', 'enddate', 'servicedate'],
  dueDate: ['กำหนดชำระ', 'วันครบกำหนด', 'ครบกำหนด', 'กำหนดรับเงิน', 'วันครบกำหนดชำระ', 'วันนัดจ่าย', 'กำหนดจ่าย', 'วันที่ต้องได้รับ', 'duedate', 'due', 'paymentdue', 'dueon'],
  paidDate: ['วันที่รับเงิน', 'วันรับเงิน', 'วันที่ได้รับเงิน', 'วันที่โอน', 'วันโอน', 'วันที่จ่าย', 'วันจ่าย', 'วันที่ชำระ', 'วันรับเงินจริง', 'วันที่รับเงินจริง', 'paiddate', 'paymentdate', 'datepaid', 'receiveddate', 'paidon', 'datereceived'],
  creditTerm: ['เครดิต', 'เครดิตเทอม', 'เทอม', 'ระยะเวลาเครดิต', 'creditterm', 'credit', 'terms', 'paymentterms', 'paymentterm'],
  note: ['หมายเหตุ', 'โน้ต', 'บันทึก', 'รายละเอียดเพิ่มเติม', 'note', 'notes', 'remark', 'remarks', 'comment', 'comments', 'memo'],
};

const UNIT_WORDS = /(บาท|thb|baht|฿)$/;

/** Header text as it is compared: lower case, no spaces or punctuation, no unit at the end. */
export function normalizeHeader(text: string): string {
  return text.normalize('NFC').toLowerCase().replace(/[\s()[\]{}.:/\\\-_,'"#*?!|]+/g, '').replace(UNIT_WORDS, '');
}

const HEADER_INDEX = Object.entries(HEADER_WORDS).map(([field, words]) => ({ field: field as Field, words: words.map(normalizeHeader) }));

/** How well a header names a field, 0..1. */
export function headerScore(header: string, field: Field): number {
  const h = normalizeHeader(header);
  if (!h) return 0;
  let best = 0;
  for (const word of HEADER_INDEX.find(entry => entry.field === field)!.words) {
    if (h === word) return 1;
    if (word.length >= 3 && h.includes(word)) best = Math.max(best, 0.6 + 0.35 * (word.length / h.length));
    else if (h.length >= 3 && word.includes(h)) best = Math.max(best, 0.5 + 0.3 * (h.length / word.length));
  }
  return Math.min(best, 0.95);
}

// ---------------------------------------------------------------------------------------------
// Reading values

const THAI_MONTHS = [
  ['มกราคม', 'มค', 'ม.ค'], ['กุมภาพันธ์', 'กพ', 'ก.พ'], ['มีนาคม', 'มีค', 'มี.ค'], ['เมษายน', 'เมย', 'เม.ย'],
  ['พฤษภาคม', 'พค', 'พ.ค'], ['มิถุนายน', 'มิย', 'มิ.ย'], ['กรกฎาคม', 'กค', 'ก.ค'], ['สิงหาคม', 'สค', 'ส.ค'],
  ['กันยายน', 'กย', 'ก.ย'], ['ตุลาคม', 'ตค', 'ต.ค'], ['พฤศจิกายน', 'พย', 'พ.ย'], ['ธันวาคม', 'ธค', 'ธ.ค'],
];
const EN_MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

const pad = (n: number) => String(n).padStart(2, '0');
const validDate = (y: number, m: number, d: number) => {
  if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1) return null;
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return d > last ? null : `${y}-${pad(m)}-${pad(d)}`;
};

/** A year as written: Buddhist Era (2567, or 67 for 43..99) becomes Gregorian; 24 is 2024. */
export function fullYear(year: number): number {
  if (year >= 2400) return year - 543;
  if (year >= 1000) return year;
  if (year >= 43) return 2500 + year - 543;
  return 2000 + year;
}

/** Excel's day number (days since 1899-12-30) as YYYY-MM-DD, for 2000..2100. */
export function excelSerialDate(serial: number): string | null {
  if (!Number.isFinite(serial) || serial < 36526 || serial > 73051) return null;
  return new Date(Date.UTC(1899, 11, 30) + Math.floor(serial) * 86400000).toISOString().slice(0, 10);
}

function monthFromWord(word: string): number | null {
  const w = word.toLowerCase().replace(/\.$/, '');
  const th = THAI_MONTHS.findIndex(names => names.some(name => w === name || w === name.replace(/\./g, '')));
  if (th >= 0) return th + 1;
  const en = EN_MONTHS.findIndex(name => w.startsWith(name) && w.length <= 9);
  return en >= 0 ? en + 1 : null;
}

export type DayOrder = 'dmy' | 'mdy';

/** Reads a date written as text. Day first unless the column shows month first. */
export function parseDateText(input: string, order: DayOrder = 'dmy'): string | null {
  const text = input.trim().replace(/\s+/g, ' ');
  if (!text) return null;
  let m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T].*)?$/.exec(text);
  if (m) return validDate(fullYear(+m[1]), +m[2], +m[3]);
  m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(?: .*)?$/.exec(text);
  if (m) {
    const [a, b, y] = [+m[1], +m[2], fullYear(+m[3])];
    return order === 'mdy' ? validDate(y, a, b) : validDate(y, b, a);
  }
  // 15 ต.ค. 67 / 15 ตุลาคม 2567 / 15 Oct 2024 / 15-Oct-24
  m = /^(\d{1,2})[ \-]*([ก-๙a-zA-Z.]+)[ \-,]*(\d{2,4})$/.exec(text);
  if (m) { const month = monthFromWord(m[2]); return month ? validDate(fullYear(+m[3]), month, +m[1]) : null; }
  // Oct 15, 2024
  m = /^([a-zA-Z.]+) (\d{1,2}),? (\d{2,4})$/.exec(text);
  if (m) { const month = monthFromWord(m[1]); return month ? validDate(fullYear(+m[3]), month, +m[2]) : null; }
  return null;
}

/** A month named in a sheet tab or heading ("ต.ค. 67", "ตุลาคม 2567", "Oct 2024", "10-2024"): YYYY-MM. */
export function monthFromName(name: string, fallbackYear?: number): string | null {
  const text = name.trim();
  let m = /(\d{1,2})[-/.](\d{4})/.exec(text);
  if (m && +m[1] >= 1 && +m[1] <= 12) return `${fullYear(+m[2])}-${pad(+m[1])}`;
  m = /(\d{4})[-/.](\d{1,2})(?!\d)/.exec(text);
  if (m && +m[2] >= 1 && +m[2] <= 12) return `${fullYear(+m[1])}-${pad(+m[2])}`;
  for (const token of text.split(/[\s_\-]+/)) {
    const month = monthFromWord(token);
    if (!month) continue;
    const year = /(\d{4}|\d{2})(?!\d)/.exec(text.replace(token, ''));
    const y = year ? fullYear(+year[1]) : fallbackYear;
    return y ? `${y}-${pad(month)}` : null;
  }
  return null;
}

/** Reads an amount: 12000, "฿12,000", "12,000.-", "(500)", "12k", "1.2 หมื่น". */
export function parseMoney(cell: SheetCell | undefined): number | null {
  if (!cell) return null;
  if (typeof cell.raw === 'number') return Number.isFinite(cell.raw) ? cell.raw : null;
  let text = String(cell.raw ?? cell.text ?? '').trim();
  if (!text) return null;
  let sign = 1;
  if (/^\(.*\)$/.test(text)) { sign = -1; text = text.slice(1, -1); }
  text = text.replace(/[฿,\s]|บาท|thb|baht/gi, '').replace(/\.-$/, '').replace(/-$/, '');
  if (text.startsWith('-')) { sign *= -1; text = text.slice(1); }
  if (text.startsWith('+')) text = text.slice(1);
  const unit = /^(\d+(?:\.\d+)?)(k|m|พัน|หมื่น|แสน|ล้าน)$/i.exec(text);
  if (unit) {
    const times: Record<string, number> = { k: 1e3, m: 1e6, พัน: 1e3, หมื่น: 1e4, แสน: 1e5, ล้าน: 1e6 };
    return sign * roundMoney(+unit[1] * times[unit[2].toLowerCase()]);
  }
  if (!/^\d+(\.\d+)?$/.test(text)) return null;
  return sign * Number(text);
}

/** A WHT rate: "3%", 3, 0.03 -> 3. */
export function parseRate(cell: SheetCell | undefined): number | null {
  if (!cell) return null;
  const percent = /%/.test(cell.text);
  const value = parseMoney({ ...cell, raw: typeof cell.raw === 'string' ? cell.raw.replace('%', '') : cell.raw, text: cell.text.replace('%', '') });
  if (value === null || value < 0) return null;
  const rate = !percent && value > 0 && value < 1 ? value * 100 : value;
  return rate <= 100 ? Math.round(rate * 100) / 100 : null;
}

/** Credit term in days: 30, "30 วัน", "Net 30", "1 เดือน", "เงินสด" -> 0. */
export function parseCreditTerm(cell: SheetCell | undefined): number | null {
  if (!cell) return null;
  if (typeof cell.raw === 'number') return cell.raw >= 0 && cell.raw <= 3650 ? Math.round(cell.raw) : null;
  const text = cell.text.trim().toLowerCase();
  if (!text) return null;
  if (/เงินสด|cash|cod|ทันที|immediate/.test(text)) return 0;
  const months = /(\d+)\s*(เดือน|month)/.exec(text);
  if (months) return +months[1] * 30;
  const days = /(\d+)/.exec(text);
  return days && +days[1] <= 3650 ? +days[1] : null;
}

export type PaymentWord = 'paid' | 'partial' | 'unpaid';
export interface StatusReading { payment?: PaymentWord; delivered?: boolean }

const PAID_WORDS = /(^|[^ม])จ่ายแล้ว|ได้รับแล้ว|ได้รับเงินแล้ว|รับแล้ว|รับเงินแล้ว|รับครบ|ได้เงินแล้ว|ได้แล้ว|โอนแล้ว|ชำระแล้ว|เคลียร์แล้ว|ปิดยอด|^paid|fullypaid|received|settled|^done$|^yes$|^y$|^true$|^✓|^✔|^☑/
const PARTIAL_WORDS = /มัดจำ|บางส่วน|แบ่งจ่าย|partial|deposit/;
const UNPAID_WORDS = /ยังไม่|ค้าง|รอโอน|รอจ่าย|รอรับ|รอชำระ|^รอ|unpaid|notpaid|pending|outstanding|overdue|^no$|^n$|^false$|^✗|^✕|^x$/;
const DELIVERED_WORDS = /ส่งงานแล้ว|ส่งแล้ว|เสร็จแล้ว|ลงแล้ว|โพสต์แล้ว|delivered|posted|completed|^done$/;
const WORKING_WORDS = /กำลังทำ|ยังไม่ส่ง|ยังไม่เสร็จ|inprogress|working|ongoing|todo/;

/** What a status cell says about payment and delivery. TRUE/FALSE checkboxes count as paid/unpaid. */
export function parseStatus(cell: SheetCell | undefined): StatusReading {
  if (!cell) return {};
  if (typeof cell.raw === 'boolean') return { payment: cell.raw ? 'paid' : 'unpaid' };
  const text = cell.text.toLowerCase().replace(/\s+/g, '');
  if (!text) return {};
  const reading: StatusReading = {};
  if (PARTIAL_WORDS.test(text)) reading.payment = 'partial';
  else if (UNPAID_WORDS.test(text)) reading.payment = 'unpaid';
  else if (PAID_WORDS.test(text)) reading.payment = 'paid';
  if (DELIVERED_WORDS.test(text)) reading.delivered = true;
  else if (WORKING_WORDS.test(text)) reading.delivered = false;
  return reading;
}

type RowKind = 'income' | 'expense';
const INCOME_WORDS = /^(รายรับ|รับ|รายได้|เงินเข้า|income|in|revenue|credit)$/;
const EXPENSE_WORDS = /^(รายจ่าย|จ่าย|ค่าใช้จ่าย|เงินออก|expense|expenses|out|cost|debit)$/;

export function parseKind(cell: SheetCell | undefined): RowKind | null {
  const text = (cell?.text || '').toLowerCase().replace(/\s+/g, '');
  if (!text) return null;
  if (INCOME_WORDS.test(text)) return 'income';
  if (EXPENSE_WORDS.test(text)) return 'expense';
  return null;
}

// ---------------------------------------------------------------------------------------------
// Looking at a sheet

const TOTAL_EXACT = new Set(['รวม', 'ยอดรวม', 'รวมทั้งหมด', 'รวมทั้งสิ้น', 'รวมยอด', 'รวมเงิน', 'รวมรายรับ', 'รวมรายจ่าย', 'สรุป', 'สรุปยอด', 'total', 'grandtotal', 'subtotal', 'sum', 'totals']);
/** A total row: "รวม" alone, or a short "รวม…" line with no date (a job named "รวมคลิป…" has one). */
const isTotalText = (text: string, rowHasDate: boolean) => TOTAL_EXACT.has(text) || (/^(รวม|total|subtotal|สรุป)/.test(text) && !rowHasDate && text.length <= 24);

const cellAt = (row: SheetCell[] | undefined, col: number): SheetCell | undefined => row?.[col];
/** A "รวม" / "Total" row: left out of the import, and of the samples used to guess columns. */
function isTotalRow(row: SheetCell[], order: DayOrder): boolean {
  const firstText = row.map(cell => cell?.text?.trim() || '').find(text => text && !/^[\d.,\s฿-]+$/.test(text)) || '';
  const hasDate = row.some(cell => cell && (cell.date || (typeof cell.raw === 'string' && parseDateText(cell.raw, order))));
  return isTotalText(normalizeHeader(firstText), hasDate);
}
const isEmpty = (cell: SheetCell | undefined) => !cell || (cell.raw === null || cell.raw === '') && !cell.text.trim();
const isNumberLike = (cell: SheetCell) => typeof cell.raw === 'number' || parseMoney(cell) !== null;
const isDateLike = (cell: SheetCell, order: DayOrder) => Boolean(cell.date) || (typeof cell.raw === 'string' && parseDateText(cell.raw, order) !== null);

export interface ColumnGuess {
  index: number;
  header: string;
  target: ColumnTarget;
  /** 0..1: how sure the guess is. */
  confidence: number;
  /** A few values from the column, as shown in the file. */
  samples: string[];
}

export interface SheetAnalysis {
  name: string;
  /** Zero-based row of the headers, or null when the sheet has no header row. */
  headerRow: number | null;
  columns: ColumnGuess[];
  kind: DataKind;
  dayOrder: DayOrder;
  /** Month taken from the sheet name, used for rows without a date. */
  sheetMonth: string | null;
  /** Rows of data under the header (zero-based), without blank rows. */
  dataRows: number[];
  /** True for a summary laid out with months across the columns: no rows to import. */
  monthsAcross: boolean;
}

interface ColumnProfile { dates: number; numbers: number; negatives: number; small: number; percents: number; statuses: number; kinds: number; texts: number; total: number; distinct: number; avgLength: number }

function profileColumn(rows: SheetCell[][], col: number, order: DayOrder): ColumnProfile {
  const p: ColumnProfile = { dates: 0, numbers: 0, negatives: 0, small: 0, percents: 0, statuses: 0, kinds: 0, texts: 0, total: 0, distinct: 0, avgLength: 0 };
  const seen = new Set<string>();
  let length = 0;
  for (const row of rows.slice(0, 80)) {
    const cell = cellAt(row, col);
    if (isEmpty(cell)) continue;
    p.total++;
    seen.add(cell!.text);
    length += cell!.text.length;
    if (isDateLike(cell!, order)) { p.dates++; continue; }
    if (/%/.test(cell!.text)) p.percents++;
    if (isNumberLike(cell!)) {
      p.numbers++;
      const n = parseMoney(cell) ?? 0;
      if (n < 0) p.negatives++;
      if (n >= 0 && n <= 15) p.small++;
      continue;
    }
    if (typeof cell!.raw === 'boolean' || parseStatus(cell).payment || parseStatus(cell).delivered !== undefined) p.statuses++;
    if (parseKind(cell)) p.kinds++;
    p.texts++;
  }
  p.distinct = seen.size;
  p.avgLength = p.total ? length / p.total : 0;
  return p;
}

/** How well a column's values fit a field, 0..1. */
function valueFit(field: Field, p: ColumnProfile): number {
  if (!p.total) return 0.3;
  const share = (n: number) => n / p.total;
  if (DATE_FIELDS.includes(field)) return share(p.dates) >= 0.6 ? 1 : share(p.dates) >= 0.3 ? 0.6 : 0.15;
  if (field === 'whtRate') return share(p.numbers + p.percents) >= 0.6 && (share(p.small) >= 0.6 || share(p.percents) >= 0.5) ? 1 : 0.2;
  if (field === 'creditTerm') return share(p.numbers) + share(p.texts) * 0.5 >= 0.6 ? 0.9 : 0.3;
  if (MONEY_FIELDS.includes(field)) return share(p.numbers) >= 0.6 ? 1 : share(p.numbers) >= 0.3 ? 0.55 : 0.15;
  if (field === 'status') return share(p.statuses) >= 0.5 ? 1 : 0.3;
  if (field === 'kind') return share(p.kinds) >= 0.6 ? 1 : 0.1;
  if (TEXT_FIELDS.includes(field)) return share(p.texts) >= 0.5 ? 1 : 0.25;
  return 0.5;
}

function chooseDayOrder(rows: SheetCell[][]): DayOrder {
  let dayFirst = 0, monthFirst = 0;
  for (const row of rows.slice(0, 200)) for (const cell of row) {
    if (!cell || typeof cell.raw !== 'string') continue;
    const m = /^(\d{1,2})[-/.](\d{1,2})[-/.]\d{2,4}/.exec(cell.raw.trim());
    if (!m) continue;
    if (+m[1] > 12) dayFirst++;
    if (+m[2] > 12) monthFirst++;
  }
  return monthFirst > dayFirst ? 'mdy' : 'dmy';
}

function findHeaderRow(rows: SheetCell[][]): number | null {
  let best: { row: number; score: number } | null = null;
  for (let r = 0; r < Math.min(rows.length, 30); r++) {
    const cells = rows[r] || [];
    const filled = cells.filter(cell => !isEmpty(cell));
    if (filled.length < 2) continue;
    const texts = filled.filter(cell => typeof cell.raw === 'string' && !isNumberLike(cell) && !cell.date);
    const matched = texts.filter(cell => HEADER_INDEX.some(entry => headerScore(cell.text, entry.field) >= 0.7)).length;
    if (!matched && texts.length < 2) continue;
    const next = rows.slice(r + 1, r + 6).find(row => row && row.some(cell => !isEmpty(cell)));
    const dataLike = next ? next.some(cell => cell && (isNumberLike(cell) || cell.date)) : false;
    const score = matched * 3 + texts.length * 0.5 + (dataLike ? 2 : 0) - r * 0.05;
    if (matched >= 1 && (!best || score > best.score)) best = { row: r, score };
  }
  return best ? best.row : null;
}

function guessKind(name: string, targets: ColumnTarget[], dataRows: SheetCell[][], columns: ColumnGuess[]): DataKind {
  const has = (field: Field) => targets.includes(field);
  if (has('income') && has('expense')) return 'mixed';
  const kindCol = columns.find(c => c.target === 'kind');
  if (kindCol) {
    const kinds = new Set(dataRows.map(row => parseKind(cellAt(row, kindCol.index))).filter(Boolean));
    if (kinds.size === 2) return 'mixed';
    if (kinds.has('expense')) return 'expenses';
  }
  const sheet = normalizeHeader(name);
  if (/รายจ่าย|ค่าใช้จ่าย|expense|cost|spend/.test(sheet)) return 'expenses';
  if (has('expense') && !has('client') && !has('received') && !has('status')) return 'expenses';
  if (has('category') && !has('client') && !has('received') && !has('pending') && !has('status') && !has('type')) return 'expenses';
  return 'jobs';
}

/** Reads a sheet and guesses where the header is, what each column is and what the rows are. */
export function analyzeSheet(grid: SheetGrid, override: { headerRow?: number | null } = {}): SheetAnalysis {
  const rows = grid.rows;
  const dayOrder = chooseDayOrder(rows);
  // The person can point at another header row when the guess is wrong.
  const headerRow = 'headerRow' in override ? override.headerRow ?? null : findHeaderRow(rows);
  const start = headerRow === null ? 0 : headerRow + 1;
  const headerCells = headerRow === null ? [] : rows[headerRow] || [];
  const width = Math.max(0, ...rows.slice(0, 200).map(row => row?.length || 0));
  const body = rows.slice(start);
  const dataRows: number[] = [];
  body.forEach((row, i) => { if (row && row.some(cell => !isEmpty(cell))) dataRows.push(start + i); });
  const dataCells = dataRows.map(r => rows[r]).filter(row => !isTotalRow(row, dayOrder));

  // Score every column against every field, by header and by values, then assign best-first.
  const candidates: { col: number; field: Field; score: number }[] = [];
  const profiles: ColumnProfile[] = [];
  for (let col = 0; col < width; col++) {
    const profile = profileColumn(dataCells, col, dayOrder);
    profiles[col] = profile;
    const header = headerCells[col]?.text || '';
    for (const { field } of HEADER_INDEX) {
      const byHeader = headerScore(header, field);
      const fit = valueFit(field, profile);
      const score = byHeader > 0 ? byHeader * (0.45 + 0.55 * fit) : 0;
      if (score > 0.3) candidates.push({ col, field, score });
    }
  }
  candidates.sort((a, b) => b.score - a.score);
  const targetOf = new Map<number, { field: Field; score: number }>();
  const used = new Set<Field>();
  for (const c of candidates) {
    if (targetOf.has(c.col) || used.has(c.field)) continue;
    targetOf.set(c.col, { field: c.field, score: c.score });
    used.add(c.field);
  }
  // A column of income/expense words is the kind of each row, whatever its header says ("Type").
  for (let col = 0; col < width; col++) {
    const p = profiles[col];
    if (p.total && p.kinds / p.total >= 0.8 && targetOf.get(col)?.field !== 'kind' && !used.has('kind')) {
      const before = targetOf.get(col);
      if (before) used.delete(before.field);
      targetOf.set(col, { field: 'kind', score: 0.9 });
      used.add('kind');
    }
  }
  // A withholding column holds rates (3%, 0.03) or amounts (300): follow the values, not the header.
  for (const [col, guess] of targetOf) {
    const p = profiles[col], share = (n: number) => (p.total ? n / p.total : 0);
    const looksLikeRates = share(p.percents) >= 0.5 || (share(p.numbers) >= 0.6 && share(p.small) >= 0.8);
    if (guess.field === 'whtAmount' && looksLikeRates && !used.has('whtRate')) { targetOf.set(col, { field: 'whtRate', score: guess.score }); used.delete('whtAmount'); used.add('whtRate'); }
    else if (guess.field === 'whtRate' && !looksLikeRates && share(p.numbers) >= 0.6 && !used.has('whtAmount')) { targetOf.set(col, { field: 'whtAmount', score: guess.score }); used.delete('whtRate'); used.add('whtAmount'); }
  }
  // Columns no header named: guess from the values alone (sheets without headers, or odd headers).
  const free = (field: Field) => !used.has(field);
  for (let col = 0; col < width; col++) {
    if (targetOf.has(col) || !profiles[col].total) continue;
    const p = profiles[col], share = (n: number) => n / p.total;
    let field: Field | null = null;
    if (share(p.dates) >= 0.8) field = free('date') ? 'date' : free('paidDate') ? 'paidDate' : null;
    else if (share(p.numbers) >= 0.8 && share(p.negatives) < 0.5) field = free('amount') && free('value') ? 'amount' : null;
    else if (share(p.statuses) >= 0.7) field = free('status') ? 'status' : null;
    else if (share(p.texts) >= 0.8 && p.avgLength >= 3) field = free('name') ? 'name' : free('client') && p.distinct < p.total ? 'client' : null;
    if (field) { targetOf.set(col, { field, score: 0.45 }); used.add(field); }
  }

  const columns: ColumnGuess[] = [];
  for (let col = 0; col < width; col++) {
    const header = headerCells[col]?.text?.trim() || '';
    const guess = targetOf.get(col);
    if (!header && !profiles[col].total) continue;
    columns.push({
      index: col,
      header,
      target: guess ? guess.field : 'keep',
      confidence: guess ? Math.round(guess.score * 100) / 100 : 0.4,
      samples: dataCells.map(row => cellAt(row, col)?.text?.trim() || '').filter(Boolean).slice(0, 3),
    });
  }

  // A summary with month names across the header (ม.ค. ก.พ. มี.ค. ...) has totals, not rows.
  const monthHeaders = headerCells.filter(cell => cell && monthFromWord(cell.text.trim().split(/\s+/)[0] || '')).length;
  const monthsAcross = monthHeaders >= 4;
  const kind = guessKind(grid.name, columns.map(c => c.target), dataCells, columns);
  return { name: grid.name, headerRow, columns, kind, dayOrder, sheetMonth: monthFromName(grid.name), dataRows, monthsAcross };
}

// ---------------------------------------------------------------------------------------------
// Building jobs and expenses

/** Why a row needs a look. The screen shows each in the app language. */
export type IssueCode =
  | 'noName' | 'noAmount' | 'negative' | 'noDate' | 'dateFromSheet' | 'dateUnreadable' | 'amountUnreadable'
  | 'valueFromParts' | 'paidWithoutDate' | 'statusConflict' | 'partialNoAmount' | 'duplicate' | 'duplicateInFile' | 'total' | 'repeatedHeader' | 'blank';

export interface ImportOptions {
  /** True when the sheet's amounts are already after withholding tax. */
  amountsAreNet: boolean;
  /** Today, YYYY-MM-DD (passed in so tests are stable). */
  today: string;
}

export interface ImportContext {
  statuses: StatusOption[];
  jobTypes: string[];
  existingJobs: Job[];
  existingExpenses: Expense[];
}

export type ImportedJob = Omit<Job, 'id'>;
export type ImportedExpense = Omit<Expense, 'id'>;

export interface ImportRow {
  key: string;
  sheet: string;
  /** Row number as Excel shows it (1-based). */
  rowNumber: number;
  kind: 'job' | 'expense' | 'skip';
  /** ready: import as is; check: imported unless the person unticks it; skip: left out unless ticked. */
  state: 'ready' | 'check' | 'skip';
  issues: IssueCode[];
  job?: ImportedJob;
  expense?: ImportedExpense;
}

export interface ImportPlan {
  rows: ImportRow[];
  /** Job types the import adds to the account's list. */
  newJobTypes: string[];
  /** Totals the file states in its own "รวม" rows, per field, to compare with the import. */
  fileTotals: Partial<Record<'value' | 'received' | 'pending' | 'amount' | 'expense' | 'income', number>>;
}

const statusIdFor = (payment: PaymentWord, statuses: StatusOption[]) => {
  const behavior = payment === 'paid' ? 'done' : payment === 'partial' ? 'partial' : 'pending';
  const builtIn = statuses.find(s => s.id === behavior && s.behavior === behavior);
  return builtIn?.id ?? statuses.find(s => s.behavior === behavior && s.id !== 'installment')?.id ?? behavior;
};

const PRESET_RATES = [1, 1.5, 2, 3, 5, 10, 15];
const snapRate = (rate: number) => PRESET_RATES.find(preset => Math.abs(preset - rate) <= 0.05) ?? Math.round(rate * 100) / 100;

const keyOf = (...parts: (string | number | null | undefined)[]) => parts.map(p => String(p ?? '').toLowerCase().replace(/\s+/g, '')).join('|');
export const jobDuplicateKey = (job: { name: string; client?: string; value: number; postDate?: string | null; payDate?: string | null }) =>
  keyOf(job.name, job.client, Math.round(job.value), job.postDate || job.payDate);
export const expenseDuplicateKey = (expense: { name: string; amount: number; date: string }) => keyOf(expense.name, Math.round(expense.amount * 100), expense.date);

/** Expense categories the app offers, and words in a sheet that mean each. Unknown ones stay as typed. */
const CATEGORY_WORDS: [string, RegExp][] = [
  ['ค่าอุปกรณ์/ซอฟต์แวร์', /อุปกรณ์|ซอฟต์แวร์|โปรแกรม|software|equipment|hardware|adobe|canva|subscription|app/i],
  ['ค่าโฆษณา/ยิงแอด', /โฆษณา|ยิงแอด|แอด|ads?\b|marketing|boost|facebookads/i],
  ['ค่าเดินทาง/น้ำมัน', /เดินทาง|น้ำมัน|แท็กซี่|รถ|grab|bolt|taxi|travel|fuel|bts|mrt|ทางด่วน|parking|จอดรถ/i],
  ['อาหาร/รับรองลูกค้า', /อาหาร|รับรอง|กาแฟ|food|meal|lunch|dinner|coffee/i],
  ['จ้างงานต่อ (Outsource)', /จ้าง|outsource|freelance|ฟรีแลนซ์|ผู้ช่วย|assistant/i],
  ['ภาษี/ธรรมเนียม', /ภาษี|ธรรมเนียม|ค่าธรรมเนียม|tax|fee|bank/i],
  ['ค่าบริการ/สาธารณูปโภค', /ค่าน้ำ|ค่าไฟ|อินเทอร์เน็ต|เน็ต|โทรศัพท์|internet|utility|utilities|electric|water|phone|ค่าเช่า|rent/i],
];
export function mapCategory(text: string, known: string[]): string {
  const value = text.trim();
  if (!value) return 'อื่นๆ';
  const exact = known.find(k => k.toLowerCase() === value.toLowerCase());
  if (exact) return exact;
  return CATEGORY_WORDS.find(([, words]) => words.test(value))?.[0] ?? value;
}

export const EXPENSE_CATEGORY_LIST = [...CATEGORY_WORDS.map(([name]) => name), 'อื่นๆ'];

interface Cells { get: (field: Field) => SheetCell | undefined; text: (field: Field) => string; notes: string[] }

function rowCells(row: SheetCell[], columns: ColumnGuess[]): Cells {
  const byField = new Map<Field, SheetCell>();
  const notes: string[] = [];
  for (const column of columns) {
    const cell = cellAt(row, column.index);
    if (column.target === 'ignore' || isEmpty(cell)) continue;
    if (column.target === 'keep') { notes.push(column.header ? `${column.header}: ${cell!.text.trim()}` : cell!.text.trim()); continue; }
    if (column.target === 'note' && byField.has('note')) { notes.push(cell!.text.trim()); continue; }
    if (!byField.has(column.target)) byField.set(column.target, cell!);
  }
  return { get: field => byField.get(field), text: field => (byField.get(field)?.text || '').trim(), notes };
}

function readDate(cell: SheetCell | undefined, order: DayOrder): { date: string | null; unreadable: boolean } {
  if (isEmpty(cell)) return { date: null, unreadable: false };
  if (cell!.date) return { date: cell!.date, unreadable: false };
  if (typeof cell!.raw === 'number') { const date = excelSerialDate(cell!.raw); return { date, unreadable: !date }; }
  const date = parseDateText(cell!.text, order);
  return { date, unreadable: !date };
}

/**
 * Turns the analysed sheets into jobs and expenses for the review table. Nothing is saved here.
 */
export function buildImportPlan(sheets: { grid: SheetGrid; analysis: SheetAnalysis }[], options: ImportOptions, context: ImportContext): ImportPlan {
  const rows: ImportRow[] = [];
  const newJobTypes: string[] = [];
  const fileTotals: ImportPlan['fileTotals'] = {};
  const existingJobKeys = new Set(context.existingJobs.map(jobDuplicateKey));
  const existingExpenseKeys = new Set(context.existingExpenses.map(expenseDuplicateKey));
  const fileKeys = new Set<string>();
  const knownTypes = new Map(context.jobTypes.map(type => [type.toLowerCase(), type]));

  for (const { grid, analysis } of sheets) {
    if (analysis.monthsAcross) continue;
    const headerTexts = analysis.headerRow === null ? [] : (grid.rows[analysis.headerRow] || []).map(c => normalizeHeader(c?.text || ''));
    for (const r of analysis.dataRows) {
      if (rows.length >= MAX_IMPORT_ROWS) break;
      const row = grid.rows[r] || [];
      const base = { key: `${analysis.name}:${r}`, sheet: analysis.name, rowNumber: r + 1 };
      const c = rowCells(row, analysis.columns);

      // Total rows and repeated headers are left out; a total row's numbers are kept to compare.
      if (isTotalRow(row, analysis.dayOrder)) {
        for (const field of ['value', 'received', 'pending', 'amount', 'expense', 'income'] as const) {
          const n = parseMoney(c.get(field));
          if (n !== null) fileTotals[field] = (fileTotals[field] || 0) + n;
        }
        rows.push({ ...base, kind: 'skip', state: 'skip', issues: ['total'] });
        continue;
      }
      const texts = row.map(cell => normalizeHeader(cell?.text || '')).filter(Boolean);
      if (headerTexts.length && texts.length && texts.filter(t => headerTexts.includes(t)).length >= Math.max(2, texts.length * 0.6)) {
        rows.push({ ...base, kind: 'skip', state: 'skip', issues: ['repeatedHeader'] });
        continue;
      }

      // Which kind of row: the sheet's kind, or per row in a ledger of money in and out.
      let rowKind: 'income' | 'expense' = analysis.kind === 'expenses' ? 'expense' : 'income';
      let ledgerAmount: number | null = null;
      if (analysis.kind === 'mixed') {
        const kind = parseKind(c.get('kind'));
        const income = parseMoney(c.get('income')), expense = parseMoney(c.get('expense'));
        const amount = parseMoney(c.get('amount')) ?? parseMoney(c.get('value'));
        if (kind) { rowKind = kind; ledgerAmount = amount ?? (kind === 'income' ? income : expense); }
        else if (income && !expense) { rowKind = 'income'; ledgerAmount = income; }
        else if (expense && !income) { rowKind = 'expense'; ledgerAmount = expense; }
        else if (amount !== null) { rowKind = amount < 0 ? 'expense' : 'income'; ledgerAmount = amount; }
        if (ledgerAmount !== null) ledgerAmount = Math.abs(ledgerAmount);
      }

      const issues: IssueCode[] = [];
      const order = analysis.dayOrder;
      const date = (field: Field) => { const read = readDate(c.get(field), order); if (read.unreadable) issues.push('dateUnreadable'); return read.date; };
      const money = (field: Field) => { const cell = c.get(field); const n = parseMoney(cell); if (cell && !isEmpty(cell) && n === null) issues.push('amountUnreadable'); return n; };
      const note = [c.text('note'), ...c.notes].filter(Boolean).join(' · ').slice(0, 10000);

      if (rowKind === 'expense') {
        let amount = ledgerAmount ?? money('amount') ?? money('expense') ?? money('value');
        if (amount !== null && amount < 0) { amount = -amount; issues.push('negative'); }
        let when = date('date') ?? date('paidDate') ?? date('postDate');
        if (!when && analysis.sheetMonth) { when = `${analysis.sheetMonth}-01`; issues.push('dateFromSheet'); }
        const name = c.text('name') || c.text('category') || c.text('note');
        if (!name && amount === null) { rows.push({ ...base, kind: 'skip', state: 'skip', issues: ['blank'] }); continue; }
        if (!name) issues.push('noName');
        if (!amount) issues.push('noAmount');
        if (!when) issues.push('noDate');
        const expense: ImportedExpense = {
          name: (name || `#${base.rowNumber}`).slice(0, 500),
          amount: roundMoney(amount || 0),
          category: mapCategory(c.text('category') || c.text('type') || name, EXPENSE_CATEGORY_LIST),
          date: when || '',
          note,
        };
        const key = expenseDuplicateKey(expense);
        if (existingExpenseKeys.has(key)) issues.push('duplicate');
        else if (fileKeys.has(`e:${key}`)) issues.push('duplicateInFile');
        fileKeys.add(`e:${key}`);
        rows.push({ ...base, kind: 'expense', expense, ...stateOf(issues) });
        continue;
      }

      // A job (or money in from a ledger, which is a job that has been paid).
      const name = c.text('name') || c.text('client') || c.text('type');
      let value = ledgerAmount ?? money('value') ?? money('amount') ?? money('income');
      let received = analysis.kind === 'mixed' ? ledgerAmount : money('received');
      const pendingCell = money('pending');
      if (!name && value === null && received === null && pendingCell === null) { rows.push({ ...base, kind: 'skip', state: 'skip', issues: ['blank'] }); continue; }
      if (value !== null && value < 0) { value = -value; issues.push('negative'); }
      if (received !== null && received < 0) { received = -received; issues.push('negative'); }

      let whtRate = parseRate(c.get('whtRate')) ?? 0;
      const whtGiven = money('whtAmount');
      if (value === null && (received !== null || pendingCell !== null)) {
        value = (received || 0) + (pendingCell || 0);
        issues.push('valueFromParts');
      }
      if (!whtRate && whtGiven && value) whtRate = snapRate((whtGiven / value) * 100);
      if (whtRate > 100) whtRate = 0;
      // Amounts already after withholding: the job value is what was billed before it.
      if (options.amountsAreNet && whtRate > 0 && value) value = roundMoney(value / (1 - whtRate / 100));
      const gross = roundMoney(value || 0);
      const whtAmount = whtAmountFor(gross, whtRate);
      const net = roundMoney(gross - whtAmount);

      const status = parseStatus(c.get('status'));
      const paidDate = date('paidDate');
      const dueDate = date('dueDate');
      let postDate = date('postDate') ?? date('date');
      if (!postDate && analysis.sheetMonth && !paidDate) { postDate = `${analysis.sheetMonth}-01`; issues.push('dateFromSheet'); }

      // Payment: from the amounts first, then the status words, then a payment date.
      let payment: PaymentWord = 'unpaid';
      let receivedFinal = 0;
      if (analysis.kind === 'mixed') { payment = 'paid'; receivedFinal = net; }
      else if (received !== null) {
        receivedFinal = Math.min(received, net);
        payment = received >= net && net > 0 ? 'paid' : received > 0 ? 'partial' : 'unpaid';
        if (status.payment && status.payment !== payment && !(status.payment === 'partial' && payment !== 'unpaid')) issues.push('statusConflict');
      } else if (pendingCell !== null) {
        receivedFinal = Math.max(0, net - pendingCell);
        payment = pendingCell <= 0 ? 'paid' : receivedFinal > 0 ? 'partial' : 'unpaid';
      } else if (status.payment === 'paid' || (!status.payment && paidDate)) { payment = 'paid'; receivedFinal = net; }
      else if (status.payment === 'partial') issues.push('partialNoAmount');
      if (payment === 'paid') receivedFinal = net;

      const creditFromCell = parseCreditTerm(c.get('creditTerm'));
      const creditTerm = creditFromCell ?? (postDate && dueDate && dueDate >= postDate
        ? Math.round((Date.parse(dueDate) - Date.parse(postDate)) / 86400000) : 0);
      const paidOn = paidDate ?? (payment === 'paid' && analysis.kind === 'mixed' ? postDate : null) ?? (payment === 'paid' ? (date('date') || null) : null);
      if (payment === 'paid' && !paidOn) issues.push('paidWithoutDate');
      if (!postDate && !paidOn && !dueDate) issues.push('noDate');
      if (!name) issues.push('noName');
      if (!gross) issues.push('noAmount');

      const delivered = status.delivered ?? (payment !== 'unpaid' || Boolean(postDate && postDate <= options.today));
      const typeText = c.text('type') || (analysis.kind === 'jobs' ? c.text('category') : '');
      let type = 'ยังไม่ระบุ';
      if (typeText) {
        const known = knownTypes.get(typeText.toLowerCase());
        type = known ?? typeText.slice(0, 500);
        if (!known) { knownTypes.set(typeText.toLowerCase(), type); newJobTypes.push(type); }
      }
      const pending = Math.max(0, roundMoney(net - receivedFinal));
      const payDate = payment === 'paid' ? paidOn : dueDate ?? calculatePayDate(postDate, creditTerm, false);
      const job: ImportedJob = {
        name: (name || `#${base.rowNumber}`).slice(0, 500),
        type,
        client: c.text('client').slice(0, 10000),
        value: gross,
        received: roundMoney(receivedFinal),
        pending,
        status: statusIdFor(payment, context.statuses),
        paymentStatus: payment === 'paid' ? 'paid' : payment === 'partial' ? 'partial' : 'unpaid',
        creditTerm: Math.min(Math.max(0, creditTerm), 3650),
        postDate: postDate || undefined,
        startDate: postDate || paidOn || undefined,
        isPosted: delivered,
        payDate: payDate || null,
        note,
        whtRate,
        whtAmount,
        excludeHolidays: false,
        installments: [],
        ...(payment === 'partial' && receivedFinal > 0 ? { depositDate: paidOn, depositAmount: roundMoney(receivedFinal) } : {}),
      };
      const key = jobDuplicateKey(job);
      if (existingJobKeys.has(key)) issues.push('duplicate');
      else if (fileKeys.has(`j:${key}`)) issues.push('duplicateInFile');
      fileKeys.add(`j:${key}`);
      rows.push({ ...base, kind: 'job', job, ...stateOf(issues) });
    }
  }
  return { rows, newJobTypes, fileTotals };
}

const SKIP_ISSUES: IssueCode[] = ['duplicate', 'noAmount'];
function stateOf(issues: IssueCode[]): { state: ImportRow['state']; issues: IssueCode[] } {
  const unique = [...new Set(issues)];
  if (unique.some(issue => SKIP_ISSUES.includes(issue))) return { state: 'skip', issues: unique };
  return { state: unique.length ? 'check' : 'ready', issues: unique };
}

/** What the import adds, for the summary above the review table. */
export function planTotals(rows: ImportRow[], included: (row: ImportRow) => boolean) {
  const totals = { jobs: 0, expenses: 0, value: 0, received: 0, pending: 0, expenseAmount: 0 };
  for (const row of rows) {
    if (!included(row)) continue;
    if (row.job) { totals.jobs++; totals.value += row.job.value; totals.received += row.job.received; totals.pending += row.job.pending; }
    if (row.expense) { totals.expenses++; totals.expenseAmount += row.expense.amount; }
  }
  for (const key of ['value', 'received', 'pending', 'expenseAmount'] as const) totals[key] = roundMoney(totals[key]);
  return totals;
}
