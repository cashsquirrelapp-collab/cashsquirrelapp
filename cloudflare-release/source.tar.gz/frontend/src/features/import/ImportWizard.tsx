import React from 'react';
import { AlertTriangle, CheckCircle2, ChevronLeft, Download, FileSpreadsheet, Upload } from 'lucide-react';
import type { Expense, Job, StatusOption } from '../../../../shared/types';
import { roundMoney, whtAmountFor } from '../../../../shared/wht';
import { calculatePayDate } from '../../../../shared/calendar';
import { Modal } from '../../components/ui/Modal';
import { Mascot } from '../../components/mascot/Mascot';
import { uiPrimaryButton, uiSecondaryButton } from '../../components/ui/uiStyles';
import { formatCurrency } from '../../utils';
import { tr, T } from '../../i18n/tr';
import { categoryText } from '../incomeExpense/ExpenseDrawer';
import {
  analyzeSheet, buildImportPlan, defaultIncluded, splitSideBySide, MAX_IMPORT_ROWS, normalizeHeader, parseDateText, planTotals,
  type ColumnTarget, type DataKind, type ImportedExpense, type ImportedJob, type ImportRow, type IssueCode, type SheetAnalysis, type SheetGrid,
} from './sheetImport';
import { readWorkbook } from './readWorkbook';
import { downloadImportTemplate } from './importTemplate';

// "นำเข้าจาก Excel" (owner, 2026-10-22, free for every account): pick a file, check how its columns
// match ours, review every row, then import. Computers and iPads only; the phone layout is unchanged.

export interface ImportResult { batchId: string; jobs: number; expenses: number }

interface Props {
  open: boolean;
  onClose: () => void;
  jobs: Job[];
  expenses: Expense[];
  statuses: StatusOption[];
  jobTypes: string[];
  /** Saves the rows; returns the batch so the person can undo it. */
  onImport: (jobs: ImportedJob[], expenses: ImportedExpense[], newJobTypes: string[]) => ImportResult;
  onUndo: (batchId: string) => void;
  onViewJobs: () => void;
}

type Step = 'file' | 'map' | 'review' | 'done';
interface SheetState { grid: SheetGrid; analysis: SheetAnalysis; include: boolean }
interface RowEdit { name?: string; amount?: string; date?: string }

const FIELD_LABELS: Record<ColumnTarget, string> = {
  name: T("ชื่องาน / รายการ"), client: T("ลูกค้า"), type: T("ประเภทงาน"), category: T("หมวดหมู่"),
  value: T("มูลค่างาน"), amount: T("ยอดเงิน"), received: T("ยอดที่รับแล้ว"), pending: T("ยอดค้างรับ"),
  income: T("รายรับ"), expense: T("รายจ่าย"), whtRate: T("หัก ณ ที่จ่าย (%)"), whtAmount: T("หัก ณ ที่จ่าย (บาท)"),
  status: T("สถานะ"), kind: T("ประเภทรายการ (รับ/จ่าย)"), date: T("วันที่"), postDate: T("วันส่งงาน"),
  dueDate: T("วันครบกำหนดรับเงิน"), paidDate: T("วันที่รับเงิน"), creditTerm: T("เครดิต (วัน)"), note: T("หมายเหตุ"),
  project: T("โปรเจกต์ที่เกี่ยวข้อง"), installment: T("งวด"), installmentStatus: T("สถานะงวด"),
  keep: T("เก็บไว้ในหมายเหตุ"), ignore: T("ไม่ใช้"),
};
const FIELDS_FOR: Record<DataKind, ColumnTarget[]> = {
  jobs: ['name', 'client', 'project', 'type', 'value', 'amount', 'received', 'pending', 'whtRate', 'whtAmount', 'status', 'installment', 'installmentStatus', 'date', 'postDate', 'dueDate', 'paidDate', 'creditTerm', 'note', 'keep', 'ignore'],
  expenses: ['name', 'category', 'project', 'amount', 'date', 'note', 'keep', 'ignore'],
  mixed: ['kind', 'name', 'project', 'client', 'category', 'income', 'expense', 'amount', 'date', 'note', 'keep', 'ignore'],
};
const KIND_LABELS: Record<DataKind, string> = { jobs: T("งาน / รายรับ"), expenses: T("รายจ่าย"), mixed: T("รายรับและรายจ่ายปนกัน") };
const ISSUE_LABELS: Record<IssueCode, string> = {
  noName: T("ไม่มีชื่องาน"), noAmount: T("ไม่มียอดเงิน"), negative: T("ยอดติดลบ ใช้เป็นยอดบวก"), noDate: T("ไม่มีวันที่"),
  dateFromSheet: T("ใช้เดือนจากชื่อแท็บ"), dateUnreadable: T("อ่านวันที่ไม่ได้"), amountUnreadable: T("อ่านยอดเงินไม่ได้"),
  valueFromParts: T("มูลค่า = รับแล้ว + ค้างรับ"), paidWithoutDate: T("รับเงินแล้วแต่ไม่มีวันที่รับ"),
  statusConflict: T("สถานะไม่ตรงกับยอดเงิน"), partialNoAmount: T("มัดจำแต่ไม่มียอดที่รับ"), duplicate: T("มีอยู่ในแอปแล้ว"),
  duplicateInFile: T("ซ้ำกับแถวก่อนหน้าในไฟล์"), monthOnly: T("มีแค่เดือน ใช้วันที่ 1"), paidDateFromDate: T("ใช้วันที่ในไฟล์เป็นวันรับเงิน"), total: T("แถวรวมยอด"), repeatedHeader: T("หัวตารางซ้ำ"), blank: T("แถวว่าง"),
  transfer: T("โอนระหว่างบัญชีตัวเอง ไม่ใช่รายรับหรือรายจ่าย"), merged: T("รวมเข้ากับงานในแท็บอื่นแล้ว"), sameNameOtherSheet: T("ชื่อเดียวกับงานในแท็บอื่น ตรวจว่าไม่ซ้ำ"),
};
const MAPPINGS_KEY = 'cashflow_import_mappings';
const PAGE = 100;

const sheetSignature = (analysis: SheetAnalysis) => analysis.columns.map(c => normalizeHeader(c.header)).join('|');
function readMappings(): Record<string, { kind: DataKind; targets: Record<string, ColumnTarget> }> {
  try { return JSON.parse(localStorage.getItem(MAPPINGS_KEY) || '{}'); } catch { return {}; }
}
function rememberMapping(analysis: SheetAnalysis) {
  try {
    const all = readMappings();
    all[sheetSignature(analysis)] = { kind: analysis.kind, targets: Object.fromEntries(analysis.columns.map(c => [normalizeHeader(c.header) || `#${c.index}`, c.target])) };
    const keys = Object.keys(all);
    for (const key of keys.slice(0, Math.max(0, keys.length - 20))) delete all[key];
    localStorage.setItem(MAPPINGS_KEY, JSON.stringify(all));
  } catch { /* remembering is a convenience */ }
}
function applyRemembered(analysis: SheetAnalysis): SheetAnalysis {
  const saved = readMappings()[sheetSignature(analysis)];
  if (!saved || analysis.headerRow === null) return analysis;
  return { ...analysis, kind: saved.kind, columns: analysis.columns.map(c => ({ ...c, target: saved.targets[normalizeHeader(c.header) || `#${c.index}`] ?? c.target, confidence: 1 })) };
}

const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const columnLetter = (index: number) => { let s = '', n = index + 1; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };

/** A row with the person's edits applied, money and due date recomputed like the job form does. */
function editedRow(row: ImportRow, edit: RowEdit | undefined): ImportRow {
  if (!edit) return row;
  const issues = row.issues.filter(issue => !((issue === 'noName' && edit.name) || (issue === 'noAmount' && edit.amount) || ((issue === 'noDate' || issue === 'dateUnreadable' || issue === 'dateFromSheet') && edit.date)));
  const amount = edit.amount !== undefined ? Math.max(0, Number(edit.amount.replace(/,/g, '')) || 0) : undefined;
  const date = edit.date ? parseDateText(edit.date) || edit.date : undefined;
  if (row.expense) {
    return { ...row, issues, expense: { ...row.expense, ...(edit.name ? { name: edit.name.slice(0, 500) } : {}), ...(amount !== undefined ? { amount: roundMoney(amount) } : {}), ...(date ? { date } : {}) } };
  }
  if (!row.job) return row;
  const job = { ...row.job, ...(edit.name ? { name: edit.name.slice(0, 500) } : {}) };
  if (amount !== undefined) {
    const rate = job.whtRate || 0;
    job.value = roundMoney(amount);
    job.whtAmount = whtAmountFor(job.value, rate);
    const net = roundMoney(job.value - job.whtAmount);
    if (job.status === 'done' || job.paymentStatus === 'paid') job.received = net;
    job.received = Math.min(job.received, net);
    job.pending = Math.max(0, roundMoney(net - job.received));
  }
  if (date) {
    job.postDate = date;
    if (job.paymentStatus !== 'paid') job.payDate = calculatePayDate(date, job.creditTerm, false);
  }
  return { ...row, issues, job };
}

export function ImportWizard({ open, onClose, jobs, expenses, statuses, jobTypes, onImport, onUndo, onViewJobs }: Props) {
  const [step, setStep] = React.useState<Step>('file');
  const [fileName, setFileName] = React.useState('');
  const [sheets, setSheets] = React.useState<SheetState[]>([]);
  const [active, setActive] = React.useState(0);
  const [amountsAreNet, setAmountsAreNet] = React.useState(false);
  const [reading, setReading] = React.useState(false);
  const [error, setError] = React.useState('');
  const [dragging, setDragging] = React.useState(false);
  const [included, setIncluded] = React.useState<Record<string, boolean>>({});
  const [edits, setEdits] = React.useState<Record<string, RowEdit>>({});
  const [filter, setFilter] = React.useState<'all' | 'check' | 'skip'>('all');
  const [shown, setShown] = React.useState(PAGE);
  const [result, setResult] = React.useState<ImportResult | null>(null);
  const [undone, setUndone] = React.useState(false);

  const reset = () => {
    setStep('file'); setFileName(''); setSheets([]); setActive(0); setAmountsAreNet(false); setError(''); setIncluded({}); setEdits({});
    setFilter('all'); setShown(PAGE); setResult(null); setUndone(false);
  };
  const close = () => { reset(); onClose(); };

  const readFile = async (file: File) => {
    setError('');
    if (!/\.(xlsx|xlsm|xls|csv|ods|txt|numbers)$/i.test(file.name)) { setError(tr("รองรับไฟล์ Excel (.xlsx .xls) CSV และ .ods")); return; }
    if (file.size > 15 * 1024 * 1024) { setError(tr("ไฟล์ใหญ่เกิน 15 MB กรุณาแบ่งเป็นหลายไฟล์")); return; }
    setReading(true);
    try {
      const XLSX = await import('xlsx');
      const grids = readWorkbook(XLSX, await file.arrayBuffer(), file.name).filter(grid => grid.rows.some(row => row.some(cell => cell.text))).flatMap(splitSideBySide);
      if (!grids.length) { setError(tr("ไม่พบข้อมูลในไฟล์นี้")); return; }
      const next = grids.map(grid => {
        const analysis = applyRemembered(analyzeSheet(grid));
        return { grid, analysis, include: defaultIncluded(analysis) };
      });
      setSheets(next);
      setActive(Math.max(0, next.findIndex(s => s.include)));
      setFileName(file.name);
      setStep('map');
    } catch {
      setError(tr("เปิดไฟล์นี้ไม่ได้ ไฟล์อาจเสียหายหรือมีรหัสผ่าน ลองบันทึกเป็น .xlsx หรือ .csv แล้วเลือกใหม่"));
    } finally {
      setReading(false);
    }
  };

  const updateSheet = (index: number, change: (sheet: SheetState) => SheetState) => setSheets(list => list.map((sheet, i) => (i === index ? change(sheet) : sheet)));
  const setTarget = (col: number, target: ColumnTarget) => updateSheet(active, sheet => ({
    ...sheet,
    analysis: { ...sheet.analysis, columns: sheet.analysis.columns.map(c => (c.index === col ? { ...c, target, confidence: 1 } : target !== 'keep' && target !== 'ignore' && target !== 'note' && c.target === target ? { ...c, target: 'keep' } : c)) },
  }));

  const plan = React.useMemo(() => (step === 'review' || step === 'done'
    ? buildImportPlan(sheets.filter(s => s.include), { amountsAreNet, today: todayKey() }, { statuses, jobTypes, existingJobs: jobs, existingExpenses: expenses })
    : null), [step === 'review' || step === 'done' ? sheets : null, amountsAreNet, step]); // eslint-disable-line react-hooks/exhaustive-deps

  const rows = React.useMemo(() => (plan ? plan.rows.map(row => editedRow(row, edits[row.key])) : []), [plan, edits]);
  const isIncluded = React.useCallback((row: ImportRow) => row.kind !== 'skip' && (included[row.key] ?? row.state !== 'skip'), [included]);
  const totals = React.useMemo(() => planTotals(rows, isIncluded), [rows, isIncluded]);
  const totalRows = sheets.filter(s => s.include).reduce((sum, s) => sum + s.analysis.dataRows.length, 0);

  const startReview = () => {
    for (const sheet of sheets) if (sheet.include) rememberMapping(sheet.analysis);
    setIncluded({}); setEdits({}); setFilter('all'); setShown(PAGE); setStep('review');
  };

  const commit = () => {
    const chosen = rows.filter(isIncluded);
    const importJobs = chosen.filter(r => r.job).map(r => r.job!);
    const importExpenses = chosen.filter(r => r.expense && r.expense.date).map(r => r.expense!);
    const usedTypes = new Set(importJobs.map(j => j.type));
    setResult(onImport(importJobs, importExpenses, (plan?.newJobTypes || []).filter(type => usedTypes.has(type))));
    setStep('done');
  };

  const sheet = sheets[active];
  const fieldsForSheet = sheet ? FIELDS_FOR[sheet.analysis.kind] : [];
  const missingName = sheet && sheet.include && !sheet.analysis.columns.some(c => ['name', 'client', 'category'].includes(c.target));
  const missingAmount = sheet && sheet.include && !sheet.analysis.columns.some(c => ['value', 'amount', 'received', 'pending', 'income', 'expense'].includes(c.target));
  const hasWht = sheets.some(s => s.include && s.analysis.columns.some(c => c.target === 'whtRate' || c.target === 'whtAmount'));

  const visibleRows = rows.filter(row => (filter === 'all' ? true : filter === 'skip' ? !isIncluded(row) : isIncluded(row) && row.issues.length > 0));
  const checkCount = rows.filter(row => isIncluded(row) && row.issues.length > 0).length;
  const skipCount = rows.filter(row => !isIncluded(row)).length;
  const missingExpenseDates = rows.filter(row => isIncluded(row) && row.expense && !row.expense.date).length;

  const header = (title: string, sub: string) => (
    <div className="border-b border-brand-border px-6 pb-4 pt-5 pr-12">
      <p className="text-[12px] font-medium text-[#C24A16] dark:text-[#FF9A6B]">{tr("นำเข้าจาก Excel")}</p>
      <h2 className="mt-0.5 text-[20px] font-semibold text-brand-text">{title}</h2>
      <p className="mt-1 text-[13px] text-brand-muted">{sub}</p>
    </div>
  );
  const stepper = (
    <ol className="flex items-center gap-2 px-6 pt-3 text-[12px]" aria-label={tr("ขั้นตอน")}>
      {([['file', T("เลือกไฟล์")], ['map', T("จับคู่คอลัมน์")], ['review', T("ตรวจทาน")], ['done', T("เสร็จ")]] as const).map(([key, label], i, all) => {
        const index = all.findIndex(([k]) => k === step);
        return (
          <li key={key} className="flex items-center gap-2" aria-current={key === step ? 'step' : undefined}>
            <span className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-semibold ${i <= index ? 'bg-[#E65F2B] text-white' : 'bg-brand-faint text-brand-muted'}`}>{i + 1}</span>
            <span className={i === index ? 'font-medium text-brand-text' : 'text-brand-muted'}>{tr(label)}</span>
            {i < all.length - 1 && <span className="mx-1 h-px w-6 bg-brand-border" aria-hidden="true" />}
          </li>
        );
      })}
    </ol>
  );

  return (
    <Modal open={open} onClose={close} label={tr("นำเข้าจาก Excel")} width={1080}>
      <div className="flex max-h-[86vh] flex-col" data-testid="import-wizard">
        {step === 'file' && (<>
          {header(tr("นำข้อมูลเดิมเข้าแอป"), tr("งานและรายจ่ายที่เคยจดไว้ใน Excel หรือ Google Sheets นำเข้าได้ในครั้งเดียว ไม่ต้องกรอกใหม่"))}
          {stepper}
          <div className="space-y-4 overflow-y-auto px-6 py-5">
            <div onDragEnter={e => { e.preventDefault(); setDragging(true); }} onDragOver={e => e.preventDefault()} onDragLeave={() => setDragging(false)}
              onDrop={e => { e.preventDefault(); setDragging(false); const file = e.dataTransfer.files?.[0]; if (file) void readFile(file); }}
              className={`rounded-2xl border-2 border-dashed transition-colors ${dragging ? 'border-[#E65F2B] bg-[#FFF5EE] dark:bg-[#E65F2B]/10' : 'border-brand-border bg-brand-faint/50 hover:border-[#F3B08C]'}`}>
              <input type="file" id="import-sheet-file" accept=".xlsx,.xlsm,.xls,.csv,.ods,.txt" className="hidden" onChange={e => { const file = e.target.files?.[0]; e.target.value = ''; if (file) void readFile(file); }} />
              <label htmlFor="import-sheet-file" className="flex min-h-[180px] cursor-pointer flex-col items-center justify-center gap-2 p-6 text-center">
                <FileSpreadsheet className="h-8 w-8 text-[#E65F2B]" />
                <span className="text-[15px] font-medium text-brand-text">{reading ? tr("กำลังอ่านไฟล์…") : tr("ลากไฟล์มาวาง หรือกดเพื่อเลือกไฟล์")}</span>
                <span className="text-[12px] text-brand-muted">{tr("Excel (.xlsx .xls) · CSV · .ods · Google Sheets: ดาวน์โหลดเป็น .xlsx ก่อน")}</span>
              </label>
            </div>
            {error && <p role="alert" className="flex items-start gap-2 rounded-xl bg-[#FFF0F0] px-3 py-2.5 text-[13px] text-[#C43A3A] dark:bg-rose-500/10 dark:text-rose-300"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{error}</p>}
            <div className="grid gap-3 sm:grid-cols-3">
              {[
                [T("อ่านในเครื่องของคุณ"), T("ไฟล์ยังไม่ถูกส่งขึ้นระบบจนกว่าคุณจะกดนำเข้า")],
                [T("ตรวจได้ทุกแถวก่อนบันทึก"), T("ระบบจับคู่คอลัมน์ให้ แล้วให้คุณตรวจและแก้ก่อนนำเข้า")],
                [T("ยกเลิกได้ทั้งชุด"), T("ถ้านำเข้าแล้วไม่ถูกต้อง ลบทั้งชุดได้ภายใน 7 วัน")],
              ].map(([title, text]) => (
                <div key={title} className="rounded-xl border border-brand-border px-4 py-3">
                  <p className="text-[13px] font-medium text-brand-text">{tr(title)}</p>
                  <p className="mt-0.5 text-[12px] leading-relaxed text-brand-muted">{tr(text)}</p>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-brand-faint/60 px-4 py-3">
              <p className="text-[13px] text-brand-muted">{tr("ยังไม่มีไฟล์ หรืออยากให้ตรงที่สุด ใช้ไฟล์ตัวอย่างของเรากรอกได้เลย")}</p>
              <button type="button" onClick={() => void downloadImportTemplate()} className={`${uiSecondaryButton} px-4 text-[13px]`}><Download className="h-4 w-4" />{tr("ดาวน์โหลดไฟล์ตัวอย่าง")}</button>
            </div>
          </div>
        </>)}

        {step === 'map' && sheet && (<>
          {header(tr("จับคู่คอลัมน์"), tr("ระบบเดาให้แล้วจากหัวตารางและข้อมูลในแต่ละคอลัมน์ ตรวจว่าแต่ละคอลัมน์ตรงกับช่องไหน เปลี่ยนได้ถ้าไม่ถูก"))}
          {stepper}
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-4">
            <p className="mb-3 text-[12px] text-brand-muted">{tr("ไฟล์: {0}", fileName)}</p>
            {sheets.length > 1 && (
              <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label={tr("แท็บในไฟล์")}>
                {sheets.map((s, i) => (
                  <div key={s.grid.name + i} className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-[13px] ${i === active ? 'border-[#F3B08C] bg-[#FFF1E8] dark:bg-[#E65F2B]/10' : 'border-brand-border'}`}>
                    <input type="checkbox" checked={s.include} disabled={s.analysis.monthsAcross || !s.analysis.dataRows.length} aria-label={tr("นำเข้าแท็บ {0}", s.grid.name)}
                      onChange={e => updateSheet(i, x => ({ ...x, include: e.target.checked }))} className="accent-[#E65F2B]" />
                    <button type="button" role="tab" aria-selected={i === active} onClick={() => setActive(i)} className="cursor-pointer text-brand-text">{s.grid.name}</button>
                    <span className="text-[11px] text-brand-muted">{tr("{0} แถว", s.analysis.dataRows.length)}</span>
                  </div>
                ))}
              </div>
            )}
            {sheet.analysis.role === 'summary' && !sheet.analysis.monthsAcross && (
              <p className="mb-4 rounded-xl bg-brand-faint px-4 py-3 text-[13px] text-brand-text">{tr("แท็บนี้ดูเป็นหน้าสรุปหรือคำอธิบาย ไม่ได้มีรายการทีละงาน จึงไม่ได้เลือกไว้ ถ้าต้องการนำเข้า ติ๊กที่ชื่อแท็บด้านบน")}</p>
            )}
            {sheet.analysis.monthsAcross ? (
              <p className="rounded-xl bg-brand-faint px-4 py-3 text-[13px] text-brand-text">{tr("แท็บนี้เป็นตารางสรุปที่เรียงเดือนเป็นคอลัมน์ มีแต่ยอดรวม ไม่มีรายการทีละงาน จึงนำเข้าเป็นรายการไม่ได้ ใช้แท็บที่จดทีละงานแทน")}</p>
            ) : (<>
              <div className="mb-4 flex flex-wrap items-end gap-4">
                <label className="text-[13px] text-brand-text">
                  <span className="mb-1 block text-[12px] text-brand-muted">{tr("ข้อมูลในแท็บนี้คือ")}</span>
                  <select value={sheet.analysis.kind} onChange={e => updateSheet(active, x => ({ ...x, analysis: { ...x.analysis, kind: e.target.value as DataKind } }))}
                    className="h-10 rounded-[10px] border border-brand-border bg-brand-white px-3 text-[13px] dark:bg-neutral-950">
                    {(['jobs', 'expenses', 'mixed'] as DataKind[]).map(kind => <option key={kind} value={kind}>{tr(KIND_LABELS[kind])}</option>)}
                  </select>
                </label>
                <label className="text-[13px] text-brand-text">
                  <span className="mb-1 block text-[12px] text-brand-muted">{tr("หัวตารางอยู่แถวที่")}</span>
                  <select value={sheet.analysis.headerRow ?? -1} onChange={e => {
                    const value = Number(e.target.value);
                    updateSheet(active, x => ({ ...x, analysis: analyzeSheet(x.grid, { headerRow: value < 0 ? null : value }) }));
                  }} className="h-10 rounded-[10px] border border-brand-border bg-brand-white px-3 text-[13px] dark:bg-neutral-950">
                    <option value={-1}>{tr("ไม่มีหัวตาราง")}</option>
                    {sheet.grid.rows.slice(0, 15).map((_, r) => <option key={r} value={r}>{tr("แถว {0}", r + 1)}</option>)}
                  </select>
                </label>
              </div>
              <div className="overflow-hidden rounded-xl border border-brand-border">
                <table className="w-full table-fixed text-left text-[13px]">
                  <thead className="bg-brand-faint/70 text-[12px] text-brand-muted">
                    <tr><th className="w-[24%] px-4 py-2.5 font-medium">{tr("คอลัมน์ในไฟล์")}</th><th className="px-4 py-2.5 font-medium">{tr("ตัวอย่างข้อมูล")}</th><th className="w-[30%] px-4 py-2.5 font-medium">{tr("ใช้เป็น")}</th></tr>
                  </thead>
                  <tbody>
                    {sheet.analysis.columns.map(column => {
                      const unsure = column.target !== 'keep' && column.target !== 'ignore' && column.confidence < 0.7;
                      return (
                        <tr key={column.index} className="border-t border-brand-border">
                          <td className="px-4 py-2.5 align-top"><span className="font-medium text-brand-text">{column.header || tr("คอลัมน์ {0}", columnLetter(column.index))}</span><span className="ml-1.5 text-[11px] text-brand-muted">{columnLetter(column.index)}</span></td>
                          <td className="truncate px-4 py-2.5 align-top text-brand-muted" title={column.samples.join(' · ')}>{column.samples.join(' · ') || '—'}</td>
                          <td className="px-4 py-2 align-top">
                            <div className="flex items-center gap-2">
                              <select aria-label={tr("ใช้คอลัมน์ {0} เป็น", column.header || columnLetter(column.index))} value={column.target} onChange={e => setTarget(column.index, e.target.value as ColumnTarget)}
                                className={`h-9 min-w-0 flex-1 rounded-[10px] border bg-brand-white px-2.5 text-[13px] dark:bg-neutral-950 ${unsure ? 'border-[#F2A93B]' : 'border-brand-border'}`}>
                                {[...new Set([...fieldsForSheet, column.target])].map(target => <option key={target} value={target}>{tr(FIELD_LABELS[target])}</option>)}
                              </select>
                              {unsure && <span className="shrink-0 rounded-md bg-[#FAEEDA] px-1.5 py-0.5 text-[11px] text-[#8A5A0B]">{tr("ควรตรวจ")}</span>}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {(missingName || missingAmount) && (
                <p role="alert" className="mt-3 flex items-start gap-2 rounded-xl bg-[#FAEEDA] px-3 py-2.5 text-[13px] text-[#8A5A0B]"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                  {missingName ? tr("ยังไม่มีคอลัมน์ที่เป็นชื่องานหรือรายการ เลือกให้อย่างน้อยหนึ่งคอลัมน์") : tr("ยังไม่มีคอลัมน์ที่เป็นยอดเงิน เลือกให้อย่างน้อยหนึ่งคอลัมน์")}</p>
              )}
            </>)}
            {hasWht && (
              <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-brand-border px-4 py-3">
                <input type="checkbox" checked={amountsAreNet} onChange={e => setAmountsAreNet(e.target.checked)} className="mt-0.5 accent-[#E65F2B]" />
                <span><span className="block text-[13px] font-medium text-brand-text">{tr("ยอดเงินในไฟล์เป็นยอดหลังหัก ณ ที่จ่ายแล้ว")}</span>
                  <span className="block text-[12px] text-brand-muted">{tr("เช่น งาน 10,000 บาท หัก 3% แล้วกรอกไว้ 9,700 ระบบจะคำนวณมูลค่างานก่อนหักให้")}</span></span>
              </label>
            )}
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-brand-border px-6 py-4">
            <button type="button" onClick={reset} className={`${uiSecondaryButton} px-4 text-[13px]`}><ChevronLeft className="h-4 w-4" />{tr("เลือกไฟล์อื่น")}</button>
            <div className="flex items-center gap-3">
              {totalRows > MAX_IMPORT_ROWS && <span className="text-[12px] text-[#C43A3A]">{tr("นำเข้าได้ครั้งละไม่เกิน {0} แถว แถวที่เกินจะยังไม่นำเข้า", MAX_IMPORT_ROWS.toLocaleString('en-US'))}</span>}
              <button type="button" onClick={startReview} disabled={!sheets.some(s => s.include)} className={`${uiPrimaryButton} px-5 text-[13px] disabled:opacity-50`}>{tr("ตรวจทานข้อมูล")}</button>
            </div>
          </div>
        </>)}

        {step === 'review' && plan && (<>
          {header(tr("ตรวจทานก่อนนำเข้า"), tr("ดูทุกแถวว่าถูกต้อง แก้ชื่อ ยอดเงิน หรือวันที่ได้ในตาราง แถวที่ไม่ติ๊กจะไม่ถูกนำเข้า"))}
          {stepper}
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-4">
            <div className="mb-4 grid gap-3 sm:grid-cols-3">
              <div className="rounded-xl border border-brand-border px-4 py-3">
                <p className="text-[12px] text-brand-muted">{tr("งานที่จะนำเข้า")}</p>
                <p className="mt-0.5 text-[18px] font-semibold text-brand-text" data-testid="import-job-count">{tr("{0} งาน", totals.jobs)}</p>
                <p className="text-[12px] text-brand-muted">{tr("มูลค่า {0} · รับแล้ว {1} · ค้างรับ {2}", formatCurrency(totals.value), formatCurrency(totals.received), formatCurrency(totals.pending))}</p>
              </div>
              <div className="rounded-xl border border-brand-border px-4 py-3">
                <p className="text-[12px] text-brand-muted">{tr("รายจ่ายที่จะนำเข้า")}</p>
                <p className="mt-0.5 text-[18px] font-semibold text-brand-text" data-testid="import-expense-count">{tr("{0} รายการ", totals.expenses)}</p>
                <p className="text-[12px] text-brand-muted">{tr("รวม {0}", formatCurrency(totals.expenseAmount))}</p>
              </div>
              <div className="rounded-xl border border-brand-border px-4 py-3">
                <p className="text-[12px] text-brand-muted">{tr("เทียบกับแถวรวมในไฟล์")}</p>
                {!plan.checks.length ? <p className="mt-0.5 text-[13px] text-brand-muted">{tr("ไฟล์ไม่มีแถวรวมยอดให้เทียบ")}</p>
                  : plan.checks.every(check => check.ok)
                    ? <p className="mt-0.5 flex items-center gap-1.5 text-[14px] font-medium text-[#12804F] dark:text-[#6FD3A3]" data-testid="import-total-check"><CheckCircle2 className="h-4 w-4" />{plan.checks.length === 1 ? tr("ตรงกัน {0}", formatCurrency(plan.checks[0].fileTotal)) : tr("อ่านได้ตรงกับแถวรวมทุกแท็บ ({0} ยอด)", plan.checks.length)}</p>
                    : plan.checks.filter(check => !check.ok).slice(0, 2).map(check => <p key={check.sheet + check.field} className="mt-0.5 text-[13px] text-[#8A5A0B]">{tr("แท็บ {0}: แถวรวม {1} · อ่านได้ {2} ดูแถวที่อ่านไม่ได้", check.sheet, formatCurrency(check.fileTotal), formatCurrency(check.rowsTotal))}</p>)}
              </div>
            </div>
            <div className="mb-3 flex flex-wrap items-center gap-2" role="tablist" aria-label={tr("แสดงแถว")}>
              {([['all', T("ทั้งหมด"), rows.length], ['check', T("ควรตรวจ"), checkCount], ['skip', T("ไม่นำเข้า"), skipCount]] as const).map(([key, label, count]) => (
                <button key={key} type="button" role="tab" aria-selected={filter === key} onClick={() => { setFilter(key); setShown(PAGE); }}
                  className={`h-8 rounded-full border px-3 text-[12px] cursor-pointer ${filter === key ? 'border-[#F3B08C] bg-[#FFF1E8] font-medium text-[#C24A16] dark:bg-[#E65F2B]/10 dark:text-[#FF9A6B]' : 'border-brand-border text-brand-text'}`}>{tr(label)} {count}</button>
              ))}
            </div>
            <div className="overflow-x-auto rounded-xl border border-brand-border">
              {/* Fixed column widths so the name keeps its room; narrow screens scroll the table sideways. */}
              <table className="w-full min-w-[1000px] table-fixed text-left text-[13px]">
                <colgroup>
                  <col style={{ width: 40 }} /><col style={{ width: 92 }} /><col style={{ width: 64 }} /><col />
                  <col style={{ width: 140 }} /><col style={{ width: 104 }} /><col style={{ width: 144 }} /><col style={{ width: 92 }} /><col style={{ width: 150 }} />
                </colgroup>
                <thead className="bg-brand-faint/70 text-[12px] text-brand-muted">
                  <tr>
                    <th className="px-3 py-2.5"><span className="sr-only">{tr("นำเข้า")}</span></th>
                    <th className="px-2 py-2.5 font-medium">{tr("แถว")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("ประเภท")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("ชื่อ")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("ลูกค้า / หมวด")}</th>
                    <th className="px-2 py-2.5 text-right font-medium">{tr("ยอดเงิน")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("วันที่")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("รับเงิน")}</th>
                    <th className="px-2 py-2.5 font-medium">{tr("ข้อสังเกต")}</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleRows.slice(0, shown).map(row => {
                    const on = isIncluded(row);
                    const edit = edits[row.key] || {};
                    const setEdit = (patch: RowEdit) => setEdits(all => ({ ...all, [row.key]: { ...all[row.key], ...patch } }));
                    const name = row.job?.name ?? row.expense?.name ?? '';
                    const amount = row.job?.value ?? row.expense?.amount ?? 0;
                    const date = row.job ? row.job.postDate || row.job.payDate || '' : row.expense?.date || '';
                    const input = 'h-8 w-full rounded-lg border border-transparent bg-transparent px-2 text-[13px] text-brand-text hover:border-brand-border focus:border-[#E65F2B] focus:bg-brand-white focus:outline-none dark:focus:bg-neutral-950';
                    return (
                      <tr key={row.key} className={`border-t border-brand-border ${on ? '' : 'opacity-55'}`}>
                        <td className="px-3 py-1.5"><input type="checkbox" checked={on} disabled={row.kind === 'skip'} aria-label={tr("นำเข้าแถว {0}", row.rowNumber)} className="accent-[#E65F2B]"
                          onChange={e => setIncluded(all => ({ ...all, [row.key]: e.target.checked }))} /></td>
                        <td className="truncate px-2 py-1.5 text-[12px] text-brand-muted" title={`${row.sheet} · ${row.rowNumber}`}>{sheets.filter(s => s.include).length > 1 ? `${row.sheet} · ` : ''}{row.rowNumber}</td>
                        <td className="px-2 py-1.5 text-[12px]">{row.job ? tr("งาน") : row.expense ? <span className="text-[#C43A3A] dark:text-[#F19A9A]">{tr("รายจ่าย")}</span> : '—'}</td>
                        <td className="px-1 py-1.5">{row.kind === 'skip' ? <span className="px-2 text-brand-muted">—</span> : <input aria-label={tr("ชื่อแถว {0}", row.rowNumber)} className={input} value={edit.name ?? name} onChange={e => setEdit({ name: e.target.value })} />}</td>
                        <td className="truncate px-2 py-1.5 text-brand-muted">{row.job ? row.job.client || '—' : row.expense ? categoryText(row.expense.category) : ''}</td>
                        <td className="px-1 py-1.5">{row.kind === 'skip' ? null : <input aria-label={tr("ยอดเงินแถว {0}", row.rowNumber)} inputMode="decimal" className={`${input} text-right tabular-nums`} value={edit.amount ?? amount.toLocaleString('en-US', { maximumFractionDigits: 2 })} onChange={e => setEdit({ amount: e.target.value })} />}</td>
                        <td className="px-1 py-1.5">{row.kind === 'skip' ? null : <input aria-label={tr("วันที่แถว {0}", row.rowNumber)} type="date" className={input} value={edit.date ?? date} onChange={e => setEdit({ date: e.target.value })} />}</td>
                        <td className="px-2 py-1.5 text-[12px]">{row.job ? (row.job.paymentStatus === 'paid' ? <span className="text-[#12804F] dark:text-[#6FD3A3]">{tr("รับครบแล้ว")}</span> : row.job.paymentStatus === 'partial' ? tr("รับบางส่วน") : <span className="text-[#C24A16] dark:text-[#FF9A6B]">{tr("ยังไม่จ่าย")}</span>) : ''}</td>
                        <td className="px-2 py-1.5">
                          <div className="flex flex-wrap gap-1">
                            {row.issues.map(issue => <span key={issue} className={`rounded-md px-1.5 py-0.5 text-[11px] ${['duplicate', 'total', 'blank', 'repeatedHeader', 'merged', 'transfer'].includes(issue) ? 'bg-brand-faint text-brand-muted' : 'bg-[#FAEEDA] text-[#8A5A0B]'}`}>{issue === 'merged' && row.mergedInto ? tr("รวมเข้ากับ {0}", row.mergedInto) : tr(ISSUE_LABELS[issue])}</span>)}
                            {row.mergedCount ? <span className="rounded-md bg-[#E9F7F0] px-1.5 py-0.5 text-[11px] text-[#12804F] dark:bg-[#6FD3A3]/10 dark:text-[#6FD3A3]">{tr("รวมการรับเงินและใบแจ้งหนี้จากแท็บอื่น {0} แถว", row.mergedCount)}</span> : null}
                            {!row.issues.length && !row.mergedCount && <span className="text-[11px] text-[#12804F] dark:text-[#6FD3A3]">{tr("พร้อม")}</span>}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {!visibleRows.length && <p className="px-4 py-8 text-center text-[13px] text-brand-muted">{tr("ไม่มีแถวในหมวดนี้")}</p>}
            </div>
            {visibleRows.length > shown && <button type="button" onClick={() => setShown(n => n + PAGE)} className={`${uiSecondaryButton} mt-3 px-4 text-[13px]`}>{tr("แสดงเพิ่มอีก {0} แถว", Math.min(PAGE, visibleRows.length - shown))}</button>}
            {missingExpenseDates > 0 && <p className="mt-3 text-[12px] text-[#8A5A0B]">{tr("รายจ่าย {0} รายการยังไม่มีวันที่ ใส่วันที่ในตารางก่อน ไม่อย่างนั้นจะยังไม่นำเข้า", missingExpenseDates)}</p>}
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-brand-border px-6 py-4">
            <button type="button" onClick={() => setStep('map')} className={`${uiSecondaryButton} px-4 text-[13px]`}><ChevronLeft className="h-4 w-4" />{tr("กลับไปจับคู่คอลัมน์")}</button>
            <button type="button" onClick={commit} disabled={!totals.jobs && !(totals.expenses - missingExpenseDates)} className={`${uiPrimaryButton} px-5 text-[13px] disabled:opacity-50`} data-testid="import-commit">
              <Upload className="h-4 w-4" />{tr("นำเข้า {0} งาน และ {1} รายจ่าย", totals.jobs, Math.max(0, totals.expenses - missingExpenseDates))}
            </button>
          </div>
        </>)}

        {step === 'done' && result && (
          <div className="flex flex-col items-center px-8 py-10 text-center">
            <Mascot mood={undone ? 'happy' : 'celebrate'} size={104} />
            <h2 className="mt-3 text-[20px] font-semibold text-brand-text">{undone ? tr("ยกเลิกการนำเข้าแล้ว") : tr("นำเข้าเรียบร้อย")}</h2>
            <p className="mt-1 max-w-md text-[13px] text-brand-muted">{undone
              ? tr("รายการจากไฟล์นี้ถูกนำออกจากแอปแล้ว")
              : tr("เพิ่ม {0} งาน และ {1} รายจ่าย จาก {2} ถ้าไม่ถูกต้อง ยกเลิกการนำเข้านี้ได้ที่นี่ หรือที่ ตั้งค่า > สำรอง & นำเข้าข้อมูล ภายใน 7 วัน", result.jobs, result.expenses, fileName)}</p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              {!undone && <button type="button" onClick={() => { close(); onViewJobs(); }} className={`${uiPrimaryButton} px-5 text-[13px]`}>{tr("ดูงานที่นำเข้า")}</button>}
              {!undone && <button type="button" onClick={() => { onUndo(result.batchId); setUndone(true); }} className={`${uiSecondaryButton} px-4 text-[13px]`}>{tr("ยกเลิกการนำเข้านี้")}</button>}
              <button type="button" onClick={close} className={`${uiSecondaryButton} px-4 text-[13px]`}>{tr("ปิด")}</button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
