// Which imports can still be undone: every imported row carries the batch it came in with.
import type { Expense, Job } from '../../../../shared/types';
import { currentLanguage } from '../../i18n/currentLanguage';

export interface ImportBatch { id: string; at: string; jobs: number; expenses: number }

/** Imports saved in the last 7 days, from the batch tag each imported row carries. */
export function recentImports(jobs: Job[], expenses: Expense[], now = Date.now()): ImportBatch[] {
  const batches = new Map<string, ImportBatch>();
  const add = (row: { importBatchId?: unknown; importedAt?: unknown }, kind: 'jobs' | 'expenses') => {
    if (typeof row.importBatchId !== 'string' || typeof row.importedAt !== 'string') return;
    if (now - Date.parse(row.importedAt) > 7 * 86400000) return;
    const batch = batches.get(row.importBatchId) || { id: row.importBatchId, at: row.importedAt, jobs: 0, expenses: 0 };
    batch[kind]++;
    batches.set(row.importBatchId, batch);
  };
  for (const job of jobs) add(job as Job & { importBatchId?: unknown; importedAt?: unknown }, 'jobs');
  for (const expense of expenses) add(expense as Expense & { importBatchId?: unknown; importedAt?: unknown }, 'expenses');
  return [...batches.values()].sort((a, b) => b.at.localeCompare(a.at));
}

export const importedLabel = (iso: string) => new Date(iso).toLocaleString(currentLanguage === 'en' ? 'en-US' : 'th-TH', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
