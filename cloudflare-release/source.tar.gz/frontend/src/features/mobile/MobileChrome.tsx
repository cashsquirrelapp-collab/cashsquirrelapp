import React from 'react';
import { BrandLogo } from '../../components/brand/BrandLogo';
import { Mascot } from '../../components/mascot/Mascot';
import { KsIcon, SquirrelAdd, type KsIconName } from './icons';
import { mobileBottomTabs, type MobileBottomTab, type MobileTab } from './mobileNavigation';
// The one place the mobile stylesheet is loaded (App imports this file), so page components that
// unit tests import for their pure functions never pull a .css file into Node.
import './mobile.css';

// The app's shell on phones (see useMobileLayout): a top bar, a bottom bar with the squirrel
// add button in the middle, and the tools screen behind "เมนู". Layout and styling follow the
// owner's design file; every button calls the app's existing handlers, and the tools list is built
// from the same permission-filtered list the desktop sidebar uses, so no feature is dropped.

export type { MobileTab } from './mobileNavigation';

export type MobileGreeting = { name: string; avatarUrl?: string; onOpen: () => void };

export function MobileHeader({ dark, onToggleTheme, alerts, onOpenAlerts, onHome, greeting, alertsAccess = false }: {
  dark: boolean; onToggleTheme: () => void; alerts: number; onOpenAlerts: () => void; onHome: () => void;
  /** The overview: the bar takes the header's terracotta and adds a greeting under the logo. */
  greeting?: MobileGreeting;
  /** The bell (due-payment reminders) is open to this account. */
  alertsAccess?: boolean;
}) {
  const themeLabel = dark ? 'เปลี่ยนเป็นโหมดสว่าง' : 'เปลี่ยนเป็นโหมดมืด';
  const theme = (
    <button key="theme" type="button" className="ksm-iconbtn" onClick={onToggleTheme} aria-label={themeLabel} title={themeLabel} aria-pressed={dark}>
      <KsIcon name={dark ? 'moon' : 'sun'} />
    </button>
  );
  const bell = alertsAccess && (
    <button key="bell" type="button" className="ksm-iconbtn is-notify" onClick={onOpenAlerts}
      aria-label={alerts ? `การแจ้งเตือน: ถึงเวลาตามเงิน ${alerts} รายการ` : 'การแจ้งเตือน'}>
      <KsIcon name="bell" />
      {alerts > 0 && <i className="ksm-dot" aria-hidden="true" />}
    </button>
  );
  return (
    <header className={`ksm ksm-header${greeting ? ' is-hero' : ''}`}>
      {/* The overview header (owner's reference, 2026-10-20): the original mascot as a faint white shape behind the greeting. */}
      {greeting && <span className="ksm-header-mascot" aria-hidden="true"><Mascot mood="happy" action="hold-baht" animated={false} size={124} /></span>}
      <div className="ksm-top">
        <button type="button" className="ksm-brand" onClick={onHome} aria-label="กระรอกตุนเงิน ไปหน้าภาพรวม">
          <span className="ksm-brand-mark"><BrandLogo size={greeting ? 34 : 36} /></span>
          <span className="ksm-wordmark" aria-hidden="true">กระรอก<span>ตุนเงิน</span></span>
        </button>
        <span className="ksm-spacer" />
        {/* The overview puts the bell first, as in the reference; other pages keep theme, then bell. */}
        {greeting ? [bell, theme] : [theme, bell]}
      </div>
      {greeting && (
        <button type="button" className="ksm-hello" onClick={greeting.onOpen} aria-label={`โปรไฟล์ของ ${greeting.name}`}>
          <span className="ksm-hello-text"><small>สวัสดีอีกครั้ง</small><b>Hello, {greeting.name}</b></span>
          <span className="ksm-hello-avatar">{greeting.avatarUrl ? <img src={greeting.avatarUrl} alt="" /> : <BrandLogo size={44} />}</span>
        </button>
      )}
    </header>
  );
}

export function MobileBottomNav({ current, onSelect, onAddJob, receivablesAccess = false }: { current: MobileTab | null; onSelect: (tab: MobileTab) => void; onAddJob: () => void; receivablesAccess?: boolean }) {
  // The five slots come from mobileNavigation.ts; the fourth is รอรับ wherever the launch policy opens it.
  const { left, right } = mobileBottomTabs(receivablesAccess);
  const item = (tab: MobileBottomTab) => (
    <button key={tab.key} type="button" className="ksm-nav-item" aria-current={current === tab.key ? 'page' : undefined} onClick={() => onSelect(tab.key)}>
      <span className="ksm-nav-icon"><KsIcon name={tab.icon} size={23} /></span>
      <span>{tab.label}</span>
    </button>
  );
  return (
    <nav className="ksm ksm-nav" aria-label="เมนูหลัก">
      {left.map(item)}
      {/* Opens the add-job form straight away: no second menu to choose from. */}
      <button type="button" className="ksm-nav-item ksm-nav-add" onClick={onAddJob} aria-label="เพิ่มงาน">
        <span className="ksm-squirrel"><SquirrelAdd /></span>
        <span>เพิ่มงาน</span>
      </button>
      {right.map(item)}
    </nav>
  );
}

/** One entry. `value` shows on the right (e.g. the current language); `soon` marks something not open yet: shown, not tappable. */
export type MobileTool = { key: string; title: string; description: string; icon: KsIconName; search?: string; value?: string; soon?: boolean; onOpen: () => void };
/** A section of the menu. A section with a single entry opens it straight away instead of expanding. */
export type MobileToolGroup = { id: string; number?: string; name: string; sub: string; icon: KsIconName; items: MobileTool[] };

const SOON = 'เร็ว ๆ นี้';

export function MobileMenuPage({ groups, account, workspace }: {
  groups: MobileToolGroup[];
  account: { name: string; detail: string; avatarUrl?: string; onOpen: () => void };
  workspace?: React.ReactNode;
}) {
  const [query, setQuery] = React.useState('');
  const [open, setOpen] = React.useState<string | null>(null);
  const q = query.trim().toLocaleLowerCase();
  const found = q ? groups.flatMap(group => group.items.map(tool => ({ group, tool }))).filter(({ group, tool }) => `${group.name} ${tool.title} ${tool.description} ${tool.search || ''}`.toLocaleLowerCase().includes(q)) : [];
  const trailing = (tool: MobileTool) => (tool.soon
    ? <span className="ksm-soon">{SOON}</span>
    : <>{tool.value && <span className="ksm-row-value">{tool.value}</span>}<KsIcon name="chevron" size={16} /></>);
  const row = (tool: MobileTool, description = tool.description) => (
    <button key={tool.key} type="button" className={`ksm-row${tool.soon ? ' is-soon' : ''}`} onClick={tool.soon ? undefined : tool.onOpen}
      aria-disabled={tool.soon || undefined} aria-label={tool.soon ? `${tool.title} · ${SOON}` : undefined}>
      <span className="ksm-row-icon"><KsIcon name={tool.icon} size={19} /></span>
      <span className="ksm-grow"><b>{tool.title}</b>{description && <p>{description}</p>}</span>
      {trailing(tool)}
    </button>
  );
  const heading = (group: MobileToolGroup, sub = group.sub) => (
    <>
      <span className="ksm-group-symbol"><KsIcon name={group.icon} size={20} /></span>
      <span className="ksm-grow">{group.number && <i className="ksm-group-number">{group.number}</i>}<b>{group.name}</b><small>{sub}</small></span>
    </>
  );
  return (
    <div className="ksm ksm-layer" role="region" aria-label="เครื่องมือทั้งหมด">
      <section className="ksm-page">
        <div className="ksm-title"><h2>เมนู</h2></div>
        <button type="button" className="ksm-account" onClick={account.onOpen}>
          <span className="ksm-avatar">{account.avatarUrl ? <img src={account.avatarUrl} alt="" /> : account.name.slice(0, 2)}</span>
          <span className="ksm-grow"><b>{account.name}</b><small>{account.detail}</small></span>
          <KsIcon name="chevron" size={17} />
        </button>
        <div className="ksm-search">
          <KsIcon name="search" />
          <input type="text" inputMode="search" autoComplete="off" value={query} onChange={event => setQuery(event.target.value)} placeholder="ค้นหา เช่น รายจ่าย ปฏิทิน เอกสาร" aria-label="ค้นหาเครื่องมือ" enterKeyHint="search" />
          {query && <button type="button" className="ksm-search-clear" onClick={() => setQuery('')} aria-label="ล้างคำค้น"><KsIcon name="close" size={17} /></button>}
        </div>
        <div aria-live="polite">
          {q ? (
            <>
              <p className="ksm-count">พบ {found.length} เครื่องมือ</p>
              <div className="ksm-panel">
                {found.length ? found.map(({ group, tool }) => row(tool, `${group.name} · ${tool.description}`)) : <p className="ksm-empty">ไม่พบเครื่องมือ ลองคำว่า รายจ่าย ปฏิทิน หรือเอกสาร</p>}
              </div>
            </>
          ) : (
            <div className="ksm-groups">
              {groups.map(group => {
                if (group.items.length === 1) {
                  const tool = group.items[0];
                  return (
                    <button key={group.id} type="button" className={`ksm-group ksm-group-direct${tool.soon ? ' is-soon' : ''}`} onClick={tool.soon ? undefined : tool.onOpen}
                      aria-disabled={tool.soon || undefined} aria-label={`${group.name}${tool.soon ? ` · ${SOON}` : ''}`}>
                      {/* The entry's own description: it says what this account can do there (e.g. no quotations in phase one). */}
                      {heading(group, tool.description || group.sub)}
                      {tool.soon ? <span className="ksm-soon">{SOON}</span> : <>{tool.value && <span className="ksm-row-value">{tool.value}</span>}<span className="ksm-group-chevron"><KsIcon name="chevron" size={17} /></span></>}
                    </button>
                  );
                }
                return (
                  <details key={group.id} className="ksm-group" open={open === group.id}
                    onToggle={event => { const isOpen = (event.currentTarget as HTMLDetailsElement).open; setOpen(current => (isOpen ? group.id : current === group.id ? null : current)); }}>
                    <summary>
                      {heading(group)}
                      <span className="ksm-group-chevron"><KsIcon name="chevron" size={17} /></span>
                    </summary>
                    <div className="ksm-group-body">{group.items.map(tool => row(tool))}</div>
                  </details>
                );
              })}
            </div>
          )}
        </div>
        {workspace && <div className="ksm-workspace">{workspace}</div>}
      </section>
    </div>
  );
}
