import React from 'react';
import { animate, useMotionValue, useReducedMotion, useTransform, type MotionValue } from 'motion/react';

// The phone overview's net-profit card shrinks into a 64px bar as the page scrolls (owner's brief,
// 2026-10-20). One scroll container (#main-content), no nested scrolling; the card is sticky at its
// top and keeps its full height in the layout, so resizing it never moves the scroll position. Every
// size follows the scroll offset through motion values: no React state per pixel.
//
// - Near the top the card is exactly as tall as the distance not yet scrolled, so its bottom edge
//   travels with the content under it; it is fully open at scrollTop 0.
// - Deep in the page a swipe down (after 36px of upward scrolling) opens it part way ("peek"), and a
//   swipe up (24px) closes it again; the thresholds stop short flicks from making it flutter.
// - When scrolling stops half way through the collapse, the page settles to fully open or fully
//   closed, in the direction the finger was going; a move under 40px goes back where it started.

export const COLLAPSED_HEIGHT = 64;
const PEEK_SHARE = 0.4;
const PEEK_OPEN = 36;
const PEEK_CLOSE = 24;
/** A gesture shorter than this inside the collapse goes back to where it started. */
const SETTLE_MIN = 40;
const EASE = [0.22, 1, 0.36, 1] as const;

const clamp01 = (value: number) => Math.min(1, Math.max(0, value));

export interface CollapsingCard {
  innerRef: React.RefObject<HTMLDivElement | null>;
  amountRef: React.RefObject<HTMLButtonElement | null>;
  labelRef: React.RefObject<HTMLDivElement | null>;
  rootRef: React.RefObject<HTMLDivElement | null>;
  /** The card's full height, 0 until measured. */
  expanded: number;
  height: MotionValue<number>;
  /** 0 = open, 1 = collapsed bar. */
  progress: MotionValue<number>;
  amountX: MotionValue<number>;
  amountY: MotionValue<number>;
  amountScale: MotionValue<number>;
  /** Scroll the page back to the top, which opens the card. */
  open: () => void;
}

export function useCollapsingCard(): CollapsingCard {
  const reduceMotion = useReducedMotion();
  const innerRef = React.useRef<HTMLDivElement>(null);
  const amountRef = React.useRef<HTMLButtonElement>(null);
  const labelRef = React.useRef<HTMLDivElement>(null);
  const rootRef = React.useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = React.useState(0);
  const expandedMv = useMotionValue(0);
  const scrollY = useMotionValue(0);
  const peek = useMotionValue(0);
  const target = React.useRef({ dx: 0, dy: 0, scale: 0.5 });
  const dx = useMotionValue(0);
  const dy = useMotionValue(0);
  const scaleTo = useMotionValue(0.5);

  const height = useTransform([scrollY, peek, expandedMv], ([y, k, full]: number[]) => {
    if (!full) return COLLAPSED_HEIGHT;
    const range = Math.max(0, full - COLLAPSED_HEIGHT);
    return Math.max(COLLAPSED_HEIGHT, full - y, COLLAPSED_HEIGHT + k * PEEK_SHARE * range);
  });
  const progress = useTransform([height, expandedMv], ([h, full]: number[]) =>
    (full > COLLAPSED_HEIGHT ? clamp01((full - h) / (full - COLLAPSED_HEIGHT)) : 0));
  const amountX = useTransform([progress, dx], ([p, x]: number[]) => p * x);
  const amountY = useTransform([progress, dy], ([p, y]: number[]) => p * y);
  const amountScale = useTransform([progress, scaleTo], ([p, s]: number[]) => 1 - p * (1 - s));

  // Measure the open card and where the figure goes in the bar: right-aligned, centred on the label row.
  React.useLayoutEffect(() => {
    const inner = innerRef.current;
    if (!inner) return;
    const offsetIn = (el: HTMLElement) => {
      let top = 0; let left = 0; let node: HTMLElement | null = el;
      while (node && node !== inner) { top += node.offsetTop; left += node.offsetLeft; node = node.offsetParent as HTMLElement | null; }
      return { top, left };
    };
    const measure = () => {
      const amount = amountRef.current; const label = labelRef.current;
      const full = inner.offsetHeight;
      if (amount && label) {
        const style = getComputedStyle(inner);
        const padRight = parseFloat(style.paddingRight) || 0;
        const strong = amount.querySelector('strong');
        const fontSize = strong ? parseFloat(getComputedStyle(strong).fontSize) || 42 : 42;
        const a = offsetIn(amount); const l = offsetIn(label);
        // 21px in the bar, smaller if a long figure would run into the label on a narrow phone.
        const text = (label.firstElementChild as HTMLElement | null) ?? label;
        const room = inner.clientWidth - padRight - (offsetIn(text).left + text.offsetWidth + 10);
        const scale = Math.max(0.3, Math.min(1, 21 / fontSize, room / Math.max(1, amount.offsetWidth)));
        target.current = {
          dx: inner.clientWidth - padRight - amount.offsetWidth * scale - a.left,
          dy: l.top + label.offsetHeight / 2 - (amount.offsetHeight * scale) / 2 - a.top,
          scale,
        };
        dx.set(target.current.dx); dy.set(target.current.dy); scaleTo.set(scale);
      }
      expandedMv.set(full);
      setExpanded(current => (current === full ? current : full));
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(inner);
    if (amountRef.current) observer.observe(amountRef.current);
    return () => observer.disconnect();
  }, [dx, dy, scaleTo, expandedMv]);

  React.useEffect(() => {
    const el = document.getElementById('main-content');
    if (!el || !expanded) return;
    const range = expanded - COLLAPSED_HEIGHT;
    // Enough room below the content for the card to close all the way, however short the page is.
    const fit = () => {
      const root = rootRef.current; if (!root) return;
      const style = getComputedStyle(el);
      const pads = (parseFloat(style.paddingTop) || 0) + (parseFloat(style.paddingBottom) || 0);
      root.style.minHeight = `${el.clientHeight - pads + range}px`;
    };
    fit();
    // Settle 160ms after the last scroll event (momentum included), never while a finger is still on
    // the screen. Not scrollend: wheels and trackpads fire it after every small step.
    let touching = false;
    let last = el.scrollTop; let travel = 0; let gestureStart = el.scrollTop; let retryTimer = 0; let peekOpen = false; let settleTimer = 0;
    let peekAnimation: { stop: () => void } | null = null;
    const setPeek = (open: boolean) => {
      if (open === peekOpen) return;
      peekOpen = open;
      peekAnimation?.stop();
      peekAnimation = animate(peek, open ? 1 : 0, { duration: reduceMotion ? 0 : open ? 0.32 : 0.26, ease: EASE });
    };
    const settle = () => {
      const y = el.scrollTop;
      const start = gestureStart;
      gestureStart = y;
      if (y <= 0 || y >= range) return;
      const short = Math.abs(y - start) < SETTLE_MIN;
      const toTop = short ? start < range / 2 : travel < 0;
      if (!toTop) setPeek(false);
      const top = toTop ? 0 : range;
      el.scrollTo({ top, behavior: reduceMotion ? 'auto' : 'smooth' });
      gestureStart = top;
      // The browser drops a smooth scroll asked for while a touch is still winding down: ask again
      // if the page has not moved at all.
      window.clearTimeout(retryTimer);
      retryTimer = window.setTimeout(() => { if (!touching && el.scrollTop === y) el.scrollTo({ top, behavior: reduceMotion ? 'auto' : 'smooth' }); }, 450);
    };
    const schedule = () => { window.clearTimeout(settleTimer); if (!touching) settleTimer = window.setTimeout(settle, 160); };
    const onTouchStart = () => { touching = true; window.clearTimeout(settleTimer); window.clearTimeout(retryTimer); };
    const onTouchEnd = () => { touching = false; schedule(); };
    const onScroll = () => {
      const y = el.scrollTop;
      const delta = y - last; last = y;
      if (delta !== 0) { if (Math.sign(delta) !== Math.sign(travel)) travel = 0; travel += delta; }
      scrollY.set(Math.max(0, y));
      if (y <= (1 - PEEK_SHARE) * range) { if (peekOpen) { peekAnimation?.stop(); peekOpen = false; peek.set(0); } }
      else if (y > range && travel <= -PEEK_OPEN) setPeek(true);
      else if (travel >= PEEK_CLOSE) setPeek(false);
      schedule();
    };
    // Coming back to the overview: the card matches wherever the page is, never stuck half way.
    scrollY.set(el.scrollTop); peek.set(0);
    el.addEventListener('scroll', onScroll, { passive: true });
    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchend', onTouchEnd, { passive: true });
    el.addEventListener('touchcancel', onTouchEnd, { passive: true });
    window.addEventListener('resize', fit);
    return () => {
      el.removeEventListener('scroll', onScroll);
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchend', onTouchEnd);
      el.removeEventListener('touchcancel', onTouchEnd);
      window.removeEventListener('resize', fit);
      window.clearTimeout(settleTimer);
      window.clearTimeout(retryTimer);
      peekAnimation?.stop();
      if (rootRef.current) rootRef.current.style.minHeight = '';
    };
  }, [expanded, peek, scrollY, reduceMotion]);

  const open = React.useCallback(() => {
    document.getElementById('main-content')?.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
  }, [reduceMotion]);

  return { innerRef, amountRef, labelRef, rootRef, expanded, height, progress, amountX, amountY, amountScale, open };
}
