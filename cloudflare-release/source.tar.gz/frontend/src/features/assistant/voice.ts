import React from 'react';

// Talking to เลขากระรอก with the browser's own speech tools: free, no Krarok Tokens. Speech to text uses the
// browser's recognition (Chrome sends the sound to Google to turn it into text; Safari uses Apple); reading
// an answer aloud uses the device's voices. Where a browser has neither, the buttons say so instead of failing.

type Recognition = {
  lang: string; continuous: boolean; interimResults: boolean;
  start(): void; stop(): void; abort(): void;
  onresult: ((event: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
};
type RecognitionClass = new () => Recognition;

const recognitionClass = (): RecognitionClass | null => {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as { SpeechRecognition?: RecognitionClass; webkitSpeechRecognition?: RecognitionClass };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
};
export const canListen = () => Boolean(recognitionClass());
export const canSpeak = () => typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance !== 'undefined';

export type ListenError = 'denied' | 'no-speech' | 'failed';

/**
 * Press to talk: words appear in the message box as they are heard (`onText` gets what was there before plus
 * what was said). Stops by itself after a pause, or when pressed again.
 */
export function useSpeechInput(lang: string, onText: (text: string) => void) {
  const [listening, setListening] = React.useState(false);
  const [error, setError] = React.useState<ListenError | null>(null);
  const ref = React.useRef<Recognition | null>(null);
  const onTextRef = React.useRef(onText); onTextRef.current = onText;
  React.useEffect(() => () => ref.current?.abort(), []);

  const stop = React.useCallback(() => { ref.current?.stop(); }, []);
  const start = React.useCallback((before: string) => {
    const Class = recognitionClass();
    if (!Class) { setError('failed'); return; }
    ref.current?.abort();
    const recognition = new Class();
    recognition.lang = lang;
    recognition.continuous = false;
    recognition.interimResults = true;
    const prefix = before.trim() ? `${before.trimEnd()} ` : '';
    recognition.onresult = event => {
      let heard = '';
      for (let i = 0; i < event.results.length; i += 1) heard += event.results[i][0]?.transcript ?? '';
      onTextRef.current(prefix + heard.trim());
    };
    recognition.onerror = event => {
      setError(event.error === 'not-allowed' || event.error === 'service-not-allowed' ? 'denied' : event.error === 'no-speech' ? 'no-speech' : event.error === 'aborted' ? null : 'failed');
    };
    recognition.onend = () => { setListening(false); if (ref.current === recognition) ref.current = null; };
    ref.current = recognition;
    setError(null);
    setListening(true);
    try { recognition.start(); } catch { setListening(false); setError('failed'); }
  }, [lang]);
  return { supported: canListen(), listening, error, start, stop, clearError: () => setError(null) };
}

/** Plain words for reading aloud: no Markdown marks, links read as their text. */
export const speakable = (markdown: string) => markdown
  .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
  .replace(/[*_`#>|~]+/g, ' ')
  .replace(/^\s*[-•]\s+/gm, '')
  .replace(/\s+/g, ' ')
  .trim();

/** Read one answer aloud (or stop if it is the one being read). Returns false when the device cannot speak. */
export function useReadAloud(lang: string) {
  const [speakingId, setSpeakingId] = React.useState<string | null>(null);
  React.useEffect(() => () => { if (canSpeak()) window.speechSynthesis.cancel(); }, []);
  const toggle = React.useCallback((id: string, text: string) => {
    if (!canSpeak()) return false;
    const synth = window.speechSynthesis;
    synth.cancel();
    if (speakingId === id) { setSpeakingId(null); return true; }
    const utterance = new SpeechSynthesisUtterance(speakable(text));
    utterance.lang = lang;
    const voice = synth.getVoices().find(item => item.lang?.toLowerCase().startsWith(lang.slice(0, 2).toLowerCase()));
    if (voice) utterance.voice = voice;
    utterance.onend = () => setSpeakingId(current => (current === id ? null : current));
    utterance.onerror = () => setSpeakingId(current => (current === id ? null : current));
    setSpeakingId(id);
    synth.speak(utterance);
    return true;
  }, [lang, speakingId]);
  return { supported: canSpeak(), speakingId, toggle };
}

export type PreparedFile = { name: string; mimeType: 'image/jpeg' | 'image/png' | 'image/webp' | 'application/pdf'; data: string; kind: 'image' | 'pdf'; bytes: number };
export const FILE_MAX_BYTES = 4 * 1024 * 1024;

const toBase64 = (buffer: ArrayBuffer) => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
};

/**
 * Ready a picked file for เลขา: pictures are redrawn at most 1600px wide as JPEG (smaller to send, and the
 * photo's hidden location data is dropped); a PDF goes as it is. Throws 'type' or 'size' for the screen to explain.
 */
export async function prepareFile(file: File): Promise<PreparedFile> {
  const name = file.name.slice(0, 120) || 'file';
  if (file.type === 'application/pdf') {
    if (file.size > FILE_MAX_BYTES) throw new Error('size');
    const buffer = await file.arrayBuffer();
    return { name, mimeType: 'application/pdf', data: toBase64(buffer), kind: 'pdf', bytes: buffer.byteLength };
  }
  if (!file.type.startsWith('image/')) throw new Error('type');
  if (file.size > 25 * 1024 * 1024) throw new Error('size');
  const bitmap = await createImageBitmap(file).catch(() => { throw new Error('type'); });
  const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d');
  if (!context) throw new Error('type');
  context.fillStyle = '#fff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.85));
  if (!blob) throw new Error('type');
  if (blob.size > FILE_MAX_BYTES) throw new Error('size');
  const buffer = await blob.arrayBuffer();
  return { name: name.replace(/\.[a-z0-9]+$/i, '') + '.jpg', mimeType: 'image/jpeg', data: toBase64(buffer), kind: 'image', bytes: buffer.byteLength };
}
