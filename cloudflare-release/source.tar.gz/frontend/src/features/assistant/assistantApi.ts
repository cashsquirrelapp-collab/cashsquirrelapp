import { tr } from '../../i18n/tr';
import { apiJson } from '../../services/api';
import { LOW_TOKENS, PAGE_HELP, SAMPLE_TOKENS, estimateTokens, pageHelpReply, sampleConversations, sampleReply, type ChatCard, type ChatMessage, type ConfirmCard, type Conversation, type TokenBalance } from './assistantMock';

// WHERE THE AI CONNECTS (next phase, done separately by the owner's team). The chat screen talks only to
// an AssistantTransport. Today it is createSampleTransport below, which never leaves the browser. To go
// live, write a transport that calls the backend (which holds the AI key) and pass it to AssistantChat:
//   send            -> stream the answer: call onDelta with each piece of text, resolve with the whole
//                      message, its cards and the tokens it used; reject (or throw) on a failed request
//                      so the chat shows its retry state.
//   conversations   -> the sidebar's history.
//   balance         -> the Pro token indicator (remaining / total / refill date).
//   confirm         -> carry out an action the user confirmed on a card (e.g. add a project).
//   remove          -> delete conversations from the history (called once the undo window has passed).
//   update          -> rename, pin or archive a conversation.
// Nothing here touches billing, stored data or LINE.

/** `context`: where the person is in the app (the floating squirrel sends the page it was opened on). */
/** `attachment`: a picture or PDF prepared by voice.ts prepareFile (live transport only). */
export type SendInput = { conversationId: string; text: string; history: ChatMessage[]; context?: { page: string; pageName: string }; attachment?: { name: string; mimeType: string; data: string } };
export type SendResult = { text: string; cards?: ChatCard[]; tokensUsed: number };

export interface AssistantTransport {
  /** True for the real เลขากระรอก (createLiveTransport): the screen drops its "sample" labels. */
  live?: boolean;
  send(input: SendInput, onDelta: (textSoFar: string) => void, signal: AbortSignal): Promise<SendResult>;
  conversations(): Promise<Conversation[]>;
  balance(): Promise<TokenBalance>;
  confirm(card: ConfirmCard, signal: AbortSignal): Promise<{ ok: boolean }>;
  /** Optional: delete conversations for good. The screen calls it only after its undo window. */
  remove?(conversationIds: string[]): Promise<void>;
  /** Optional: rename, pin or archive a conversation. */
  update?(conversationId: string, change: { title?: string; pinned?: boolean; archived?: boolean }): Promise<void>;
  /** Optional: the user pressed ยกเลิก on a confirmation card. */
  cancel?(card: ConfirmCard): Promise<void>;
}

export class AssistantRequestError extends Error {}

const wait = (ms: number, signal: AbortSignal) => new Promise<void>((resolve, reject) => {
  if (signal.aborted) { reject(new DOMException('aborted', 'AbortError')); return; }
  const timer = window.setTimeout(resolve, ms);
  signal.addEventListener('abort', () => { window.clearTimeout(timer); reject(new DOMException('aborted', 'AbortError')); }, { once: true });
});

const graphemes = (text: string): string[] => {
  const Seg = (Intl as unknown as { Segmenter?: new (locale: string, options: { granularity: 'grapheme' }) => { segment: (input: string) => Iterable<{ segment: string }> } }).Segmenter;
  return Seg ? Array.from(new Seg('th', { granularity: 'grapheme' }).segment(text), part => part.segment) : Array.from(text);
};

/** The sample transport for the screen preview: labelled sample answers, streamed like a real AI. */
export function createSampleTransport(options: { failSends: () => boolean; failActions: () => boolean; tokens: () => TokenBalance; instant: boolean }): AssistantTransport {
  return {
    async send(input, onDelta, signal) {
      await wait(options.instant ? 150 : 1300, signal);
      if (options.failSends()) throw new AssistantRequestError('offline');
      const answer = input.context && input.text.trim() === tr(PAGE_HELP) ? { text: pageHelpReply(input.context.page, input.context.pageName), cards: undefined } : sampleReply(input.text, `${input.conversationId}-${input.history.length}`);
      const parts = graphemes(answer.text);
      for (let shown = 0; shown < parts.length;) {
        shown = options.instant ? parts.length : Math.min(parts.length, shown + 3);
        onDelta(parts.slice(0, shown).join(''));
        if (shown < parts.length) await wait(24, signal);
      }
      return { text: answer.text, cards: answer.cards, tokensUsed: Math.min(options.tokens().remaining, estimateTokens(answer.text) + estimateTokens(input.text)) };
    },
    async conversations() { return sampleConversations(Date.now()); },
    async balance() { return { ...SAMPLE_TOKENS }; },
    async confirm(_card, signal) {
      await wait(options.instant ? 100 : 900, signal);
      return { ok: !options.failActions() };
    },
    // The sample history lives in the browser only, so there is nothing to delete elsewhere.
    async remove() {},
    async update() {},
  };
}

export const tokenLevel = (balance: TokenBalance): 'ok' | 'low' | 'empty' =>
  balance.remaining <= 0 ? 'empty' : balance.remaining <= LOW_TOKENS ? 'low' : 'ok';

/** GET /api/assistant: whether เลขากระรอก is switched on for this account, and what is left. */
export type AssistantStatus = {
  enabled: boolean; plan: 'pro' | 'trial' | 'admin' | 'none';
  tokensLeft: number | null; trialLeft: number | null; resetsAt: string | null; tokenLimit: number | null; requestLimit: number | null;
};
export const readAssistantStatus = (account: string, signal?: AbortSignal) =>
  apiJson<AssistantStatus>('/api/assistant', { headers: { 'X-Account-ID': account }, signal });

type LiveReply = { text: string; cards?: ChatCard[]; tokens: number; tokensLeft: number | null; trialLeft: number | null };

/** What the token indicator shows: Pro's or the trial's tokens (the trial never refills), or (admins, no cap) a full ring. */
function balanceOf(status: AssistantStatus): TokenBalance {
  if (status.requestLimit !== null && status.tokenLimit === null) return { remaining: status.trialLeft ?? 0, total: status.requestLimit, refillsOn: '' };
  if (status.tokenLimit === null) return { remaining: SAMPLE_TOKENS.total, total: SAMPLE_TOKENS.total, refillsOn: status.resetsAt ?? '' };
  return { remaining: status.tokensLeft ?? 0, total: status.tokenLimit, refillsOn: status.resetsAt ?? '' };
}

/**
 * The real เลขากระรอก: the backend (/api/assistant) runs the AI with the key it holds, charges Krarok Tokens and
 * returns cards; a confirmation card is saved only when the user presses ยืนยัน. The answer arrives whole and is
 * typed out like the sample. Chat history lives on this screen only (it is not saved yet).
 */
export function createLiveTransport(options: { account: string; status: AssistantStatus; instant: boolean; onApplied?: () => void }): AssistantTransport {
  const headers = { 'X-Account-ID': options.account };
  let balance = balanceOf(options.status);
  const post = <T,>(body: unknown, signal?: AbortSignal) => apiJson<T>('/api/assistant', { method: 'POST', headers, body: JSON.stringify(body), signal });
  return {
    live: true,
    async send(input, onDelta, signal) {
      const earlier = input.history.slice(0, -1).filter(message => !message.failed && message.text.trim())
        .slice(-12).map(message => ({ role: message.from === 'me' ? 'user' as const : 'assistant' as const, text: message.text.slice(0, 1000) }));
      let reply: LiveReply;
      try {
        reply = await post<LiveReply>({ action: 'message', text: input.text.slice(0, 2000), history: earlier, ...(input.context ? { pageName: input.context.pageName.slice(0, 40) } : {}), ...(input.attachment ? { attachment: input.attachment } : {}) }, signal);
      } catch (error) {
        const status = (error as { status?: number }).status;
        const code = (error as { code?: string }).code;
        // Plan, token and pause answers are messages for the person, not connection failures.
        if (status === 402 || status === 403 || (status === 503 && code !== 'ai_provider') || code?.startsWith('ai_file')) {
          const used = code === 'ai_tokens_used' || code === 'ai_trial_used' ? balance.remaining : 0;
          balance = { ...balance, remaining: balance.remaining - used };
          return { text: (error as Error).message, tokensUsed: used };
        }
        throw new AssistantRequestError((error as Error).message || 'offline');
      }
      const parts = graphemes(reply.text);
      for (let shown = 0; shown < parts.length;) {
        shown = options.instant ? parts.length : Math.min(parts.length, shown + 3);
        onDelta(parts.slice(0, shown).join(''));
        if (shown < parts.length) await wait(18, signal);
      }
      const remaining = reply.tokensLeft ?? reply.trialLeft ?? balance.remaining;
      const used = Math.max(0, balance.remaining - remaining);
      balance = { ...balance, remaining };
      return { text: reply.text, cards: reply.cards, tokensUsed: used };
    },
    // Only the automatic-notifications thread (still a labelled sample); new chats start empty.
    async conversations() { return sampleConversations(Date.now()).filter(conversation => conversation.kind === 'line'); },
    async balance() { return { ...balance }; },
    async confirm(card, signal) {
      try {
        await post<{ status: string }>({ action: 'confirm', proposalId: card.id }, signal);
        options.onApplied?.();
        return { ok: true };
      } catch { return { ok: false }; }
    },
    async cancel(card) { await post({ action: 'cancel', proposalId: card.id }).catch(() => undefined); },
    async remove() {},
    async update() {},
  };
}
