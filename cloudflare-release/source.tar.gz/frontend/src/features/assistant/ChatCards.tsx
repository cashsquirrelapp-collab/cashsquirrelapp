import React from 'react';
import { AlertCircle, ArrowUpRight, BarChart3, Briefcase, Check, CheckCircle2, FileText, ListChecks, Loader2, Pencil, Send, X } from 'lucide-react';
import { tr } from '../../i18n/tr';
import type { ChatCard, ConfirmCard, DocumentCard, ProjectCard, QuestionsCard, SummaryCard } from './assistantMock';
import { LineCard } from './LineCard';
import type { LineDueAction, LineItem } from './lineMock';

// Result cards inside an answer (brief §6): a project, a document, a money summary and a confirmation.
// With the sample transport they carry sample data and say so, and a confirmation changes nothing. With the
// live transport they show the account's own data, and ยืนยัน saves the change through the backend.

export type ConfirmState = 'pending' | 'working' | 'done' | 'failed' | 'cancelled' | 'expired';

const SampleTag = () => <span className="asx-card-tag">{tr("ข้อมูลตัวอย่าง")}</span>;

// Real answers (the live transport) carry the account's own data, so they lose the sample tag.
const LiveContext = React.createContext(false);

function Head({ icon: Icon, title }: { icon: typeof Briefcase; title: string }) {
  const live = React.useContext(LiveContext);
  return <div className="asx-rcard-head"><span className="asx-rcard-icon"><Icon size={16} strokeWidth={1.9} /></span><b>{title}</b>{!live && <SampleTag />}</div>;
}

function Rows({ rows }: { rows: { label: string; value: string; tone?: 'income' | 'expense' }[] }) {
  return (
    <dl className="asx-rcard-rows">
      {rows.map(row => <div key={row.label}><dt>{row.label}</dt><dd className={row.tone ? `is-${row.tone}` : undefined}>{row.value}</dd></div>)}
    </dl>
  );
}

function Project({ card, onNavigate }: { card: ProjectCard; onNavigate: (path: string) => void }) {
  return (
    <div className="asx-rcard">
      <Head icon={Briefcase} title={tr("โปรเจกต์")} />
      <Rows rows={[{ label: tr("ชื่องาน"), value: card.name }, { label: tr("ลูกค้า"), value: card.client }, { label: tr("มูลค่างาน"), value: card.amount }, { label: tr("สถานะ"), value: card.status }]} />
      <div className="asx-rcard-actions"><button type="button" className="asx-pill-btn" onClick={() => onNavigate('/jobs')}>{tr("ตรวจสอบในหน้างาน")}<ArrowUpRight size={14} /></button></div>
    </div>
  );
}

function Document({ card, onNavigate }: { card: DocumentCard; onNavigate: (path: string) => void }) {
  return (
    <div className="asx-rcard">
      <Head icon={FileText} title={card.docType} />
      <Rows rows={[{ label: tr("เลขที่เอกสาร"), value: card.number }, { label: tr("ลูกค้า"), value: card.client }, { label: tr("ยอดเงิน"), value: card.amount }]} />
      <div className="asx-rcard-actions"><button type="button" className="asx-pill-btn" onClick={() => onNavigate(card.path)}>{tr("เปิดในแอป")}<ArrowUpRight size={14} /></button></div>
    </div>
  );
}

function Summary({ card }: { card: SummaryCard }) {
  return (
    <div className="asx-rcard">
      <Head icon={BarChart3} title={tr("สรุปการเงิน")} />
      <p className="asx-rcard-period">{card.period}</p>
      <Rows rows={[{ label: tr("รายรับ"), value: card.income, tone: 'income' }, { label: tr("รายจ่าย"), value: card.expense, tone: 'expense' }, { label: tr("เงินคงเหลือ"), value: card.balance }]} />
    </div>
  );
}

const choiceLabel = (option: string) => (option === '0' ? tr("ไม่หัก") : `${option}%`);

function Confirm({ card, state, onConfirm, onCancel, confirmedPath, onNavigate, onRevise }: { card: ConfirmCard; state: ConfirmState; onConfirm: () => void; onCancel: () => void; confirmedPath?: string; onNavigate: (path: string) => void; onRevise?: (card: ConfirmCard, edits: Record<string, string>) => Promise<void> }) {
  const live = React.useContext(LiveContext);
  // Change fields right on the card before confirming (owner, 2026-10-24); the card is prepared again with them.
  const [editing, setEditing] = React.useState(false);
  const [values, setValues] = React.useState<Record<string, string>>({});
  const [saving, setSaving] = React.useState(false);
  const [problem, setProblem] = React.useState<string | null>(null);
  const fields = card.edit ?? [];
  const canEdit = live && Boolean(onRevise) && fields.length > 0 && state === 'pending';
  const box = React.useRef<HTMLDivElement>(null);
  // The card grows while editing: bring all of it above the message box, so its buttons are never under the dock.
  React.useEffect(() => { if (editing) requestAnimationFrame(() => box.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })); }, [editing]);
  const startEdit = () => { setValues(Object.fromEntries(fields.map(field => [field.field, field.value]))); setProblem(null); setEditing(true); };
  const saveEdit = async () => {
    const changed = Object.fromEntries(fields.filter(field => (values[field.field] ?? '') !== field.value).map(field => [field.field, values[field.field] ?? '']));
    if (!Object.keys(changed).length) { setEditing(false); return; }
    setSaving(true); setProblem(null);
    try { await onRevise!(card, changed); setEditing(false); }
    catch (error) { setProblem((error as Error)?.message || tr("แก้รายการนี้ไม่สำเร็จ")); }
    finally { setSaving(false); }
  };
  return (
    <div ref={box} className={`asx-rcard is-confirm is-${state}${editing ? ' is-editing' : ''}`}>
      <Head icon={CheckCircle2} title={card.title} />
      {editing ? (
        <div className="asx-edit-list">
          {fields.map(field => (
            <label key={field.field} className="asx-edit-row">
              <span>{field.label}</span>
              {field.type === 'choice' ? (
                <select value={values[field.field] ?? ''} onChange={event => setValues(state => ({ ...state, [field.field]: event.target.value }))} disabled={saving}>
                  {(field.options ?? []).map(option => <option key={option} value={option}>{choiceLabel(option)}</option>)}
                </select>
              ) : (
                <input type={field.type === 'date' ? 'date' : 'text'} inputMode={field.type === 'money' ? 'decimal' : undefined} value={values[field.field] ?? ''} disabled={saving} maxLength={200}
                  onChange={event => setValues(state => ({ ...state, [field.field]: event.target.value }))}
                  onKeyDown={event => { if (event.key === 'Enter' && !event.nativeEvent.isComposing) { event.preventDefault(); void saveEdit(); } }} />
              )}
            </label>
          ))}
          {problem && <p className="asx-edit-problem" role="alert"><AlertCircle size={14} />{problem}</p>}
        </div>
      ) : <Rows rows={card.changes} />}
      {editing ? (
        <div className="asx-rcard-actions">
          <button type="button" className="asx-pill-btn" onClick={() => { setEditing(false); setProblem(null); }} disabled={saving}>{tr("ไม่แก้แล้ว")}</button>
          <button type="button" className="asx-pill-btn is-primary" onClick={() => void saveEdit()} disabled={saving}>
            {saving && <Loader2 size={14} className="animate-spin" />}{tr("ใช้ค่านี้")}
          </button>
        </div>
      ) : state === 'pending' || state === 'working' ? (
        <div className="asx-rcard-actions">
          {canEdit && <button type="button" className="asx-pill-btn asx-edit-btn" onClick={startEdit}><Pencil size={14} />{tr("แก้ไข")}</button>}
          <button type="button" className="asx-pill-btn" onClick={onCancel} disabled={state === 'working'}>{tr("ยกเลิก")}</button>
          <button type="button" className="asx-pill-btn is-primary" onClick={onConfirm} disabled={state === 'working'}>
            {state === 'working' && <Loader2 size={14} className="animate-spin" />}{tr("ยืนยัน")}
          </button>
        </div>
      ) : (
        <p className={`asx-rcard-result is-${state}`} role="status">
          {state === 'done' && <><CheckCircle2 size={16} />{live ? tr("บันทึกแล้ว") : tr("ยืนยันแล้ว (ตัวอย่าง) · ยังไม่มีการเปลี่ยนแปลงข้อมูลจริง")}{confirmedPath && <button type="button" className="asx-link-btn" onClick={() => onNavigate(confirmedPath)}>{tr('เปิดเอกสาร')}</button>}</>}
          {state === 'failed' && <><AlertCircle size={16} />{tr("ทำรายการไม่สำเร็จ")}<button type="button" className="asx-link-btn" onClick={onConfirm}>{tr("ลองอีกครั้ง")}</button></>}
          {state === 'cancelled' && <><X size={16} />{tr("ยกเลิกรายการนี้แล้ว")}</>}
          {state === 'expired' && <><X size={16} />{tr("รายการนี้หมดเวลายืนยันแล้ว ขอให้เลขาเตรียมใหม่ได้")}</>}
        </p>
      )}
    </div>
  );
}

/**
 * Tap-to-answer questions: tap a choice (or type where only the user knows), then ส่งคำตอบ sends every answer as one
 * message and เลขา carries on. An older card, already answered or overtaken by the chat, stays read-only.
 */
function Questions({ card, onAnswer, answered }: { card: QuestionsCard; onAnswer?: (text: string) => void; answered?: boolean }) {
  const [picked, setPicked] = React.useState<Record<string, string>>({});
  const [typed, setTyped] = React.useState<Record<string, string>>({});
  const [sent, setSent] = React.useState(false);
  const done = sent || answered || !onAnswer;
  const valueOf = (id: string) => typed[id]?.trim() || picked[id] || '';
  const ready = card.questions.every(question => valueOf(question.id));
  const submit = () => {
    if (!ready || done) return;
    setSent(true);
    onAnswer?.(card.questions.map(question => `${question.text.replace(/[?？]\s*$/, '').trim()}: ${valueOf(question.id)}`).join('\n'));
  };
  return (
    <div className={`asx-rcard is-questions${done ? ' is-done' : ''}`}>
      <div className="asx-rcard-head"><span className="asx-rcard-icon"><ListChecks size={16} strokeWidth={1.9} /></span><b>{tr("เลือกคำตอบได้เลย")}</b></div>
      <div className="asx-q-list">
        {card.questions.map(question => (
          <fieldset key={question.id} className="asx-q" disabled={done}>
            <legend>{question.text}</legend>
            {question.options.length > 0 && (
              <div className="asx-q-options">
                {question.options.map(option => {
                  const on = !typed[question.id]?.trim() && picked[question.id] === option;
                  return (
                    <button key={option} type="button" className="asx-q-chip" aria-pressed={on}
                      onClick={() => { setPicked(state => ({ ...state, [question.id]: option })); setTyped(state => ({ ...state, [question.id]: '' })); }}>
                      {on && <Check size={14} strokeWidth={2.2} aria-hidden="true" />}{option}
                    </button>
                  );
                })}
              </div>
            )}
            {question.allowText && (
              <input className="asx-q-input" value={typed[question.id] ?? ''} maxLength={200} aria-label={question.text}
                placeholder={question.placeholder || (question.options.length ? tr("หรือพิมพ์เอง") : tr("พิมพ์คำตอบ"))}
                onChange={event => setTyped(state => ({ ...state, [question.id]: event.target.value }))}
                onKeyDown={event => { if (event.key === 'Enter' && !event.nativeEvent.isComposing) { event.preventDefault(); submit(); } }} />
            )}
          </fieldset>
        ))}
      </div>
      <div className="asx-rcard-actions">
        <button type="button" className="asx-pill-btn is-primary" onClick={submit} disabled={!ready || done}>
          {done ? <><Check size={14} />{tr("ส่งคำตอบแล้ว")}</> : <><Send size={14} />{tr("ส่งคำตอบ")}</>}
        </button>
      </div>
    </div>
  );
}

export function ChatCardView({ live = false, ...props }: {
  card: ChatCard; confirmState?: ConfirmState; confirmedPath?: string; onConfirm: (card: ConfirmCard) => void; onCancel: (card: ConfirmCard) => void; onNavigate: (path: string) => void;
  onLineDue?: (action: LineDueAction, item: LineItem) => void;
  /** Answers to a questions card, sent as the user's next message; `answered` makes an older card read-only. */
  onAnswer?: (text: string) => void; answered?: boolean;
  /** Fields changed on a confirmation card: the card is prepared again and replaced. */
  onRevise?: (card: ConfirmCard, edits: Record<string, string>) => Promise<void>;
  /** A real answer, not sample data. */
  live?: boolean;
}) {
  return <LiveContext.Provider value={live}><CardBody {...props} /></LiveContext.Provider>;
}

function CardBody({ card, confirmState, confirmedPath, onConfirm, onCancel, onNavigate, onLineDue, onAnswer, answered, onRevise }: {
  card: ChatCard; confirmState?: ConfirmState; confirmedPath?: string; onConfirm: (card: ConfirmCard) => void; onCancel: (card: ConfirmCard) => void; onNavigate: (path: string) => void;
  onLineDue?: (action: LineDueAction, item: LineItem) => void; onAnswer?: (text: string) => void; answered?: boolean;
  onRevise?: (card: ConfirmCard, edits: Record<string, string>) => Promise<void>;
}) {
  switch (card.kind) {
    case 'navigation': return <button type="button" className="asx-pill-btn asx-feature-link" onClick={() => onNavigate(card.path)}>{card.label}<ArrowUpRight size={14} aria-hidden="true" /></button>;
    case 'project': return <Project card={card} onNavigate={onNavigate} />;
    case 'document': return <Document card={card} onNavigate={onNavigate} />;
    case 'summary': return <Summary card={card} />;
    case 'confirm': return <Confirm card={card} state={confirmState ?? 'pending'} onConfirm={() => onConfirm(card)} onCancel={() => onCancel(card)} confirmedPath={confirmedPath} onNavigate={onNavigate} onRevise={onRevise} />;
    case 'line': return <LineCard card={card.card} onDue={onLineDue} onOpen={onNavigate} />;
    case 'questions': return <Questions card={card} onAnswer={onAnswer} answered={answered} />;
  }
}
