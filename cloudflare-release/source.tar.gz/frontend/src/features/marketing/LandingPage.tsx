import React, { lazy, Suspense } from 'react';
const KineticLanding = lazy(() => import('./kinetic/KineticLanding'));
export default function LandingPage({ onNavigate }: { onNavigate: (path: string) => void }) {
  return <Suspense fallback={<div aria-label="กำลังเปิดกระรอกตุนเงิน" style={{ minHeight: '100svh', background: '#faf8f3' }} />}><KineticLanding onNavigate={onNavigate} /></Suspense>;
}
