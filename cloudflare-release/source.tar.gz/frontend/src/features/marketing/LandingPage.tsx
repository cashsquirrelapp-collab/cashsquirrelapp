import React, { lazy, Suspense } from 'react';
const Landing = lazy(() => import('./editorial/Landing'));
export default function LandingPage(_props: { onNavigate: (path: string) => void }) {
  return <Suspense fallback={<div aria-label="กำลังเปิดกระรอกตุนเงิน" style={{minHeight:'100svh',background:'#FAF8F5'}} />}><Landing /></Suspense>;
}
