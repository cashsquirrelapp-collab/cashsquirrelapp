import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, Bell, Briefcase, CalendarDays, ChevronDown, CreditCard, FileText, LayoutDashboard,
  ListChecks, Menu, MessageCircle, PieChart, Receipt, RotateCcw, Wallet, X, Zap, type LucideIcon,
} from 'lucide-react';
import { BrandLockup } from '../../../components/brand/BrandLogo';
import './saas.css';
import { PRO_PRICING, formatBaht } from '../../../../../shared/proPricing';

// Landing page after the owner's reference (2026-10-20): split hero with the real desktop and phone
// screens, a feature bar that drives a product showcase, current features, reminders, LINE AI Pro,
// pricing, FAQ and a closing call to action. Product images are screenshots of the real app with
// example data (public/landing-v3, captured by artifacts/landing-v3/capture.mjs). Every claim matches
// what works today; what does not is marked "เร็ว ๆ นี้". The previous landing stays in ../editorial.

const LOGIN = '/login';
const SOON = 'เร็ว ๆ นี้';
const EASE = [0.22, 1, 0.36, 1] as const;

type ShowcaseKey = 'overview' | 'jobs' | 'receivables' | 'expenses' | 'calendar' | 'documents';
const SHOWCASE: { key: ShowcaseKey; tab: string; title: string; text: string; image: string; alt: string }[] = [
  { key: 'overview', tab: 'ภาพรวม', title: 'เห็นเงินทั้งเดือนในหน้าเดียว', text: 'มูลค่างาน เงินที่รับจริง รายจ่าย และกำไรสุทธิ', image: 'desktop-overview', alt: 'หน้าภาพรวมของกระรอกตุนเงิน' },
  { key: 'jobs', tab: 'งาน', title: 'ทุกงาน ทุกลูกค้า อยู่ในรายการเดียว', text: 'สถานะงาน การรับเงิน และเครดิตเทอมของแต่ละงาน', image: 'desktop-jobs', alt: 'หน้ารายการงาน' },
  { key: 'receivables', tab: 'เงินรอรับ', title: 'รู้ว่าเงินก้อนไหนยังไม่เข้า', text: 'เรียงตามวันครบกำหนด รับเงินบางส่วนหรือทั้งหมดได้ทันที', image: 'desktop-receivables', alt: 'หน้าเงินรอรับ' },
  { key: 'expenses', tab: 'รายจ่าย', title: 'จดรายจ่ายตามหมวด', text: 'ดูรายจ่ายทั้งเดือน รวมรายการประจำ', image: 'desktop-expenses', alt: 'หน้ารายจ่าย' },
  { key: 'calendar', tab: 'ปฏิทิน', title: 'วันส่งงานและวันรับเงินบนปฏิทิน', text: 'ดูเป็นเดือนหรือไทม์ไลน์ เห็นเงินที่จะเข้าในแต่ละวัน', image: 'desktop-calendar', alt: 'หน้าปฏิทิน' },
  { key: 'documents', tab: 'เอกสาร', title: 'ใบเสนอราคาถึงใบเสร็จ ในไม่กี่คลิก', text: 'ใบเสนอราคา ใบแจ้งหนี้ ใบเสร็จ และใบกำกับภาษี พร้อม PDF', image: 'desktop-documents', alt: 'หน้าเอกสาร' },
];

const FEATURE_BAR: { label: string; icon: LucideIcon; target: ShowcaseKey | 'reminders' }[] = [
  { label: 'ภาพรวมการเงิน', icon: PieChart, target: 'overview' },
  { label: 'จัดการงาน', icon: Briefcase, target: 'jobs' },
  { label: 'ติดตามเงินรอรับ', icon: Wallet, target: 'receivables' },
  { label: 'รายจ่าย', icon: Receipt, target: 'expenses' },
  { label: 'ปฏิทินและไทม์ไลน์', icon: CalendarDays, target: 'calendar' },
  { label: 'ใบเสนอราคาและใบเสร็จ', icon: FileText, target: 'documents' },
  { label: 'แจ้งเตือนกำหนดรับเงิน', icon: Bell, target: 'reminders' },
];

const FEATURES: { icon: LucideIcon; title: string; text: string }[] = [
  { icon: LayoutDashboard, title: 'ภาพรวมการเงิน', text: 'มูลค่างาน รับจริง รายจ่าย กำไรสุทธิ' },
  { icon: Briefcase, title: 'บันทึกและจัดการงาน', text: 'สถานะงาน ลูกค้า และเครดิตเทอม' },
  { icon: Wallet, title: 'ติดตามเงินที่ยังรอรับ', text: 'รับบางส่วนหรือรับครบ บันทึกได้ทันที' },
  { icon: Receipt, title: 'บันทึกรายจ่าย', text: 'แยกหมวด และรายจ่ายประจำ' },
  { icon: CalendarDays, title: 'ปฏิทินและไทม์ไลน์', text: 'วันส่งงานและวันครบกำหนดรับเงิน' },
  { icon: FileText, title: 'ใบเสนอราคา', text: 'สร้างและดาวน์โหลดเป็น PDF' },
  { icon: ListChecks, title: 'ใบเสร็จรับเงิน', text: 'ออกต่อจากงานที่รับเงินแล้ว' },
  { icon: Bell, title: 'เตือนก่อนครบกำหนดรับเงิน', text: 'เห็นงานที่ใกล้ถึงวันจ่าย' },
  { icon: Bell, title: 'เตือนเมื่อเลยกำหนด', text: 'งานที่ยังไม่ได้เงินไม่หลุดสายตา' },
];

// What the LINE official account does today (the webhook, the rich menu, and the owner's LINE
// FEATURE-STATUS hand-off of 2026-10-14). Needs Pro or the Pro trial, and a linked LINE account.
const LINE_TILES: { icon: LucideIcon; label: string }[] = [
  { icon: MessageCircle, label: 'พิมพ์สั้น ๆ\nตรวจแล้วค่อยบันทึก' },
  { icon: Wallet, label: 'ดูเงินรอรับ\nและสรุปเดือนนี้' },
  { icon: FileText, label: 'เรียกดูเอกสาร\nเปิด PDF ต่อได้' },
  { icon: Bell, label: 'เตือนงาน\nใกล้ครบกำหนด' },
];

const FREE: string[] = [
  'บันทึกงาน รายรับ และรายจ่าย',
  'ภาพรวม ปฏิทิน และไทม์ไลน์',
  'ติดตามเงินรอรับ พร้อมแจ้งเตือนในแอป',
  'ใบเสนอราคา ใบแจ้งหนี้ ใบเสร็จ ใบกำกับภาษี 10 ใบใหม่ต่อเดือน',
];
const PRO: { text: string; soon?: boolean }[] = [
  { text: 'ทุกฟีเจอร์พื้นฐาน' },
  { text: 'ออกเอกสารไม่จำกัด ไม่มีลายน้ำ' },
  { text: 'บันทึกงานผ่านแชต LINE' },
  { text: 'ดูงานค้างจ่ายและสรุปเดือนนี้ใน LINE' },
  { text: 'แจ้งเตือนทาง LINE และอีเมลตามที่ตั้งค่า' },
  { text: 'ผู้ช่วยการเงิน AI ใน LINE', soon: true },
  { text: 'ออกเอกสารผ่าน LINE', soon: true },
];

const FAQ: { q: string; a: string }[] = [
  { q: 'กระรอกตุนเงินเหมาะกับใคร?', a: 'ฟรีแลนซ์ ครีเอเตอร์ ติวเตอร์ และคนที่รับงานจากหลายลูกค้า แล้วอยากเห็นว่าเงินก้อนไหนเข้าแล้ว ก้อนไหนยังรอ' },
  { q: 'เริ่มใช้งานฟรีได้ไหม?', a: 'ได้ สมัครด้วย Google, Facebook หรืออีเมล ไม่ต้องใช้บัตร' },
  { q: 'Pro ต่างจาก Free อย่างไร?', a: 'Pro ออกเอกสารได้ไม่จำกัดและไม่มีลายน้ำ ใช้ผู้ช่วยใน LINE และรับแจ้งเตือนทาง LINE หรืออีเมลได้ ส่วน Free ออกเอกสารใหม่ได้ 10 ใบต่อเดือน' },
  { q: 'ออกใบเสนอราคาได้ไหม?', a: 'ได้ทั้ง Free และ Pro พร้อมใบแจ้งหนี้ ใบเสร็จ ใบกำกับภาษี และดาวน์โหลด PDF' },
  { q: 'เชื่อมต่อ LINE อย่างไร?', a: 'สมัคร Pro แล้วไปที่ ตั้งค่า > LINE กดเชื่อมต่อ แล้วทำตามขั้นตอนใน LINE' },
  { q: 'ยกเลิก Pro ได้ไหม?', a: 'ได้ทุกเมื่อจากหน้าแพ็กเกจ สิทธิ์ใช้ต่อได้ถึงสิ้นรอบที่ชำระแล้ว' },
];

function Reveal({ children, className, delay = 0, as = 'div', id }: { children: React.ReactNode; className?: string; delay?: number; as?: 'div' | 'section'; id?: string }) {
  const reduce = useReducedMotion();
  const Tag = as === 'section' ? motion.section : motion.div;
  return (
    <Tag id={id} className={className} initial={reduce ? false : { opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -12% 0px' }} transition={{ duration: 0.5, ease: EASE, delay }}>
      {children}
    </Tag>
  );
}

function Laptop({ src, alt }: { src: string; alt: string }) {
  return (
    <div className="sl-laptop" aria-label={alt} role="img">
      <div className="sl-laptop-screen"><img src={src} alt="" width={1440} height={900} /></div>
      <div className="sl-laptop-base" aria-hidden="true" />
    </div>
  );
}

function Phone({ children, label, className = '' }: { children: React.ReactNode; label: string; className?: string }) {
  return <div className={`sl-phone ${className}`} role="img" aria-label={label}><div className="sl-phone-screen">{children}</div></div>;
}

export default function SaasLanding() {
  const reduce = useReducedMotion();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [tab, setTab] = useState<ShowcaseKey>('overview');
  const [faqOpen, setFaqOpen] = useState<number | null>(0);
  const [petting, setPetting] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  // The app may have left the dark class on <html>; this page is light only.
  useEffect(() => {
    const root = document.documentElement; const wasDark = root.classList.contains('dark');
    root.classList.remove('dark');
    return () => { if (wasDark) root.classList.add('dark'); };
  }, []);

  const goTo = (target: ShowcaseKey | 'reminders') => {
    if (target !== 'reminders') setTab(target);
    document.getElementById(target === 'reminders' ? 'reminders' : 'showcase')?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
  };
  const active = SHOWCASE.find(item => item.key === tab) ?? SHOWCASE[0];
  const step = (delta: number) => setTab(current => SHOWCASE[(SHOWCASE.findIndex(item => item.key === current) + delta + SHOWCASE.length) % SHOWCASE.length].key);
  const nav = [{ href: '#features', text: 'ฟีเจอร์' }, { href: '#showcase', text: 'วิธีใช้งาน' }, { href: '#pricing', text: 'ราคา' }, { href: '#line-pro', text: 'Pro' }];
  const rise = (delay: number) => (reduce ? {} : { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.58, ease: EASE, delay } });

  return (
    <div className="sl">
      <a className="sl-skip" href="#sl-main">ข้ามไปเนื้อหา</a>
      <header className={`sl-nav${scrolled ? ' is-scrolled' : ''}`}>
        <div className="sl-wrap sl-nav-row">
          <a href="#top" className="sl-logo" aria-label="กระรอกตุนเงิน หน้าแรก"><BrandLockup size={30} /></a>
          <nav className="sl-nav-links" aria-label="เมนูหลัก">{nav.map(n => <a key={n.href} href={n.href}>{n.text}</a>)}</nav>
          <div className="sl-nav-actions">
            <a className="sl-login" href={LOGIN}>เข้าสู่ระบบ</a>
            <a className="sl-btn is-primary is-small" href={LOGIN}>เริ่มใช้งานฟรี <ArrowUpRight size={15} /></a>
            <button type="button" className="sl-menu-btn" aria-label={menuOpen ? 'ปิดเมนู' : 'เปิดเมนู'} aria-expanded={menuOpen} onClick={() => setMenuOpen(open => !open)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
        {menuOpen && <nav className="sl-mobile-links" aria-label="เมนู">{nav.map(n => <a key={n.href} href={n.href} onClick={() => setMenuOpen(false)}>{n.text}<ArrowRight size={16} /></a>)}<a href={LOGIN}>เข้าสู่ระบบ<ArrowUpRight size={16} /></a></nav>}
      </header>

      <main id="sl-main">
        <section id="top" className="sl-hero">
          <div className="sl-wrap sl-hero-grid">
            <div className="sl-hero-copy">
              <motion.p className="sl-eyebrow" {...rise(0)}><span />YOUR PERSONAL FINANCE ASSISTANT</motion.p>
              <motion.h1 {...rise(0.06)}>เรื่องเงินของคุณ<br /><em>เราช่วยดูแล</em></motion.h1>
              <motion.p className="sl-lead" {...rise(0.14)}>บันทึกงาน ติดตามเงิน จัดการรายจ่าย<br />และเอกสาร ทั้งหมดในที่เดียว</motion.p>
              <motion.div className="sl-cta-row" {...rise(0.22)}>
                <a className="sl-btn is-primary" href={LOGIN}>เริ่มใช้งานฟรี <ArrowRight size={17} /></a>
                <a className="sl-btn is-ghost" href="#showcase">ดูวิธีใช้งาน</a>
              </motion.div>
            </div>
            <motion.div className="sl-hero-visual" initial={reduce ? false : { opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease: EASE, delay: 0.18 }}>
              <span className="sl-hero-glow" aria-hidden="true" />
              <Laptop src="/landing-v3/desktop-overview.webp" alt="หน้าภาพรวมบนคอมพิวเตอร์" />
              <Phone className="sl-hero-phone" label="หน้าภาพรวมบนมือถือ"><img src="/landing-v3/phone-overview.webp" alt="" width={1170} height={2532} /></Phone>
              <img className="sl-hero-mascot" src="/line/mascot-v6-working.png" alt="" width={1024} height={1024} />
              <p className="sl-shot-note">ภาพจากแอปจริง · ข้อมูลตัวอย่าง</p>
            </motion.div>
          </div>
        </section>

        <div className="sl-wrap">
          <nav className="sl-featurebar" aria-label="ฟีเจอร์">
            {FEATURE_BAR.map(item => {
              const selected = item.target === tab;
              return (
                <button key={item.label} type="button" className={`sl-featurebar-item${selected ? ' is-selected' : ''}`} aria-pressed={selected} onClick={() => goTo(item.target)}>
                  <i className="sl-featurebar-icon"><item.icon size={21} strokeWidth={1.7} /></i>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <Reveal as="section" id="showcase" className="sl-section sl-showcase">
          <div className="sl-wrap sl-showcase-grid">
            <div className="sl-showcase-copy">
              <p className="sl-eyebrow"><span />WORKSPACE</p>
              <h2>ทุกเรื่องการเงิน<br />ในมุมมองเดียว</h2>
              <p className="sl-lead">ดูงาน รายรับ รายจ่าย<br />และเงินที่ต้องติดตามได้ง่ายขึ้น</p>
              <div className="sl-tabs" role="tablist" aria-label="เลือกหน้าที่อยากดู">
                {SHOWCASE.map(item => (
                  <button key={item.key} type="button" role="tab" aria-selected={tab === item.key} aria-controls="sl-showcase-panel" className="sl-tab" onClick={() => setTab(item.key)}>{item.tab}</button>
                ))}
              </div>
              <div className="sl-tab-text" aria-live="polite">
                <motion.div key={active.key} initial={reduce ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: EASE }}>
                  <h3>{active.title}</h3>
                  <p>{active.text}</p>
                </motion.div>
              </div>
              <div className="sl-stepper">
                <button type="button" aria-label="หน้าก่อนหน้า" onClick={() => step(-1)}><ArrowLeft size={18} /></button>
                <span className="sl-dots" aria-hidden="true">{SHOWCASE.map(item => <i key={item.key} className={item.key === tab ? 'is-active' : ''} />)}</span>
                <button type="button" aria-label="หน้าถัดไป" onClick={() => step(1)}><ArrowRight size={18} /></button>
              </div>
            </div>
            <div className="sl-showcase-stage">
            <div id="sl-showcase-panel" role="tabpanel" className="sl-browser">
              <div className="sl-browser-bar" aria-hidden="true"><i /><i /><i /></div>
              <div className="sl-browser-view">
                {SHOWCASE.map(item => (
                  <img key={item.key} className={item.key === tab ? 'is-active' : ''} src={`/landing-v3/${item.image}.webp`} alt={item.key === tab ? item.alt : ''}
                    aria-hidden={item.key !== tab} width={1440} height={900} loading={item.key === 'overview' ? 'eager' : 'lazy'} />
                ))}
              </div>
            </div>
            <Phone className="sl-showcase-phone" label="หน้าภาพรวมบนมือถือ"><img src="/landing-v3/phone-overview.webp" alt="" width={1170} height={2532} loading="lazy" /></Phone>
            <p className="sl-shot-note">ภาพจากแอปจริง · ข้อมูลตัวอย่าง</p>
            </div>
          </div>
        </Reveal>

        <Reveal as="section" id="features" className="sl-section">
          <div className="sl-wrap">
            <div className="sl-heading"><h2>ใช้ได้วันนี้</h2><p>ฟีเจอร์ที่เปิดให้ทุกบัญชี</p></div>
            <ul className="sl-feature-grid">
              {FEATURES.map(item => (
                <li key={item.title}><span className="sl-feature-icon"><item.icon size={20} strokeWidth={1.7} /></span><b>{item.title}</b><p>{item.text}</p></li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal as="section" id="reminders" className="sl-section sl-reminders">
          <div className="sl-wrap sl-reminders-grid">
            <div>
              <h2>เงินก้อนไหนต้องตาม<br /><em>กระรอกช่วยเตือน</em></h2>
              <p className="sl-lead">รู้ก่อนถึงกำหนดรับเงิน<br />และเมื่อมีงานที่เลยกำหนดแล้ว</p>
              <p className="sl-small">เห็นในแอปทุกบัญชี · Pro รับทาง LINE และอีเมลได้ตามที่ตั้งค่า</p>
            </div>
            <div className="sl-status-card" aria-label="ตัวอย่างสถานะ">
              <img className="sl-status-mascot" src="/line/mascot-v6-reminder.png" alt="" width={1024} height={1024} loading="lazy" />
              {[
                { client: 'ร้านกาแฟตัวอย่าง', amount: '฿7,000', state: 'ใกล้ครบกำหนด', detail: 'อีก 4 วัน', tone: 'soon' },
                { client: 'แบรนด์ตัวอย่าง A', amount: '฿6,500', state: 'เลยกำหนดรับเงิน', detail: 'เลยมา 2 วัน', tone: 'late' },
                { client: 'บริษัท ตัวอย่าง จำกัด', amount: '฿18,000', state: 'รับเงินแล้ว', detail: '14 ต.ค.', tone: 'paid' },
              ].map(row => (
                <div key={row.client} className="sl-status-row">
                  <span className="sl-grow"><b>{row.client}</b><small>{row.detail}</small></span>
                  <span className={`sl-chip is-${row.tone}`}>{row.state}</span>
                  <strong>{row.amount}</strong>
                </div>
              ))}
              <p className="sl-shot-note">ตัวอย่าง</p>
            </div>
          </div>
        </Reveal>

        <section id="line-pro" className="sl-line">
          <Reveal className="sl-wrap sl-line-grid">
            <div className="sl-line-copy">
              <span className="sl-pro-badge">Pro</span>
              <h2>เลขาการเงินของคุณ<br />อยู่ใน <span className="sl-line-word">LINE</span> ด้วย</h2>
              <p>คุยกับน้องกระรอกตุน บันทึกงาน<br />และเรียกดูข้อมูลการเงินได้ง่ายขึ้น</p>
              <a className="sl-btn is-light" href="#pricing">ดูรายละเอียด Pro <ArrowUpRight size={16} /></a>
              <p className="sl-line-terms">สำหรับ Pro หรือช่วงทดลองใช้ และบัญชีที่เชื่อม LINE แล้ว<br />ผู้ช่วย AI และการออกเอกสารผ่าน LINE · {SOON}</p>
            </div>
            <motion.div className="sl-line-phones" initial={reduce ? false : { y: 12, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} viewport={{ once: true }} transition={{ duration: 0.55, ease: EASE, delay: 0.1 }}>
              <img className="sl-line-phone is-back" src="/landing-v3/line-phone-reminder.webp" alt="การ์ดเตือนรับเงินใน LINE" width={630} height={1480} loading="lazy" />
              <img className="sl-line-phone is-front" src="/landing-v3/line-phone-draft.webp" alt="การ์ดตรวจรายการก่อนบันทึกใน LINE" width={630} height={1480} loading="lazy" />
              <p className="sl-shot-note is-light">การ์ด LINE จริง · ข้อมูลตัวอย่าง</p>
            </motion.div>
            <ul className="sl-line-tiles">
              {LINE_TILES.map(item => (
                <li key={item.label}><span><item.icon size={22} strokeWidth={1.7} /></span><b>{item.label.split('\n').map((line, i) => <React.Fragment key={line}>{i > 0 && <br />}{line}</React.Fragment>)}</b></li>
              ))}
            </ul>
          </Reveal>
        </section>

        <Reveal as="section" id="pricing" className="sl-section">
          <div className="sl-wrap">
            <div className="sl-heading"><h2>เริ่มฟรี<br /><em>พร้อมเมื่อไหร่ค่อยไปต่อ</em></h2></div>
            <div className="sl-plans">
              <article className="sl-plan">
                <p className="sl-plan-name">FREE</p>
                <p className="sl-plan-price"><strong>฿0</strong><span>/ เดือน</span></p>
                <ul>{FREE.map(text => <li key={text}>{text}</li>)}</ul>
                <a className="sl-btn is-ghost is-block" href={LOGIN}>เริ่มใช้งานฟรี <ArrowRight size={16} /></a>
              </article>
              <article className="sl-plan is-pro">
                <p className="sl-plan-name">PRO</p>
                <p className="sl-plan-price"><strong>{formatBaht(PRO_PRICING.month.total)}</strong><span>/ เดือน</span></p>
                <ul>{PRO.map(item => <li key={item.text} className={item.soon ? 'is-soon' : ''}>{item.text}{item.soon && <em>{SOON}</em>}</li>)}</ul>
                <button type="button" className="sl-btn is-primary is-block" disabled aria-disabled="true">สมัคร Pro · {SOON}</button>
              </article>
            </div>
          </div>
        </Reveal>

        <Reveal as="section" id="faq" className="sl-section">
          <div className="sl-wrap sl-faq-wrap">
            <h2>คำถามที่พบบ่อย</h2>
            <div className="sl-faq">
              {FAQ.map((item, index) => {
                const open = faqOpen === index;
                return (
                  <div key={item.q} className={`sl-faq-item${open ? ' is-open' : ''}`}>
                    <button type="button" aria-expanded={open} aria-controls={`sl-faq-${index}`} onClick={() => setFaqOpen(open ? null : index)}>{item.q}<ChevronDown size={18} /></button>
                    <div id={`sl-faq-${index}`} role="region" hidden={!open}><p>{item.a}</p></div>
                  </div>
                );
              })}
            </div>
          </div>
        </Reveal>

        <Reveal as="section" className="sl-section sl-final">
          <div className="sl-wrap sl-final-grid">
            <div className="sl-final-art">
              <button type="button" className={`sl-final-mascot${petting ? ' is-petting' : ''}`} aria-label="ทักทายน้องกระรอก"
                onClick={() => { setPetting(true); window.setTimeout(() => setPetting(false), 900); }}>
                <img src={petting ? '/line/mascot-v6-received.png' : '/line/mascot-v6-guide.png'} alt="" width={1024} height={1024} loading="lazy" />
              </button>
              <span className="sl-final-note" aria-hidden="true">ให้เรื่องเงิน<br />เป็นเรื่องง่ายขึ้น</span>
            </div>
            <div className="sl-final-copy">
              <h2>พร้อมให้เราช่วยดูแล<br /><em>เรื่องเงินของคุณแล้วหรือยัง?</em></h2>
              <a className="sl-btn is-primary is-wide" href={LOGIN}>เริ่มใช้งานฟรี <ArrowRight size={17} /></a>
              <ul className="sl-trust">
                <li><Zap size={16} />เริ่มใช้งานได้ทันที</li>
                <li><CreditCard size={16} />ไม่ต้องใช้บัตรเครดิต</li>
                <li><RotateCcw size={16} />ยกเลิก Pro ได้ทุกเมื่อ</li>
              </ul>
            </div>
          </div>
        </Reveal>
      </main>

      <footer className="sl-footer">
        <div className="sl-wrap sl-footer-row">
          <BrandLockup size={26} />
          <nav aria-label="ลิงก์ท้ายหน้า">
            <a href="#features">ฟีเจอร์</a><a href="#pricing">ราคา</a><a href="#showcase">วิธีใช้งาน</a><a href="#line-pro">Pro</a>
            <a href="#faq">คำถามที่พบบ่อย</a><a href="/privacy">ติดต่อเรา</a><a href="/terms">ข้อกำหนดการใช้งาน</a><a href="/privacy">นโยบายความเป็นส่วนตัว</a>
          </nav>
        </div>
      </footer>
    </div>
  );
}
