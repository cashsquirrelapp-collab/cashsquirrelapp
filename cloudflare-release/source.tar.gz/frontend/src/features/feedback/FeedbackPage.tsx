import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowRight, Check, LoaderCircle, MessageSquare, Send } from 'lucide-react';
import { FEEDBACK_MAX_BODY_LENGTH, type FeedbackCategory } from '../../../../shared/feedback';
import { uiPrimaryButton, uiSurface } from '../../components/ui/uiStyles';
import { useLanguage } from '../../i18n/LanguageContext';
import { feedbackApi } from '../../services/feedback';
import FeedbackInbox from './FeedbackInbox';
import { categoryLabels, feedbackError, feedbackErrorClass, feedbackSuccessClass } from './feedbackUi';

type Props = { userId: string; isGuest: boolean; onSignIn?: () => void };

function FeedbackForm({ userId }: { userId: string }) {
  const { language } = useLanguage();
  const copy = (th: string, en: string) => language === 'th' ? th : en;
  const [body, setBody] = useState('');
  const [category, setCategory] = useState<FeedbackCategory | ''>('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const locked = useRef(false);
  const mounted = useRef(true);
  const textarea = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const message = body.trim();
    if (locked.current || !message || message.length > FEEDBACK_MAX_BODY_LENGTH) return;
    locked.current = true;
    setSaving(true);
    setError('');
    setNotice('');
    try {
      await feedbackApi.create(userId, message, category || undefined);
      if (!mounted.current) return;
      setBody('');
      setCategory('');
      setRefreshKey(value => value + 1);
      setNotice(copy('ส่งข้อความแล้ว ขอบคุณที่ช่วยพัฒนาแอป ทีมงานจะตอบกลับในหน้านี้', 'Message sent. Thank you for helping improve the app. The team will reply on this page.'));
    } catch (cause) {
      if (mounted.current) setError(feedbackError(cause, language));
    } finally {
      locked.current = false;
      if (mounted.current) { setSaving(false); textarea.current?.focus(); }
    }
  }

  return <div className="space-y-5">
    <section className={`${uiSurface} p-5 sm:p-6`} aria-labelledby="new-feedback-title">
      <div className="flex items-center gap-2.5"><span className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand-blue-bg text-brand-blue-acc"><MessageSquare size={18} aria-hidden="true" /></span><h2 id="new-feedback-title" className="text-base font-semibold">{copy('มีอะไรอยากบอกเรา?', 'What would you like to share?')}</h2></div>
      <p className="mt-3 text-sm leading-relaxed text-brand-muted">{copy('แจ้งปัญหาที่พบ หรือเสนอไอเดียที่อยากให้เพิ่ม เล่าให้ทีมงานฟังได้เลย', 'Report a problem or suggest something you would like us to add.')}</p>
      <form onSubmit={submit} className="mt-5 space-y-4">
        <div className="max-w-sm"><label htmlFor="feedback-category" className="mb-1.5 block text-sm font-medium">{copy('ประเภท', 'Category')} <span className="font-normal text-brand-muted">{copy('(ไม่จำเป็น)', '(optional)')}</span></label><select id="feedback-category" value={category} disabled={saving} className="ui-input" onChange={event => setCategory(event.target.value as FeedbackCategory | '')}><option value="">{copy('เลือกประเภท', 'Choose a category')}</option>{Object.entries(categoryLabels).map(([value, labels]) => <option key={value} value={value}>{labels[language === 'th' ? 0 : 1]}</option>)}</select></div>
        <div><label htmlFor="feedback-message" className="mb-1.5 block text-sm font-medium">{copy('ข้อความ', 'Message')}</label><textarea ref={textarea} id="feedback-message" value={body} onChange={event => setBody(event.target.value)} disabled={saving} required maxLength={FEEDBACK_MAX_BODY_LENGTH} rows={5} aria-describedby="feedback-message-hint feedback-message-count" className="ui-input min-h-36 resize-y" placeholder={copy('เช่น หน้าที่พบปัญหา สิ่งที่ทำก่อนเกิดปัญหา หรือไอเดียที่อยากให้มี…', 'For example, where the problem occurred, what you were doing, or an idea you would like to see…')} onKeyDown={event => { if ((event.ctrlKey || event.metaKey) && event.key === 'Enter' && !event.nativeEvent.isComposing) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} /><div className="mt-2 flex flex-wrap justify-between gap-2"><p id="feedback-message-hint" className="text-xs leading-relaxed text-brand-muted">{copy('ไม่ต้องใส่รหัสผ่านหรือข้อมูลการชำระเงิน', 'Please leave out passwords and payment details.')}</p><p id="feedback-message-count" className="text-xs tabular-nums text-brand-muted">{body.length.toLocaleString()} / {FEEDBACK_MAX_BODY_LENGTH.toLocaleString()} {copy('ตัวอักษร', 'characters')}</p></div></div>
        {error && <p role="alert" className={feedbackErrorClass}>{error}</p>}
        {notice && <p role="status" className={`flex items-start gap-2 ${feedbackSuccessClass}`}><Check size={17} className="mt-0.5 shrink-0" aria-hidden="true" />{notice}</p>}
        <div className="flex flex-wrap items-center justify-between gap-3"><p className="text-xs text-brand-muted">{copy('อ่านข้อความตอบกลับได้ในรายการด้านล่าง', 'Replies will appear in your conversations below.')}</p><button type="submit" className={`${uiPrimaryButton} w-full sm:w-auto`} disabled={saving || !body.trim()}>{saving ? <LoaderCircle size={16} className="animate-spin" /> : <Send size={16} />}{saving ? copy('กำลังส่ง…', 'Sending…') : copy('ส่งข้อความถึงทีมงาน', 'Send to the team')}</button></div>
      </form>
    </section>
    <FeedbackInbox userId={userId} refreshKey={refreshKey} />
  </div>;
}

export default function FeedbackPage({ userId, isGuest, onSignIn }: Props) {
  const { language } = useLanguage();
  const copy = (th: string, en: string) => language === 'th' ? th : en;
  return <section aria-labelledby="feedback-page-title" className="mx-auto w-full max-w-4xl space-y-5 pb-8">
    <header className="ui-page-header"><div className="min-w-0"><h1 id="feedback-page-title" className="ui-page-title">{copy('ข้อเสนอแนะ', 'Feedback')}</h1><p className="ui-page-description">{copy('ช่วยกันทำให้แอปใช้ง่ายขึ้น ส่งข้อความและคุยกับทีมงานได้ที่นี่', 'Help make the app better. Share feedback and talk with the team here.')}</p></div></header>
    {isGuest ? <div className={`${uiSurface} px-6 py-12 text-center`}><span className="mx-auto grid size-14 place-items-center rounded-2xl bg-brand-blue-bg text-brand-blue-acc"><MessageSquare size={26} aria-hidden="true" /></span><h2 className="mt-5 text-lg font-semibold">{copy('เข้าสู่ระบบเพื่อคุยกับทีมงาน', 'Sign in to talk with the team')}</h2><p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-brand-muted">{copy('ใช้บัญชีจริงเพื่อส่งข้อเสนอแนะ เก็บประวัติการสนทนา และกลับมาอ่านคำตอบจากทีมงาน โหมดทดลองยังส่งข้อความไม่ได้', 'Use an account to send feedback, keep your conversations, and read replies from the team. Guest mode cannot send messages.')}</p>{onSignIn && <button type="button" className={`${uiPrimaryButton} mt-6`} onClick={onSignIn}>{copy('เข้าสู่ระบบ / สมัครสมาชิก', 'Sign in / Create an account')}<ArrowRight size={16} /></button>}</div> : <FeedbackForm key={userId} userId={userId} />}
  </section>;
}
