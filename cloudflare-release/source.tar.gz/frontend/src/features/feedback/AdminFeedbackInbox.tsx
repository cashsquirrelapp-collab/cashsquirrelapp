import FeedbackInbox from './FeedbackInbox';

export default function AdminFeedbackInbox({ userId }: { userId: string }) {
  return <FeedbackInbox key={userId} userId={userId} admin />;
}
