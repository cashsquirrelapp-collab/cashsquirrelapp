import React from 'react';
import { loadStripe } from '@stripe/stripe-js/pure';
import type { StripeCheckoutLoadActionsSuccess, StripePaymentElement } from '@stripe/stripe-js';
import { CreditCard, LockKeyhole } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { uiPrimaryButton } from '../../components/ui/uiStyles';
import { renewalConsentText, type CardOptions } from '../../../../shared/cardConsent';
import type { EmbeddedPayment } from './EmbeddedPaymentModal';

export function CardPaymentModal({ checkout, busy, onOptions, onClose, onComplete }: {
  checkout: EmbeddedPayment; busy: boolean;
  onOptions: (options: Pick<CardOptions, 'autoRenew' | 'saveCard'>) => void;
  onClose: () => void; onComplete: () => void;
}) {
  const mount = React.useRef<HTMLDivElement>(null);
  const actions = React.useRef<StripeCheckoutLoadActionsSuccess | null>(null);
  const [ready, setReady] = React.useState(false);
  const [paying, setPaying] = React.useState(false);
  const [completed, setCompleted] = React.useState(false);
  const [error, setError] = React.useState('');
  const [changed, setChanged] = React.useState(false);
  const amount = (checkout.amount / 100).toLocaleString('th-TH');
  const duration = checkout.months === 12 ? '1 ปี' : `${checkout.months} เดือน`;
  React.useEffect(() => {
    let canceled = false;
    let payment: StripePaymentElement | undefined;
    actions.current = null;
    setReady(false); setError('');
    void (async () => {
      const stripe = await loadStripe(checkout.publishableKey, { locale: 'th' });
      if (canceled) return;
      if (!stripe) throw new Error('โหลดช่องกรอกบัตรไม่สำเร็จ');
      const dark = document.documentElement.classList.contains('dark');
      const sdk = stripe.initCheckoutElementsSdk({
        clientSecret: checkout.clientSecret,
        elementsOptions: {
          savedPaymentMethod: { enableSave: 'never', enableRedisplay: 'auto' },
          appearance: {
            theme: dark ? 'night' : 'stripe',
            variables: { colorPrimary: '#ffa66b', colorBackground: dark ? '#202124' : '#ffffff',
              colorText: dark ? '#f3f1ef' : '#292524', colorDanger: '#ef4444',
              borderRadius: '12px', fontFamily: 'system-ui, sans-serif', spacingUnit: '4px' },
          },
        },
      });
      const loaded = await sdk.loadActions();
      if (canceled) return;
      if (loaded.type !== 'success') throw new Error('โหลดหน้าชำระไม่สำเร็จ กรุณาลองใหม่');
      actions.current = loaded.actions;
      payment = sdk.createPaymentElement({ layout: 'tabs' });
      payment.on('ready', () => { if (!canceled) setReady(true); });
      payment.on('loaderror', () => { if (!canceled) setError('โหลดช่องกรอกบัตรไม่สำเร็จ กรุณาเปิดหน้านี้อีกครั้ง'); });
      if (mount.current) payment.mount(mount.current);
    })().catch(e => { if (!canceled) setError(e.message || 'โหลดหน้าชำระไม่สำเร็จ'); });
    return () => { canceled = true; actions.current = null; payment?.destroy(); };
  }, [checkout.clientSecret, checkout.publishableKey]);
  const confirm = async () => {
    if (!actions.current || !ready || busy || paying || completed) return;
    if (Date.parse(checkout.expiresAt) <= Date.now()) { setError('รายการหมดเวลาแล้ว กรุณาปิดและเปิดชำระใหม่'); return; }
    setPaying(true); setError('');
    try {
      const result = await actions.current.confirm({
        redirect: 'if_required', savePaymentMethod: checkout.saveCard === true,
        returnUrl: `${window.location.origin}/app?checkout=success`,
      });
      if (result.type === 'error') { setError(result.error.message || 'ชำระไม่สำเร็จ กรุณาตรวจข้อมูลบัตร'); return; }
      setCompleted(true);
      onComplete(); // The server, never this callback, grants Pro.
    } catch { setError('การเชื่อมต่อขัดข้อง กรุณารอสักครู่แล้วลองใหม่'); }
    finally { setPaying(false); }
  };
  const changeOptions = (autoRenew: boolean, saveCard: boolean) => {
    if (busy || paying) return;
    setChanged(true); onOptions({ autoRenew, saveCard });
  };
  return <Modal open onClose={paying ? () => {} : onClose} label="ชำระด้วยบัตร" width={520}>
    <div className="overflow-y-auto p-5 pt-10 sm:p-7 sm:pt-10">
      <div className="mb-5 flex items-center gap-3">
        <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400"><CreditCard size={24}/></div>
        <div><h2 className="text-xl font-bold text-brand-text dark:text-white">ชำระด้วยบัตร</h2>
          <p className="mt-1 text-sm text-brand-muted">กระรอกตุนเงิน · Pro {duration}</p></div>
      </div>
      <div className="mb-6 flex items-center justify-between rounded-xl bg-black/5 p-4 dark:bg-white/5">
        <span className="text-sm text-brand-muted">ยอดชำระวันนี้</span><strong className="text-2xl text-brand-text dark:text-white">฿{amount}</strong>
      </div>
      {completed ? <p role="status" className="py-8 text-center">กำลังยืนยันยอดชำระ สิทธิ์ Pro จะเปิดให้อัตโนมัติ</p> : <>
        {!ready && !error && <p role="status" className="mb-4 text-sm text-brand-muted">กำลังเตรียมช่องกรอกบัตร…</p>}
        <div ref={mount} data-testid="custom-card-fields" className={busy ? 'pointer-events-none opacity-40' : ''}/>
        <fieldset disabled={busy || paying} className="mt-5 space-y-4 disabled:opacity-50">
          <label className="flex cursor-pointer items-start gap-3 text-sm text-brand-text dark:text-white">
            <input type="checkbox" className="mt-1 h-4 w-4 accent-orange-400" checked={checkout.saveCard === true}
              disabled={checkout.autoRenew === true}
              onChange={e => changeOptions(false, e.target.checked)}/>
            <span>จำบัตรไว้ใช้ครั้งหน้า<span className="mt-1 block text-xs text-brand-muted">บัตรเก็บอย่างปลอดภัยกับ Stripe การจำบัตรอย่างเดียวจะไม่ตัดเงินอัตโนมัติ</span></span>
          </label>
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-orange-400/25 p-3 text-sm text-brand-text dark:text-white">
            <input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-orange-400" checked={checkout.autoRenew === true}
              onChange={e => changeOptions(e.target.checked, checkout.saveCard === true || e.target.checked)}/>
            <span>{renewalConsentText(checkout.period)}</span>
          </label>
        </fieldset>
        <p className="mt-3 text-xs text-brand-muted">{checkout.autoRenew
          ? `รอบถัดไป ฿${amount} ทุก${checkout.months === 12 ? 'ปี' : checkout.months === 1 ? 'เดือน' : ' 6 เดือน'} · ปิดการต่ออายุได้`
          : `จ่ายครั้งเดียว ใช้ Pro ${duration} · ไม่ตัดเงินรอบถัดไป`}</p>
        {changed && <p className="mt-2 text-xs text-brand-muted">เมื่อเปลี่ยนตัวเลือก ระบบจะเตรียมรายการใหม่ กรุณาตรวจข้อมูลบัตรก่อนชำระ</p>}
        {error && <p role="alert" className="mt-3 text-sm text-red-500">{error}</p>}
        <button type="button" disabled={!ready || busy || paying} onClick={() => void confirm()}
          className={`${uiPrimaryButton} mt-5 w-full disabled:opacity-50`}>
          {busy ? 'กำลังปรับรายการ…' : paying ? 'กำลังยืนยันการชำระ…' : `ยืนยันชำระ ฿${amount}`}
        </button>
      </>}
      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-brand-muted"><LockKeyhole size={13}/> ชำระอย่างปลอดภัยผ่าน Stripe</p>
    </div>
  </Modal>;
}
