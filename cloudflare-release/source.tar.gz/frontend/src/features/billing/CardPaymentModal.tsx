import React from 'react';
import { loadStripe } from '@stripe/stripe-js/pure';
import type { StripeCheckoutLoadActionsSuccess, StripePaymentElement, StripeCheckoutExpressCheckoutElement, StripeExpressCheckoutElementConfirmEvent } from '@stripe/stripe-js';
import { CreditCard, LockKeyhole } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { uiPrimaryButton } from '../../components/ui/uiStyles';
import { CARD_SAVE_DISCLOSURE, renewalConsentText, type CardOptions } from '../../../../shared/cardConsent';
import type { EmbeddedPayment } from './EmbeddedPaymentModal';

/** Show the selected package immediately while the server validates/prepares it. */
export function PreparingCardModal({ amount, months, onClose }: { amount: number; months: number; onClose: () => void }) {
  return <Modal open onClose={onClose} label="ชำระด้วยบัตร" width={520}>
    <div className="p-7 pt-10 font-sans">
      <h2 className="text-xl font-bold text-brand-text dark:text-white">ชำระด้วยบัตร</h2>
      <p className="mt-1 text-sm text-brand-muted">กระรอกตุนเงิน · Pro {months === 12 ? '1 ปี' : `${months} เดือน`}</p>
      <div className="my-6 flex items-center justify-between rounded-xl bg-black/5 p-4 dark:bg-white/5">
        <span className="text-sm text-brand-muted">ยอดชำระวันนี้</span><strong className="text-2xl">฿{amount.toLocaleString('th-TH')}</strong>
      </div>
      <p role="status" className="text-sm text-brand-muted">กำลังเตรียมช่องกรอกบัตร…</p>
      <div aria-hidden="true" className="mt-4 h-28 animate-pulse rounded-xl bg-black/5 motion-reduce:animate-none dark:bg-white/5"/>
      <p className="mt-5 text-center text-xs text-brand-muted">ชำระอย่างปลอดภัยผ่าน Stripe</p>
    </div>
  </Modal>;
}

export function CardPaymentModal({ checkout, busy, onOptions, onClose, onComplete }: {
  checkout: EmbeddedPayment; busy: boolean;
  onOptions: (options: Pick<CardOptions, 'autoRenew' | 'saveCard'>) => Promise<boolean | undefined>;
  onClose: () => void; onComplete: () => void;
}) {
  const mount = React.useRef<HTMLDivElement>(null);
  const walletMount = React.useRef<HTMLDivElement>(null);
  const [walletStatus, setWalletStatus] = React.useState<'loading' | 'available' | 'unavailable'>('loading');
  const confirmationLock = React.useRef(false);
  const walletConfirm = React.useRef<(event: StripeExpressCheckoutElementConfirmEvent, secret: string) => void>(() => {});
  const actions = React.useRef<StripeCheckoutLoadActionsSuccess | null>(null);
  const [readySecret, setReadySecret] = React.useState<string | null>(null);
  const [paying, setPaying] = React.useState(false);
  const [completed, setCompleted] = React.useState(false);
  const [error, setError] = React.useState('');
  const [changed, setChanged] = React.useState(false);
  const [autoRenew, setAutoRenew] = React.useState(checkout.autoRenew === true);
  const [syncing, setSyncing] = React.useState(false);
  const [syncError, setSyncError] = React.useState('');
  const [retry, setRetry] = React.useState(0);
  const syncLock = React.useRef(false);
  const needsReconcile = React.useRef(false);
  const mounted = React.useRef(false);
  const optionsCallback = React.useRef(onOptions);
  optionsCallback.current = onOptions;
  const ready = readySecret === checkout.clientSecret;
  const optionsPending = syncing || busy || autoRenew !== (checkout.autoRenew === true) || needsReconcile.current;
  React.useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  React.useEffect(() => {
    if (syncLock.current || busy || syncError || completed
      || (autoRenew === (checkout.autoRenew === true) && !needsReconcile.current)) return;
    // Respond locally on every click. Coalesce quick changes and serialize server writes:
    // an older response can never reset the customer's latest selection.
    const timer = window.setTimeout(() => {
      syncLock.current = true; setSyncing(true);
      void optionsCallback.current({ autoRenew, saveCard: true }).then(ok => {
        if (!mounted.current) return;
        needsReconcile.current = ok !== true;
        if (!ok) setSyncError('ยังเตรียมรายการไม่สำเร็จ ตัวเลือกของคุณยังอยู่ กรุณาลองอีกครั้ง');
      }).catch(() => {
        if (!mounted.current) return;
        needsReconcile.current = true;
        setSyncError('การเชื่อมต่อขัดข้อง ตัวเลือกของคุณยังอยู่ กรุณาลองอีกครั้ง');
      }).finally(() => {
        syncLock.current = false;
        if (mounted.current) setSyncing(false);
      });
    }, 350);
    return () => window.clearTimeout(timer);
  }, [autoRenew, checkout.autoRenew, checkout.clientSecret, busy, syncing, syncError, retry, completed]);
  const amount = (checkout.amount / 100).toLocaleString('th-TH');
  const duration = checkout.months === 12 ? '1 ปี' : `${checkout.months} เดือน`;
  React.useEffect(() => {
    let canceled = false;
    let payment: StripePaymentElement | undefined;
    let wallet: StripeCheckoutExpressCheckoutElement | undefined;
    actions.current = null;
    setReadySecret(null); setError(''); setWalletStatus('loading');
    void (async () => {
      const stripe = await loadStripe(checkout.publishableKey, { locale: 'th' });
      if (canceled) return;
      if (!stripe) throw new Error('โหลดช่องกรอกบัตรไม่สำเร็จ');
      const dark = document.documentElement.classList.contains('dark');
      const styles = getComputedStyle(document.documentElement);
      const token = (name: string, fallback: string) => styles.getPropertyValue(name).trim() || fallback;
      const sdk = stripe.initCheckoutElementsSdk({
        clientSecret: checkout.clientSecret,
        elementsOptions: {
          // Stripe fields live in an iframe: the site's CSS fonts must be loaded there too.
          fonts: [{ cssSrc: 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@300;400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap' }],
          savedPaymentMethod: { enableSave: 'never', enableRedisplay: 'auto' },
          appearance: {
            theme: dark ? 'night' : 'stripe',
            variables: { colorPrimary: token('--blue-acc', '#E65F2B'), colorBackground: token('--white', '#ffffff'),
              colorText: token('--text', '#1C1917'), colorTextSecondary: token('--muted', '#7D7772'), colorDanger: '#ef4444',
              borderRadius: '12px', fontFamily: '"IBM Plex Sans Thai", "IBM Plex Sans", sans-serif',
              fontSizeBase: '16px', fontWeightNormal: '400', fontWeightMedium: '500', fontWeightBold: '600', spacingUnit: '4px' },
            rules: { '.Input': { boxShadow: 'none', borderColor: token('--border', '#E5E3DF') },
              '.Label': { fontWeight: '500' }, '.Tab': { boxShadow: 'none' } },
          },
        },
      });
      let fieldsReady = false;
      const markReady = () => { if (!canceled && fieldsReady && actions.current) setReadySecret(checkout.clientSecret); };
      const loadingActions = sdk.loadActions();
      // Wallets need their native confirmation event, separately from card-form submission.
      payment = sdk.createPaymentElement({ layout: 'tabs', wallets: { googlePay: 'never', applePay: 'never' } });
      payment.on('ready', () => { fieldsReady = true; markReady(); });
      payment.on('loaderror', () => { if (!canceled) setError('โหลดช่องกรอกบัตรไม่สำเร็จ กรุณาเปิดหน้านี้อีกครั้ง'); });
      if (mount.current) payment.mount(mount.current);
      // A wallet failure must not prevent the standard card form from loading.
      try {
        wallet = sdk.createExpressCheckoutElement();
        wallet.on('ready', event => {
          if (!canceled) setWalletStatus(event.availablePaymentMethods && Object.values(event.availablePaymentMethods).some(Boolean) ? 'available' : 'unavailable');
        });
        wallet.on('loaderror', () => { if (!canceled) setWalletStatus('unavailable'); });
        wallet.on('confirm', event => {
          if (canceled) { event.paymentFailed({ reason: 'fail' }); return; }
          walletConfirm.current(event, checkout.clientSecret);
        });
        if (walletMount.current) wallet.mount(walletMount.current);
      } catch { if (!canceled) setWalletStatus('unavailable'); }
      const loaded = await loadingActions;
      if (canceled) return;
      if (loaded.type !== 'success') throw new Error('โหลดหน้าชำระไม่สำเร็จ กรุณาลองใหม่');
      actions.current = loaded.actions;
      markReady();
    })().catch(e => { if (!canceled) setError(e.message || 'โหลดหน้าชำระไม่สำเร็จ'); });
    return () => { canceled = true; actions.current = null; payment?.destroy(); wallet?.destroy(); };
  }, [checkout.clientSecret, checkout.publishableKey]);
  const confirm = async (walletEvent?: StripeExpressCheckoutElementConfirmEvent, secret = checkout.clientSecret) => {
    if (!actions.current || !ready || optionsPending || syncError || confirmationLock.current || completed || secret !== checkout.clientSecret) {
      walletEvent?.paymentFailed({ reason: 'fail' }); return;
    }
    if (Date.parse(checkout.expiresAt) <= Date.now()) { setError('รายการหมดเวลาแล้ว กรุณาปิดและเปิดชำระใหม่'); walletEvent?.paymentFailed({ reason: 'fail' }); return; }
    confirmationLock.current = true; setPaying(true); setError('');
    try {
      const result = await actions.current.confirm({
        redirect: 'if_required', savePaymentMethod: checkout.saveCard === true,
        ...(walletEvent ? { expressCheckoutConfirmEvent: walletEvent } : {}),
        returnUrl: `${window.location.origin}/app?checkout=success`,
      });
      if (result.type === 'error') { walletEvent?.paymentFailed({ reason: 'fail' }); setError(result.error.message || 'ชำระไม่สำเร็จ กรุณาตรวจข้อมูลบัตร'); return; }
      setCompleted(true);
      onComplete(); // The server, never this callback, grants Pro.
    } catch (cause) {
      walletEvent?.paymentFailed({ reason: 'fail' });
      // Never log provider payloads, card details, or Checkout secrets.
      const category = cause instanceof Error && cause.name === 'IntegrationError' ? 'integration' : 'confirmation';
      console.warn('checkout_confirmation_failed', { method: walletEvent ? 'wallet' : 'card', category });
      setError(walletEvent ? 'ยืนยันผ่านกระเป๋าเงินไม่สำเร็จ กรุณาลองอีกครั้ง หรือเลือกชำระด้วยบัตร' : 'ยืนยันการชำระไม่สำเร็จ กรุณาตรวจข้อมูลแล้วลองอีกครั้ง');
    }
    finally { confirmationLock.current = false; setPaying(false); }
  };
  walletConfirm.current = (event, secret) => { void confirm(event, secret); };
  const changeOptions = (autoRenew: boolean) => {
    if (paying || completed) return;
    setChanged(true); setAutoRenew(autoRenew); setSyncError('');
  };
  return <Modal open onClose={paying ? () => {} : onClose} label="ชำระด้วยบัตร" width={520}>
    <div className="overflow-y-auto p-5 pt-10 font-sans sm:p-7 sm:pt-10">
      <div className="mb-5 flex items-center gap-3">
        <div className="rounded-xl bg-orange-500/10 p-3 text-orange-400"><CreditCard size={24}/></div>
        <div><h2 className="text-xl font-bold text-brand-text dark:text-white">ชำระด้วยบัตร</h2>
          <p className="mt-1 text-sm text-brand-muted">กระรอกตุนเงิน · Pro {duration}</p></div>
      </div>
      <div className="mb-6 flex items-center justify-between rounded-xl bg-black/5 p-4 dark:bg-white/5">
        <span className="text-sm text-brand-muted">ยอดชำระวันนี้</span><strong className="text-2xl text-brand-text dark:text-white">฿{amount}</strong>
      </div>
      {completed ? <p role="status" className="py-8 text-center">กำลังยืนยันยอดชำระ สิทธิ์ Pro จะเปิดให้อัตโนมัติ</p> : <>
        {!ready && !error && <p role="status" className="mb-4 text-sm text-brand-muted">กำลังเตรียมช่องกรอกบัตร…</p>}
        <div ref={mount} data-testid="custom-card-fields" inert={optionsPending || !!syncError || paying} className={optionsPending ? 'opacity-40' : ''}/>
        <fieldset disabled={paying} className="mt-5 space-y-4 disabled:opacity-50">
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-orange-400/25 p-3 text-sm text-brand-text dark:text-white">
            <input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-orange-400" checked={autoRenew}
              onChange={e => changeOptions(e.target.checked)}/>
            <span>{renewalConsentText(checkout.period)}</span>
          </label>
        </fieldset>
        <p className="mt-3 text-xs text-brand-muted">{autoRenew
          ? `รอบถัดไป ฿${amount} ทุก${checkout.months === 12 ? 'ปี' : checkout.months === 1 ? 'เดือน' : ' 6 เดือน'} · ปิดการต่ออายุได้`
          : `จ่ายครั้งเดียว ใช้ Pro ${duration} · ไม่ตัดเงินรอบถัดไป`}</p>
        {optionsPending && !syncError && <p role="status" className="mt-2 text-xs text-brand-muted">กำลังเตรียมรายการตามตัวเลือกของคุณ…</p>}
        {changed && !optionsPending && !syncError && <p className="mt-2 text-xs text-brand-muted">อัปเดตตัวเลือกแล้ว กรุณาตรวจข้อมูลบัตรก่อนชำระ</p>}
        {syncError && <div className="mt-3 text-sm"><p role="alert" className="text-red-500">{syncError}</p>
          <button type="button" onClick={() => { setSyncError(''); setRetry(n => n + 1); }} className="mt-2 underline">ลองเตรียมรายการอีกครั้ง</button></div>}
        {error && <p role="alert" className="mt-3 text-sm text-red-500">{error}</p>}
        {checkout.saveCard && <p id="card-save-disclosure" className="mt-4 text-xs leading-relaxed text-brand-muted">{CARD_SAVE_DISCLOSURE}</p>}
        <section className="mt-4" aria-label="ชำระผ่านกระเป๋าเงิน">
          {walletStatus === 'available' && <p className="mb-2 text-sm text-brand-muted">ชำระผ่านกระเป๋าเงิน — เลือกบัตรในหน้าต่างที่เปิดขึ้น</p>}
          <div ref={walletMount} data-testid="wallet-buttons" hidden={walletStatus === 'unavailable'}
            inert={!ready || optionsPending || !!syncError || paying}
            className={!ready || optionsPending || paying ? 'opacity-40' : ''}/>
          {walletStatus === 'unavailable' && <p className="text-xs text-brand-muted">Google Pay / Apple Pay ยังไม่พร้อมในเบราว์เซอร์นี้ ใช้ช่องกรอกบัตรด้านบนได้</p>}
        </section>
        <button type="button" disabled={!ready || optionsPending || !!syncError || paying} onClick={() => void confirm()}
          aria-describedby={checkout.saveCard ? 'card-save-disclosure' : undefined}
          className={`${uiPrimaryButton} mt-5 w-full disabled:opacity-50`}>
          {optionsPending && !syncError ? 'กำลังเตรียมรายการ…' : paying ? 'กำลังยืนยันการชำระ…' : `ยืนยันชำระ ฿${amount}${checkout.saveCard ? ' และบันทึกบัตร' : ''}`}
        </button>
      </>}
      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-brand-muted"><LockKeyhole size={13}/> ชำระอย่างปลอดภัยผ่าน Stripe</p>
    </div>
  </Modal>;
}
