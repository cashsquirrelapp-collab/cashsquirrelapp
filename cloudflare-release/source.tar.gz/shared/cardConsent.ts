import { PRO_MONTH_PROMO_LAST_DAY, PRO_PRICING, PRO_REGULAR_MONTHLY, proMonthPromoRunning, thaiShortDate, type ProPeriod } from './proPricing';

// v2 (owner, 2026-10-21): the consent sentence below. v3 (owner, 2026-10-24, "แก้ข้อยินยอม"): a monthly subscription
// made while the monthly promotion runs also agrees to ฿249 a month from 1 Dec 2569. The amounts come from
// PRO_PRICING (with the card fee since 2026-10-25: ฿177, ฿895, ฿1,562) and each checkout stores its exact text. New checkouts record v3 and its
// exact text; subscriptions that agreed to v1 or v2 keep renewing, so renewal checks accept all three. Those agreed
// to ฿159 a month: moving them to ฿249 needs a notice to them first.
export const CARD_CONSENT_VERSION = 'krarok-card-20261024-v3';
export const ACCEPTED_CARD_CONSENT_VERSIONS: readonly string[] = ['krarok-card-20261021-v1', 'krarok-card-20261021-v2', CARD_CONSENT_VERSION];
export const CARD_SAVE_DISCLOSURE_VERSION = 'krarok-card-save-20261021-v2';
export const CARD_SAVE_DISCLOSURE = 'เมื่อกดยืนยันชำระ คุณยินยอมให้ Stripe บันทึกบัตรเพื่อใช้ชำระครั้งถัดไป การบันทึกบัตรไม่ใช่การยินยอมให้ตัดเงินอัตโนมัติ';
export function renewalConsentText(period: ProPeriod, now = new Date()): string {
  const plan = PRO_PRICING[period];
  const cadence = plan.months === 12 ? 'ปี' : plan.months === 1 ? 'เดือน' : '6 เดือน';
  const amount = `฿${plan.total.toLocaleString('th-TH')}/${cadence}`;
  const steps = period === 'month' && proMonthPromoRunning(now) && PRO_REGULAR_MONTHLY > plan.total
    ? `${amount} ถึงวันที่ ${thaiShortDate(PRO_MONTH_PROMO_LAST_DAY)} จากนั้น ฿${PRO_REGULAR_MONTHLY.toLocaleString('th-TH')}/เดือน` : amount;
  return `ยินยอมต่ออายุ Pro อัตโนมัติ ${steps} จนกว่าจะยกเลิก โดยสามารถยกเลิกได้ก่อนรอบบิลถัดไปที่หน้าสมาชิก`;
}
export type CardOptions = { autoRenew: boolean; saveCard: boolean; consentVersion: string };
