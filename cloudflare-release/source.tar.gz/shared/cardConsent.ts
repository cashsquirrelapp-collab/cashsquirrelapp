import { PRO_PRICING, type ProPeriod } from './proPricing';

export const CARD_CONSENT_VERSION = 'krarok-card-20261021-v1';
export const CARD_SAVE_DISCLOSURE_VERSION = 'krarok-card-save-20261021-v2';
export const CARD_SAVE_DISCLOSURE = 'เมื่อกดยืนยันชำระ คุณยินยอมให้ Stripe บันทึกบัตรเพื่อใช้ชำระครั้งถัดไป การบันทึกบัตรไม่ใช่การยินยอมให้ตัดเงินอัตโนมัติ';
export function renewalConsentText(period: ProPeriod): string {
  const plan = PRO_PRICING[period];
  const cadence = plan.months === 12 ? 'ปี' : plan.months === 1 ? 'เดือน' : ' 6 เดือน';
  return `ยินยอมให้ต่ออายุ Pro และตัดบัตรอัตโนมัติ ฿${plan.total.toLocaleString('th-TH')} ทุก${cadence} จนกว่าจะปิดการต่ออายุ โดยปิดได้ในหน้าการสมัครสมาชิกก่อนถึงรอบถัดไป`;
}
export type CardOptions = { autoRenew: boolean; saveCard: boolean; consentVersion: string };
