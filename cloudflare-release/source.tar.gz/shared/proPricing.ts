// Pro prices in one place (owner, 2026-10-20). Every screen that shows a Pro price reads it from here:
// the plans page, the Pro promo dialog and the landing page. Amounts are in baht as the customer pays.

export type ProPeriod = 'month' | 'halfYear' | 'year';
export const PRO_PERIODS: readonly ProPeriod[] = ['month', 'halfYear', 'year'];

export const PRO_PRICING: Record<ProPeriod, { months: number; total: number; bestValue?: boolean }> = {
  month: { months: 1, total: 159 },
  halfYear: { months: 6, total: 849 },
  year: { months: 12, total: 1490, bestValue: true },
};

/**
 * Whether checkout charges exactly the price above. Stripe still holds the earlier monthly offer
 * (฿199 for 3 cycles, then ฿249; backend/src/services/stripeSubscriptions.ts refuses any other
 * configured price) and has no 6-month or 1-year price. So every period stays closed: no button may
 * charge an amount the page does not show. Open a period only after its Stripe price exists and the
 * billing API, PromptPay and the webhook checks use these amounts.
 */
export const PRO_CHECKOUT_OPEN: Record<ProPeriod, boolean> = { month: false, halfYear: false, year: false };

export interface ProPriceDetails {
  months: number;
  total: number;
  /** The monthly price times the months. */
  regular: number;
  saving: number;
  /** Rounded to a whole percent; 0 for monthly. */
  savingPct: number;
  average: number;
  bestValue: boolean;
}

export function proPriceDetails(period: ProPeriod): ProPriceDetails {
  const { months, total, bestValue = false } = PRO_PRICING[period];
  const regular = PRO_PRICING.month.total * months;
  const saving = Math.max(0, regular - total);
  return { months, total, regular, saving, savingPct: regular ? Math.round((saving / regular) * 100) : 0, average: total / months, bestValue };
}

/** "฿1,490"; an average keeps two decimals: "฿141.50". */
export function formatBaht(value: number, decimals = 0): string {
  return `฿${value.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}
