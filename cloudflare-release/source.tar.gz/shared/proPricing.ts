// Pro prices in one place (owner, 2026-10-20). Every screen that shows a Pro price reads it from here:
// the plans page, the Pro promo dialog and the landing page. Amounts are in baht as the customer pays.

export type ProPeriod = 'month' | 'halfYear' | 'year';
export const PRO_PERIODS: readonly ProPeriod[] = ['month', 'halfYear', 'year'];

/** The regular monthly price (owner, 2026-10-20: "ราคาจริงคือ 249"); every period's promotion is shown
 * against it, struck through: ฿249 a month, ฿1,494 for 6 months, ฿2,988 for a year. */
export const PRO_REGULAR_MONTHLY = 249;

/**
 * What the owner receives for each period after Stripe's fee (owner, 2026-10-25: "ผู้ใช้ออกค่าธรรมเนียมเอง กูต้องได้
 * ยอดสุทธิตามราคาที่กูตั้งเป๊ะๆ"). The customer's price below is this plus the fee.
 */
export const PRO_NET_TARGET: Record<ProPeriod, number> = { month: 159, halfYear: 849, year: 1490 };

/**
 * Stripe Thailand's standard fee for a domestic card (stripe.com/en-th/pricing, checked 2026-10-25): 3.65% + ฿10 per
 * payment, with VAT on the fee (Stripe's Thailand tax page; 7%, the reduced rate). PromptPay costs less (1.65%), so it
 * nets more; foreign cards (4.75% + ฿10) net up to about ฿2 less on a month.
 */
export const STRIPE_TH_CARD_FEE = { percent: 3.65, fixedBaht: 10, vatPercent: 7 } as const;
/** What the owner keeps from a payment of `total` baht by a domestic card. */
export function netAfterCardFee(total: number, fee: { percent: number; fixedBaht: number; vatPercent: number } = STRIPE_TH_CARD_FEE): number {
  return total - (total * fee.percent / 100 + fee.fixedBaht) * (1 + fee.vatPercent / 100);
}

/**
 * The prices the customer pays, in whole baht: the lowest price that still leaves the owner the net target after a
 * domestic card's fee (tests/pro-pricing.test.ts checks it). Stripe's catalog must hold exactly these amounts.
 */
export const PRO_PRICING: Record<ProPeriod, { months: number; total: number; bestValue?: boolean }> = {
  month: { months: 1, total: 177 },
  halfYear: { months: 6, total: 895 },
  year: { months: 12, total: 1562, bestValue: true },
};

/** Owner, 2026-10-24: the monthly promotion (now ฿177 with the card fee) runs through 30 Nov 2569; from 1 Dec 2569 a month costs the
 * regular ฿249. Six months and a year keep their prices. Every price screen states the end date while it runs. */
export const PRO_MONTH_PROMO_LAST_DAY = '2026-11-30';
export const PRO_MONTH_PROMO_NEXT_DAY = '2026-12-01';
/** "30 พ.ย. 2569" from "2026-11-30", the same on every runtime (no Intl). */
export function thaiShortDate(key: string): string {
  const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
  return `${Number(key.slice(8, 10))} ${months[Number(key.slice(5, 7)) - 1]} ${Number(key.slice(0, 4)) + 543}`;
}
export function proMonthPromoRunning(now = new Date()): boolean {
  return new Date(now.getTime() + 7 * 3600_000).toISOString().slice(0, 10) <= PRO_MONTH_PROMO_LAST_DAY;
}

/** Implemented periods. The billing API additionally requires KRAROK_PREPAID_ENABLED and
 * validates the Stripe catalog; the UI waits for checkout_ready before accepting payment. */
export const PRO_CHECKOUT_OPEN: Record<ProPeriod, boolean> = { month: true, halfYear: true, year: true };

export interface ProPriceDetails {
  months: number;
  total: number;
  /** The regular monthly price times the months. */
  regular: number;
  saving: number;
  /** Against the regular price, rounded to a whole percent. */
  savingPct: number;
  average: number;
  bestValue: boolean;
}

export function proPriceDetails(period: ProPeriod): ProPriceDetails {
  const { months, total, bestValue = false } = PRO_PRICING[period];
  const regular = PRO_REGULAR_MONTHLY * months;
  const saving = Math.max(0, regular - total);
  return { months, total, regular, saving, savingPct: regular ? Math.round((saving / regular) * 100) : 0, average: total / months, bestValue };
}

/** "฿1,562"; an average keeps two decimals: "฿130.17". */
export function formatBaht(value: number, decimals = 0): string {
  return `฿${value.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}
