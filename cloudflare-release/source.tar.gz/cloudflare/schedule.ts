// The cron jobs vercel.json schedules, by Cloudflare cron expression (UTC). Keep both in step.
//   0 1 * * *   08:00 Bangkok daily       overdue digest
//   0 1 1 * *   08:00 Bangkok on the 1st  monthly report, 50 ทวิ reminder
//   0 2 * * *   09:00 Bangkok daily       close expired accounts
export const CRONS = ['0 1 * * *', '0 1 1 * *', '0 2 * * *'] as const;

export function scheduledPaths(cron: string): string[] {
  switch (cron) {
    case '0 1 * * *': return ['/api/send-overdue-digest'];
    case '0 1 1 * *': return ['/api/send-monthly-report', '/api/send-wht50-reminder'];
    case '0 2 * * *': return ['/api/close-expired-accounts'];
    default: return [];
  }
}
